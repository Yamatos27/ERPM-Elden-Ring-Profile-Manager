ELDEN RING PROFILE MANAGER — PUBLIC PREVIEW 1.4.7

SAUVEGARDES COMPRESSÉES AUTOMATIQUEMENT
Au démarrage et lors des actualisations après les opérations, les anciennes
sauvegardes des profils sont compressées. La plus récente de chaque profil
reste directement disponible. Les sauvegardes du jeu et la référence ne sont
pas compressées. Les anciennes copies déjà présentes sont prises en charge.
Les points importants restent conservés et peuvent également être compressés.

La liste indique « compressée ». Sélectionne une ancienne sauvegarde et clique
Charger la partie : la décompression et le chargement se font automatiquement.
L'archive reste conservée. Le bouton passe ensuite à Jouer.
Tous les fichiers du dossier sont conservés, y compris les fichiers .bak.
Avant de remplacer un dossier par son archive, l'application extrait une copie
et compare chaque fichier. Si la compression échoue, elle conserve le dossier
et inscrit la raison dans le journal. Une archive invalide bloque le chargement
sans remplacer la sauvegarde du jeu. Le gain d'espace dépend du contenu.

AFFICHAGE SUR IMAGE
Les textes se fondent dans l'image sans bandes noires. Le fond est repeint sous
chaque texte pour éviter les lettres superposées. L'image est assombrie d'au
moins 60 % pour améliorer la lisibilité. Les listes et boutons gardent leur fond.

INSTALLATION
Ferme l'ancienne version. Place le nouvel exécutable dans ton dossier habituel,
à côté du même config.json et du même dossier data. Ne remplace pas tes données.
Utilise cette version pour relire les sauvegardes qu'elle compresse : les versions
antérieures ne savent pas les charger automatiquement.

VALIDATION
20 tests passent sous Windows : compression/restauration avec fichiers annexes,
conservation de la dernière sauvegarde, liste des archives, archive corrompue,
redessin du fond contrôlé par lecture des pixels, et tests existants.
Le parcours visuel complet et le jeu n'ont pas été testés sur ton installation.

SOURCES ET DÉPENDANCES INCLUSES DANS SOURCE
  go test -mod=vendor ./...

CORRECTION 1.4.7
Les libellés principaux sont entièrement dessinés par l'application : image et
texte dans la même opération. Un test avec un vrai contrôle Windows vérifie
le rendu après trois changements de texte, pixel par pixel.
Ferme toutes les anciennes versions et vérifie que le titre affiche 1.4.7.
