//go:build windows

package main

import (
	"strings"
	"unsafe"
)

var pIsDialogMessageW = user32.NewProc("IsDialogMessageW")
var pIsWindowEnabled = user32.NewProc("IsWindowEnabled")
var pIsWindow = user32.NewProc("IsWindow")
var pGetWindowRect = user32.NewProc("GetWindowRect")

// Separate owned windows cannot be covered by sibling list controls, even when
// the main window refreshes or resizes while a dialog is open.
func messageBox(title, text string, flags uintptr) int {
	if modalActive {
		return IDCANCEL
	}
	modalActive = true
	defer func() {
		modalActive = false
		setControlsEnabled(!busy && initialized)
		if pageKind != "" {
			setPageControlsEnabled(!busy)
		}
	}()
	// Existing call sites offer a real cancellation path as well as Yes/No.
	if flags&15 == MB_YESNO {
		flags = (flags &^ 15) | 3
	}
	r, _, _ := pMessageBoxW.Call(mainHwnd, uintptr(unsafe.Pointer(utf16Ptr(text))), uintptr(unsafe.Pointer(utf16Ptr(title))), flags)
	if r == 0 {
		return IDCANCEL
	}
	return int(r)
}

func createOwnedPrompt(title string) uintptr {
	ensurePromptClass()
	if !promptClassRegistered {
		return 0
	}
	var rc RECT
	pGetWindowRect.Call(mainHwnd, uintptr(unsafe.Pointer(&rc)))
	x := int(rc.Left) + (int(rc.Right-rc.Left)-650)/2
	y := int(rc.Top) + (int(rc.Bottom-rc.Top)-300)/2
	if x < 0 {
		x = 0
	}
	if y < 0 {
		y = 0
	}
	// No WS_CHILD: mainHwnd is the owner, not a parent in the content hierarchy.
	return createChild(mainHwnd, "EldenRingPromptPublicV1", title, 0, WS_POPUP|WS_CAPTION|WS_SYSMENU, x, y, 650, 300, 0, 0)
}

func promptText(title, label, def string) (string, bool) {
	if modalActive {
		return "", false
	}
	modalActive = true
	enabled, _, _ := pIsWindowEnabled.Call(mainHwnd)
	pEnableWindow.Call(mainHwnd, 0)
	defer func() {
		modalActive = false
		valid, _, _ := pIsWindow.Call(mainHwnd)
		if valid != 0 && enabled != 0 {
			pEnableWindow.Call(mainHwnd, 1)
			pSetForegroundWindow.Call(mainHwnd)
		}
		setControlsEnabled(!busy && initialized)
		if pageKind != "" {
			setPageControlsEnabled(!busy)
		}
	}()
	promptMu.Lock()
	promptState = promptDialogState{Title: title, Label: label, Default: def}
	promptMu.Unlock()
	hwnd := createOwnedPrompt(title)
	if hwnd == 0 {
		return "", false
	}
	pShowWindow.Call(hwnd, SW_SHOW)
	pSetForegroundWindow.Call(hwnd)
	promptMu.Lock()
	edit := promptState.Edit
	promptMu.Unlock()
	pSetFocus.Call(edit)
	var m MSG
	for {
		promptMu.Lock()
		done := promptState.Done
		promptMu.Unlock()
		if done {
			break
		}
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			pDestroyWindow.Call(hwnd)
			// Do not consume the application's quit notification in a nested loop.
			if r == 0 {
				pPostQuitMessage.Call(m.WParam)
			}
			return "", false
		}
		handled, _, _ := pIsDialogMessageW.Call(hwnd, uintptr(unsafe.Pointer(&m)))
		if handled == 0 {
			pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
			pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
		}
	}
	promptMu.Lock()
	result, ok := promptState.Result, promptState.OK
	promptMu.Unlock()
	return strings.TrimSpace(result), ok
}
