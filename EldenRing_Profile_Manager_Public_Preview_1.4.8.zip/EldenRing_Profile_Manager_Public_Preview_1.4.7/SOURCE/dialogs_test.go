//go:build windows

package main

import (
	"runtime"
	"syscall"
	"testing"
	"unsafe"
)

// Hidden Win32 windows exercise the real parent/owner and command routing.
// These tests neither show UI nor read user profiles or launch any process.
func TestOwnedPromptRouting(t *testing.T) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	oldMain := mainHwnd
	mainHwnd = createChild(0, "STATIC", "test owner", 0, WS_OVERLAPPED, 0, 0, 900, 700, 0, 0)
	if mainHwnd == 0 {
		t.Fatal("hidden owner creation failed")
	}
	defer func() { pDestroyWindow.Call(mainHwnd); mainHwnd = oldMain }()
	for _, command := range []int{IDOK, IDCANCEL} {
		promptState = promptDialogState{Label: "A long label\nSecond line", Default: "test value"}
		hwnd := createOwnedPrompt("hidden prompt")
		if hwnd == 0 {
			t.Fatal("prompt creation failed")
		}
		style, _, _ := user32.NewProc("GetWindowLongW").Call(hwnd, uintptr(^uint32(15))) // GWL_STYLE = -16
		if style&WS_CHILD != 0 {
			t.Fatal("prompt is still an inline child")
		}
		owner, _, _ := user32.NewProc("GetWindow").Call(hwnd, 4) // GW_OWNER
		if owner != mainHwnd {
			t.Fatal("incorrect dialog owner")
		}
		parent, _, _ := user32.NewProc("GetParent").Call(promptState.Edit)
		if parent != hwnd {
			t.Fatal("edit still belongs to the main window")
		}
		pSendMessageW.Call(hwnd, WM_COMMAND, uintptr(command), 0)
		if !promptState.Done || promptState.OK != (command == IDOK) {
			t.Fatal("wrong result", command, promptState)
		}
		if command == IDOK && promptState.Result != "test value" {
			t.Fatal("edit text lost")
		}
		exists, _, _ := pIsWindow.Call(hwnd)
		if exists != 0 {
			pDestroyWindow.Call(hwnd)
			t.Fatal("dialog not destroyed")
		}
	}
}

func TestPromptKeyboard(t *testing.T) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	oldMain := mainHwnd
	mainHwnd = createChild(0, "STATIC", "test owner", 0, WS_OVERLAPPED, 0, 0, 900, 700, 0, 0)
	defer func() { pDestroyWindow.Call(mainHwnd); mainHwnd = oldMain }()
	for _, key := range []uintptr{13, 27} {
		promptState = promptDialogState{Label: "Keyboard test", Default: "value"}
		hwnd := createOwnedPrompt("hidden prompt")
		if hwnd == 0 {
			t.Fatal("prompt creation failed")
		}
		msg := MSG{HWnd: promptState.Edit, Message: WM_KEYDOWN, WParam: key}
		pIsDialogMessageW.Call(hwnd, uintptr(unsafe.Pointer(&msg)))
		if !promptState.Done || promptState.OK != (key == 13) {
			pDestroyWindow.Call(hwnd)
			t.Fatalf("key %d not handled correctly: %+v", key, promptState)
		}
	}
}

func TestModalRefreshKeepsBackgroundDisabled(t *testing.T) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	owner := createChild(0, "STATIC", "hidden", 0, WS_OVERLAPPED, 0, 0, 200, 200, 0, 0)
	defer pDestroyWindow.Call(owner)
	child := createChild(owner, "BUTTON", "hidden", 0, WS_CHILD, 0, 0, 100, 30, 0, 0)
	oldButtons, oldModal, oldPages := actionButtons, modalActive, pageControls
	defer func() { actionButtons = oldButtons; modalActive = oldModal; pageControls = oldPages }()
	actionButtons = map[int]uintptr{12345: child}
	pageControls = []uintptr{child}
	modalActive = true
	setControlsEnabled(true)
	enabled, _, _ := pIsWindowEnabled.Call(child)
	if enabled != 0 {
		t.Fatal("refresh re-enabled a background action")
	}
	setPageControlsEnabled(true)
	enabled, _, _ = pIsWindowEnabled.Call(child)
	if enabled != 0 {
		t.Fatal("page refresh re-enabled a background action")
	}
}

func TestStaticLabelsEraseOldText(t *testing.T) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	dc, _, _ := gdi32.NewProc("CreateCompatibleDC").Call(0)
	if dc == 0 {
		t.Fatal("DC creation failed")
	}
	defer gdi32.NewProc("DeleteDC").Call(dc)
	old := brushBg
	brushBg, _, _ = pCreateSolidBrush.Call(colBg)
	defer func() { pDeleteObject.Call(brushBg); brushBg = old }()
	brush := wndProc(0, WM_CTLCOLORSTATIC, dc, 12345)
	mode, _, _ := gdi32.NewProc("GetBkMode").Call(dc)
	color, _, _ := gdi32.NewProc("GetBkColor").Call(dc)
	if brush != brushBg || mode != 2 || color != colBg {
		t.Fatalf("label does not erase its background: %d %d %d", brush, mode, color)
	}
}

func TestLabelBackgroundRepaintsImage(t *testing.T) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	parent := createChild(0, "STATIC", "", 0, WS_OVERLAPPED, 0, 0, 200, 200, 0, 0)
	defer pDestroyWindow.Call(parent)
	child := createChild(parent, "STATIC", "", 0, WS_CHILD, 20, 30, 50, 30, 0, 0)
	if parent == 0 || child == 0 {
		t.Fatal("hidden windows unavailable")
	}
	oldPixels, oldW, oldH := bgPixels, bgWidth, bgHeight
	bgPixels, bgWidth, bgHeight = make([]byte, 100*100*4), 100, 100
	for i := 0; i < len(bgPixels); i += 4 {
		bgPixels[i] = 30
		bgPixels[i+1] = 20
		bgPixels[i+2] = 10
	}
	defer func() { bgPixels, bgWidth, bgHeight = oldPixels, oldW, oldH }()
	screen, _, _ := user32.NewProc("GetDC").Call(0)
	defer user32.NewProc("ReleaseDC").Call(0, screen)
	dc, _, _ := gdi32.NewProc("CreateCompatibleDC").Call(screen)
	defer gdi32.NewProc("DeleteDC").Call(dc)
	bmp, _, _ := gdi32.NewProc("CreateCompatibleBitmap").Call(screen, 50, 30)
	previous, _, _ := gdi32.NewProc("SelectObject").Call(dc, bmp)
	defer func() { gdi32.NewProc("SelectObject").Call(dc, previous); pDeleteObject.Call(bmp) }()
	for i := 0; i < 2; i++ {
		gdi32.NewProc("SetPixel").Call(dc, 5, 5, 0xffffff)
		if !paintLabelBackground(parent, child, dc) {
			t.Fatal("background not painted")
		}
		pixel, _, _ := gdi32.NewProc("GetPixel").Call(dc, 5, 5)
		if pixel != 10|20<<8|30<<16 {
			t.Fatalf("old text pixel not replaced by image: %x", pixel)
		}
	}
}

func TestNativeLabelPrintErasesTextWithoutBlackBars(t *testing.T) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	parent := createChild(0, "STATIC", "", 0, WS_OVERLAPPED, 0, 0, 300, 200, 0, 0)
	defer pDestroyWindow.Call(parent)
	draws := 0
	callback := syscall.NewCallback(func(h uintptr, m uint32, w, l uintptr) uintptr {
		if m == WM_DRAWITEM {
			draws++
			return wndProc(h, m, w, l)
		}
		r, _, _ := pDefWindowProcW.Call(h, uintptr(m), w, l)
		return r
	})
	user32.NewProc("SetWindowLongPtrW").Call(parent, uintptr(^uint32(3)), callback)
	oldMain, oldControls := mainHwnd, mainControls
	mainHwnd = parent
	child := createControl("STATIC", "Long previous text", WS_CHILD, 20, 30, 180, 30, 0, 0)
	defer func() { mainHwnd = oldMain; mainControls = oldControls; delete(controlLayout, child) }()
	oldPixels, oldW, oldH := bgPixels, bgWidth, bgHeight
	bgPixels, bgWidth, bgHeight = make([]byte, 100*100*4), 100, 100
	for i := 0; i < len(bgPixels); i += 4 {
		bgPixels[i] = 30
		bgPixels[i+1] = 20
		bgPixels[i+2] = 10
	}
	defer func() { bgPixels, bgWidth, bgHeight = oldPixels, oldW, oldH }()
	screen, _, _ := user32.NewProc("GetDC").Call(0)
	defer user32.NewProc("ReleaseDC").Call(0, screen)
	dc, _, _ := gdi32.NewProc("CreateCompatibleDC").Call(screen)
	defer gdi32.NewProc("DeleteDC").Call(dc)
	bmp, _, _ := gdi32.NewProc("CreateCompatibleBitmap").Call(screen, 180, 30)
	previous, _, _ := gdi32.NewProc("SelectObject").Call(dc, bmp)
	defer func() { gdi32.NewProc("SelectObject").Call(dc, previous); pDeleteObject.Call(bmp) }()
	for _, text := range []string{"Long previous text", "Short", ""} {
		setWindowText(child, text)
		pSendMessageW.Call(child, 0x318, dc, 4) // WM_PRINTCLIENT / PRF_CLIENT
	}
	if draws != 3 {
		t.Fatalf("native owner paint not exercised: %d", draws)
	}
	for y := 0; y < 30; y++ {
		for x := 0; x < 180; x++ {
			pixel, _, _ := gdi32.NewProc("GetPixel").Call(dc, uintptr(x), uintptr(y))
			if pixel != 10|20<<8|30<<16 {
				t.Fatalf("black bar or old text at %d,%d: %x", x, y, pixel)
			}
		}
	}
}
