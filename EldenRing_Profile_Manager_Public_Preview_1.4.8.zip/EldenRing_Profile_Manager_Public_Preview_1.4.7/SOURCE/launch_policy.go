//go:build windows

package main

import (
	"fmt"
	"os/exec"
	"path/filepath"
)

func validateModEngineLauncher() error {
	if !cfg.UseModEngine || !filepath.IsAbs(cfg.ModEngine) {
		return fmt.Errorf("configure et active ModEngine 2 dans PARAMÈTRES ; tous les profils l'utilisent pour jouer")
	}
	for _, name := range []string{"launchmod_eldenring.bat", "modengine2_launcher.exe", "config_eldenring.toml"} {
		if err := requirePayloadFile(filepath.Join(cfg.ModEngine, name)); err != nil {
			return err
		}
	}
	_, _, err := readRandomizerConfig(modEngineConfigPath())
	return err
}

// A single launch policy for Normal and Randomizer. Legacy settings cannot
// re-enable Steam/direct-executable fallback.
func profileLaunchCommand(p ProfileMeta) (*exec.Cmd, error) {
	if err := validateModEngineLauncher(); err != nil {
		return nil, err
	}
	if p.Mode == "randomizer" {
		return randomizerLaunchCommand(p)
	}
	if p.Mode != "normal" {
		return nil, fmt.Errorf("mode du profil inconnu : %s", p.Mode)
	}
	if err := validateNormalEnvironment(); err != nil {
		return nil, err
	}
	cmd := exec.Command("cmd.exe", "/d", "/c", ".\\launchmod_eldenring.bat")
	cmd.Dir = cfg.ModEngine
	return cmd, nil
}
