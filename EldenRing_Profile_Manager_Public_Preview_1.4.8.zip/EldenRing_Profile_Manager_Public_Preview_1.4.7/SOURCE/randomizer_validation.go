//go:build windows

package main

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"

	"github.com/pelletier/go-toml/v2"
)

var requiredRandomizerDLLs = []string{"RandomizerHelper.dll", "RandomizerCrashFix.dll"}
var requiredRandomizerINIs = []string{"RandomizerHelper_config.ini"}

func isSeparateTransmogFile(name string) bool {
	switch strings.ToLower(name) {
	case "ertransmogrify.dll", "ertransmogrify.ini", "ertransmogrify.txt":
		return true
	}
	return false
}

func requirePayloadFile(path string) error {
	st, err := os.Lstat(path)
	if err != nil {
		return fmt.Errorf("fichier requis inaccessible : %s : %w", path, err)
	}
	if !st.Mode().IsRegular() || st.Size() == 0 {
		return fmt.Errorf("fichier requis vide ou non régulier : %s", path)
	}
	return nil
}

// Record the source shape at import; absence is not inferred from a damaged cache.
type randomizerSourceShape struct {
	Version    int  `json:"version"`
	ChrPresent bool `json:"chrPresent"`
}

func recordRandomizerSourceShape(source, dest string) error {
	st, err := os.Lstat(filepath.Join(source, "chr"))
	if err != nil && !os.IsNotExist(err) {
		return err
	}
	if err == nil && (!st.IsDir() || st.Mode()&os.ModeSymlink != 0) {
		return fmt.Errorf("source : chr doit être un dossier")
	}
	b, err := json.Marshal(randomizerSourceShape{Version: 1, ChrPresent: err == nil})
	if err != nil {
		return err
	}
	if err = os.MkdirAll(filepath.Join(dest, "metadata"), 0755); err != nil {
		return err
	}
	return os.WriteFile(filepath.Join(dest, "metadata", "source-shape.json"), b, 0644)
}

func sourceOmitsChr(root string) bool {
	b, err := os.ReadFile(filepath.Join(root, "metadata", "source-shape.json"))
	if err != nil {
		return false
	}
	var shape randomizerSourceShape
	return json.Unmarshal(b, &shape) == nil && shape.Version == 1 && !shape.ChrPresent
}

// Keep errors readable even when the package is in a deeply nested staging folder.
func validateRandomizerPackage(root string) (err error) {
	defer func() {
		if err != nil {
			err = fmt.Errorf("%s", strings.ReplaceAll(err.Error(), root+string(os.PathSeparator), "seed/"))
		}
	}()
	var problems []string
	for _, n := range append(append([]string{"regulation.bin"}, prefixedFiles("root", requiredRandomizerDLLs)...), prefixedFiles("root", requiredRandomizerINIs)...) {
		if err := requirePayloadFile(filepath.Join(root, n)); err != nil {
			problems = append(problems, err.Error())
		}
	}
	for _, n := range managedRandoDirs {
		st, err := os.Lstat(filepath.Join(root, n))
		if n == "chr" && os.IsNotExist(err) && sourceOmitsChr(root) {
			continue
		}
		if err != nil || !st.IsDir() || st.Mode()&os.ModeSymlink != 0 {
			problems = append(problems, "dossier requis absent ou invalide : "+filepath.Join(root, n))
		}
	}
	if len(problems) > 0 {
		return fmt.Errorf("seed incomplète — réimporte une source complète :\n%s", strings.Join(problems, "\n"))
	}
	entries, err := os.ReadDir(filepath.Join(root, "root"))
	if err != nil {
		return err
	}
	for _, e := range entries {
		if isSeparateTransmogFile(e.Name()) {
			continue
		} // Legacy packages may contain this unrelated mod.
		if e.IsDir() || !isRandomizerDLLFolderPayload(e.Name()) {
			return fmt.Errorf("contenu inattendu dans les fichiers DLL du seed : %s", e.Name())
		}
		st, err := os.Lstat(filepath.Join(root, "root", e.Name()))
		if err != nil {
			return err
		}
		if !st.Mode().IsRegular() {
			return fmt.Errorf("fichier DLL/INI/TXT non régulier : %s", e.Name())
		}
	}
	for _, n := range managedRandoDirs {
		if n == "chr" && !pathExists(filepath.Join(root, n)) && sourceOmitsChr(root) {
			continue
		}
		if err := filepath.Walk(filepath.Join(root, n), func(path string, st os.FileInfo, err error) error {
			if err != nil {
				return err
			}
			if st.Mode()&os.ModeSymlink != 0 || (!st.IsDir() && !st.Mode().IsRegular()) {
				return fmt.Errorf("fichier spécial interdit dans la seed : %s", path)
			}
			return nil
		}); err != nil {
			return err
		}
	}
	return nil
}

func prefixedFiles(prefix string, names []string) []string {
	out := make([]string, 0, len(names))
	for _, n := range names {
		out = append(out, filepath.Join(prefix, n))
	}
	return out
}

// A real TOML parser validates tables, strings, comments and duplicate keys.
func readRandomizerConfig(path string) (map[string]any, []byte, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, nil, err
	}
	var doc map[string]any
	if err = toml.Unmarshal(b, &doc); err != nil {
		return nil, nil, fmt.Errorf("config_eldenring.toml invalide : %w", err)
	}
	return doc, b, nil
}

func configDLLs(doc map[string]any) ([]string, error) {
	section, ok := doc["modengine"].(map[string]any)
	if !ok {
		return nil, fmt.Errorf("section [modengine] absente")
	}
	raw, exists := section["external_dlls"]
	if !exists {
		return nil, nil
	}
	values, ok := raw.([]any)
	if !ok {
		return nil, fmt.Errorf("modengine.external_dlls doit être un tableau")
	}
	var out []string
	for _, v := range values {
		s, ok := v.(string)
		if !ok {
			return nil, fmt.Errorf("external_dlls contient une valeur non textuelle")
		}
		out = append(out, s)
	}
	return out, nil
}

// Preserve all other settings and comments; replace only the parsed array.
func externalDLLSpan(text string) (int, int, error) {
	section := ""
	offset := 0
	for _, line := range strings.SplitAfter(text, "\n") {
		t := strings.TrimSpace(strings.SplitN(line, "#", 2)[0])
		if strings.HasPrefix(t, "[") {
			section = t
		}
		eq := strings.Index(line, "=")
		if section == "[modengine]" && eq >= 0 && strings.Trim(strings.TrimSpace(line[:eq]), "\"'") == "external_dlls" {
			start := offset + eq + 1
			for start < len(text) && strings.ContainsRune(" \t\r\n", rune(text[start])) {
				start++
			}
			if start >= len(text) || text[start] != '[' {
				return 0, 0, fmt.Errorf("external_dlls : tableau attendu")
			}
			quote := byte(0)
			escaped := false
			comment := false
			for i := start + 1; i < len(text); i++ {
				c := text[i]
				if comment {
					if c == '\n' {
						comment = false
					}
					continue
				}
				if quote != 0 {
					if escaped {
						escaped = false
						continue
					}
					if quote == '"' && c == '\\' {
						escaped = true
						continue
					}
					if c == quote {
						quote = 0
					}
					continue
				}
				if c == '#' {
					comment = true
					continue
				}
				if c == '"' || c == '\'' {
					quote = c
					continue
				}
				if c == ']' {
					return start, i + 1, nil
				}
			}
			return 0, 0, fmt.Errorf("external_dlls : tableau non fermé")
		}
		offset += len(line)
	}
	return -1, -1, nil
}

func ensureRandomizerDLLsInConfig(seedRoot string) error {
	path := modEngineConfigPath()
	if !fileExists(path) {
		candidates := []string{filepath.Join(seedRoot, "metadata", "config_eldenring.toml"), userModEngineConfigPath(), vanillaModEngineConfigPath()}
		for _, candidate := range candidates {
			if fileExists(candidate) {
				if err := copyFile(candidate, path); err != nil {
					return err
				}
				break
			}
		}
	}
	doc, b, err := readRandomizerConfig(path)
	if err != nil {
		return err
	}
	dlls, err := configDLLs(doc)
	if err != nil {
		return err
	}
	for _, wanted := range requiredRandomizerDLLs {
		found := false
		for _, current := range dlls {
			if strings.EqualFold(filepath.Clean(current), wanted) {
				found = true
			}
		}
		if !found {
			dlls = append(dlls, wanted)
		}
	}
	encoded, err := toml.Marshal(map[string]any{"external_dlls": dlls})
	if err != nil {
		return err
	}
	assignment := strings.TrimSpace(string(encoded))
	array := strings.TrimSpace(strings.SplitN(assignment, "=", 2)[1])
	text := string(b)
	start, end, err := externalDLLSpan(text)
	if err != nil {
		return err
	}
	if start >= 0 {
		text = text[:start] + array + text[end:]
	} else {
		pos := -1
		offset := 0
		for _, line := range strings.SplitAfter(text, "\n") {
			if strings.TrimSpace(strings.SplitN(line, "#", 2)[0]) == "[modengine]" {
				pos = offset + len(line)
				break
			}
			offset += len(line)
		}
		if pos < 0 {
			return fmt.Errorf("section [modengine] introuvable pour compléter external_dlls")
		}
		text = text[:pos] + "\n" + assignment + "\n" + text[pos:]
	}
	var check map[string]any
	if err = toml.Unmarshal([]byte(text), &check); err != nil {
		return err
	}
	if text == string(b) {
		return nil
	}
	// Keep the precise previous configuration before editing it.
	if err = copyFile(path, uniqueSiblingPath(path, "before-randomizer")); err != nil {
		return err
	}
	return os.WriteFile(path, []byte(text), 0644)
}

func fileDigest(path string) ([32]byte, error) {
	var digest [32]byte
	f, err := os.Open(path)
	if err != nil {
		return digest, err
	}
	defer f.Close()
	h := sha256.New()
	if _, err = io.Copy(h, f); err != nil {
		return digest, err
	}
	copy(digest[:], h.Sum(nil))
	return digest, nil
}

func validateDeployedRandomizer(p ProfileMeta) error {
	if err := validateRandoProfile(p); err != nil {
		return err
	}
	src := profileRandoDir(p.ID)
	// Compare every deployed payload byte to the selected seed, including INI/TXT.
	for _, name := range append([]string{"regulation.bin", "root"}, managedRandoDirs...) {
		if name == "chr" && !pathExists(filepath.Join(src, name)) && sourceOmitsChr(src) {
			if pathExists(filepath.Join(modDir(), name)) {
				return fmt.Errorf("dossier déployé inattendu : mod/chr (absent de la source)")
			}
			continue
		}
		err := filepath.Walk(filepath.Join(src, name), func(path string, st os.FileInfo, err error) error {
			if err != nil {
				return err
			}
			if name == "root" && isSeparateTransmogFile(st.Name()) {
				return nil
			}
			if st.Mode()&os.ModeSymlink != 0 {
				return fmt.Errorf("lien non autorisé dans la seed : %s", path)
			}
			rel, err := filepath.Rel(src, path)
			if err != nil {
				return err
			}
			dst := filepath.Join(modDir(), rel)
			if name == "root" {
				rel, err = filepath.Rel(filepath.Join(src, "root"), path)
				if err != nil {
					return err
				}
				dst = filepath.Join(cfg.ModEngine, rel)
			}
			if st.IsDir() {
				if !dirExists(dst) {
					return fmt.Errorf("dossier déployé absent : %s", dst)
				}
				return nil
			}
			a, err := fileDigest(path)
			if err != nil {
				return err
			}
			b, err := fileDigest(dst)
			if err != nil {
				return fmt.Errorf("fichier déployé inaccessible : %s : %w", dst, err)
			}
			if a != b {
				return fmt.Errorf("fichier déployé différent de la seed : %s", dst)
			}
			return nil
		})
		if err != nil {
			return err
		}
	}
	doc, _, err := readRandomizerConfig(modEngineConfigPath())
	if err != nil {
		return err
	}
	dlls, err := configDLLs(doc)
	if err != nil {
		return err
	}
	for _, wanted := range requiredRandomizerDLLs {
		found := false
		for _, entry := range dlls {
			if strings.EqualFold(filepath.Clean(entry), wanted) {
				found = true
			}
		}
		if !found {
			return fmt.Errorf("external_dlls ne charge pas %s à la racine de ModEngine2", wanted)
		}
	}
	extension, _ := doc["extension"].(map[string]any)
	loader, _ := extension["mod_loader"].(map[string]any)
	if loader["enabled"] != true {
		return fmt.Errorf("[extension.mod_loader] enabled doit être true")
	}
	mods, _ := loader["mods"].([]any)
	found := false
	for _, raw := range mods {
		mod, _ := raw.(map[string]any)
		if mod["enabled"] != true {
			continue
		}
		path, _ := mod["path"].(string)
		if strings.EqualFold(filepath.Clean(path), "mod") {
			found = true
			break
		}
		// A preceding mod can override the seed. Refuse rather than silently reorder it.
		return fmt.Errorf("un mod actif précède le dossier mod : %s ; vérifie la priorité dans config_eldenring.toml", path)
	}
	if !found {
		return fmt.Errorf("aucune entrée active path = 'mod' dans extension.mod_loader.mods")
	}
	for _, n := range []string{"launchmod_eldenring.bat", "modengine2_launcher.exe"} {
		if err := requirePayloadFile(filepath.Join(cfg.ModEngine, n)); err != nil {
			return err
		}
	}
	return nil
}

func randomizerLaunchCommand(p ProfileMeta) (*exec.Cmd, error) {
	if p.Mode != "randomizer" {
		return nil, fmt.Errorf("profil Randomizer requis")
	}
	if !cfg.UseModEngine || !cfg.UseRandomizer {
		return nil, fmt.Errorf("ModEngine2 et Randomizer doivent être activés")
	}
	if err := validateDeployedRandomizer(p); err != nil {
		return nil, fmt.Errorf("lancement refusé : %w", err)
	}
	cmd := exec.Command("cmd.exe", "/d", "/c", ".\\launchmod_eldenring.bat")
	cmd.Dir = cfg.ModEngine
	return cmd, nil
}

// Exact cleanup performed by transfert.bat, before copying the new seed only.
// In particular ertransmogrify and the current TOML are not deleted/restored.
func removePreviousSeedForDeployment() error {
	for _, n := range append([]string{"regulation.bin"}, managedRandoDirs...) {
		if err := removePathIfExists(filepath.Join(modDir(), n)); err != nil {
			return err
		}
	}
	entries, err := os.ReadDir(cfg.ModEngine)
	if err != nil {
		return err
	}
	for _, e := range entries {
		if !e.IsDir() && strings.HasPrefix(strings.ToLower(e.Name()), "randomizer") && isRandomizerDLLFolderPayload(e.Name()) {
			if err := removePathIfExists(filepath.Join(cfg.ModEngine, e.Name())); err != nil {
				return err
			}
		}
	}
	return nil
}
