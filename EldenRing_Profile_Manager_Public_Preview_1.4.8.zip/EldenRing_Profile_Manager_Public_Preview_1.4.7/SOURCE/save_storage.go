package main

import (
	"archive/zip"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sync"
)

const saveArchiveName = ".manager-save.zip"

var saveStorageMu sync.Mutex

func storedSaveExists(path string) bool {
	return fileExists(filepath.Join(path, "ER0000.sl2")) || fileExists(filepath.Join(path, saveArchiveName))
}

// Build beside the source, verify a complete round trip, then atomically replace
// the directory. A failed compression never removes the original snapshot.
func compressSave(path string) error {
	if !fileExists(filepath.Join(path, "ER0000.sl2")) {
		return nil
	}
	stage := uniqueSiblingPath(path, "compressed")
	defer os.RemoveAll(stage)
	if err := os.MkdirAll(stage, 0755); err != nil {
		return err
	}
	archive := filepath.Join(stage, saveArchiveName)
	out, err := os.Create(archive)
	if err != nil {
		return err
	}
	zw := zip.NewWriter(out)
	err = filepath.Walk(path, func(p string, info os.FileInfo, e error) error {
		if e != nil {
			return e
		}
		rel, e := filepath.Rel(path, p)
		if e != nil {
			return e
		}
		if rel == "." {
			return nil
		}
		if !info.IsDir() && !info.Mode().IsRegular() {
			return fmt.Errorf("fichier non régulier : %s", p)
		}
		h, e := zip.FileInfoHeader(info)
		if e != nil {
			return e
		}
		h.Name = filepath.ToSlash(rel)
		if info.IsDir() {
			h.Name += "/"
		} else {
			h.Method = zip.Deflate
		}
		w, e := zw.CreateHeader(h)
		if e != nil {
			return e
		}
		if info.IsDir() {
			return nil
		}
		r, e := os.Open(p)
		if e != nil {
			return e
		}
		_, e = io.Copy(w, r)
		ce := r.Close()
		if e != nil {
			return e
		}
		return ce
	})
	ze := zw.Close()
	se := out.Sync()
	ce := out.Close()
	for _, e := range []error{err, ze, se, ce} {
		if e != nil {
			return e
		}
	}
	check := uniqueSiblingPath(path, "verify")
	defer os.RemoveAll(check)
	if err := unzipProfile(archive, check); err != nil {
		return err
	}
	err = filepath.Walk(path, func(p string, info os.FileInfo, e error) error {
		if e != nil {
			return e
		}
		rel, e := filepath.Rel(path, p)
		if e != nil {
			return e
		}
		other := filepath.Join(check, rel)
		if info.IsDir() {
			if !dirExists(other) {
				return fmt.Errorf("dossier absent après vérification : %s", rel)
			}
			return nil
		}
		a, e := fileDigest(p)
		if e != nil {
			return e
		}
		b, e := fileDigest(other)
		if e != nil {
			return e
		}
		if a != b {
			return fmt.Errorf("sauvegarde différente après compression : %s", rel)
		}
		return nil
	})
	if err != nil {
		return err
	}
	return activatePreparedDirectory(stage, path)
}

func maintainSaveStorage(ps []ProfileMeta) {
	saveStorageMu.Lock()
	defer saveStorageMu.Unlock()
	for _, p := range ps {
		saves := listProfileSaves(p.ID)
		for i, s := range saves {
			if i == 0 {
				continue
			}
			if err := compressSave(s.Path); err != nil {
				logLine("Compression différée : " + s.Path + " : " + err.Error())
			}
		}
	}
}

// Expand to a temporary source: the archive stays available if loading fails.
func expandStoredSave(src string) (string, func(), error) {
	if fileExists(filepath.Join(src, "ER0000.sl2")) {
		return src, func() {}, nil
	}
	tmp := uniqueSiblingPath(src, "expanded")
	cleanup := func() { _ = os.RemoveAll(tmp) }
	if err := unzipProfile(filepath.Join(src, saveArchiveName), tmp); err != nil {
		cleanup()
		return "", func() {}, fmt.Errorf("décompression de la sauvegarde impossible (%s) : %w", src, err)
	}
	if !fileExists(filepath.Join(tmp, "ER0000.sl2")) {
		cleanup()
		return "", func() {}, fmt.Errorf("archive de sauvegarde incomplète : ER0000.sl2 absent (%s)", src)
	}
	return tmp, cleanup, nil
}
