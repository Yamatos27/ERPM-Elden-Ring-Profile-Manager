//go:build windows

package main

import (
	"archive/zip"
	"embed"
	"encoding/json"
	"errors"
	"fmt"
	"image"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

// Keep the icon inside the program binary so the title bar/taskbar icon works
// even if the .ico file next to the executable is removed.
//
//go:embed app.ico config_eldenring.toml
var embeddedFS embed.FS

const appVersion = "1.4.7-public-preview"

const (
	defaultSteamID = ""
)

// ----------------------------- Win32 constants -----------------------------
const (
	WS_OVERLAPPED    = 0x00000000
	WS_CAPTION       = 0x00C00000
	WS_SYSMENU       = 0x00080000
	WS_MINIMIZEBOX   = 0x00020000
	WS_MAXIMIZEBOX   = 0x00010000
	WS_THICKFRAME    = 0x00040000
	WS_VISIBLE       = 0x10000000
	WS_CHILD         = 0x40000000
	WS_BORDER        = 0x00800000
	WS_VSCROLL       = 0x00200000
	WS_TABSTOP       = 0x00010000
	WS_POPUP         = 0x80000000
	WS_EX_CLIENTEDGE = 0x00000200

	BS_OWNERDRAW     = 0x0000000B
	BS_DEFPUSHBUTTON = 0x00000001
	BS_PUSHBUTTON    = 0x00000000

	ES_AUTOHSCROLL = 0x0080
	ES_MULTILINE   = 0x0004
	ES_AUTOVSCROLL = 0x0040
	ES_READONLY    = 0x0800

	LBS_NOTIFY           = 0x0001
	LBS_OWNERDRAWFIXED   = 0x0010
	LBS_HASSTRINGS       = 0x0040
	LBS_NOINTEGRALHEIGHT = 0x0100

	SS_LEFT = 0x00000000

	WM_CREATE          = 0x0001
	WM_DESTROY         = 0x0002
	WM_CLOSE           = 0x0010
	WM_SIZE            = 0x0005
	WM_ERASEBKGND      = 0x0014
	WM_TIMER           = 0x0113
	WM_KEYDOWN         = 0x0100
	WM_COMMAND         = 0x0111
	WM_DRAWITEM        = 0x002B
	WM_CTLCOLORSTATIC  = 0x0138
	WM_CTLCOLORLISTBOX = 0x0134
	WM_CTLCOLOREDIT    = 0x0133
	WM_SETFONT         = 0x0030
	WM_SETREDRAW       = 0x000B
	WM_SETICON         = 0x0080

	WM_APP_TASKDONE = 0x8001
	WM_APP_PROGRESS = 0x8002
	WM_APP_AUTOSAVE = 0x8003

	LB_ADDSTRING     = 0x0180
	LB_RESETCONTENT  = 0x0184
	LB_SETCURSEL     = 0x0186
	LB_GETCURSEL     = 0x0188
	LB_SETITEMHEIGHT = 0x01A0

	PBM_SETBARCOLOR = 0x0409
	PBM_SETBKCOLOR  = 0x2001

	LBN_SELCHANGE = 1

	PBM_SETRANGE32 = 0x0406
	PBM_SETPOS     = 0x0402

	SW_HIDE     = 0
	SW_SHOW     = 5
	SW_MAXIMIZE = 3
	SW_RESTORE  = 9

	MB_OK              = 0x00000000
	MB_ICONERROR       = 0x00000010
	MB_ICONINFORMATION = 0x00000040
	MB_ICONQUESTION    = 0x00000020
	MB_ICONWARNING     = 0x00000030
	MB_YESNO           = 0x00000004
	IDOK               = 1
	IDCANCEL           = 2
	IDYES              = 6
	IDNO               = 7

	ODS_SELECTED = 0x0001
	TRANSPARENT  = 1

	DT_CENTER     = 0x00000001
	DT_VCENTER    = 0x00000004
	DT_SINGLELINE = 0x00000020

	IDC_ARROW = 32512

	IMAGE_ICON      = 1
	LR_LOADFROMFILE = 0x0010
	LR_DEFAULTSIZE  = 0x0040

	OFN_PATHMUSTEXIST = 0x00000800
	OFN_FILEMUSTEXIST = 0x00001000
	OFN_EXPLORER      = 0x00080000

	BI_RGB         = 0
	DIB_RGB_COLORS = 0
	SRCCOPY        = 0x00CC0020
	ICON_SMALL     = 0
	ICON_BIG       = 1

	TH32CS_SNAPPROCESS = 0x00000002
	MAX_PATH           = 260
	HOLLOW_BRUSH       = 5
	VK_ESCAPE          = 0x1B

	BIF_RETURNONLYFSDIRS = 0x0001
	BIF_NEWDIALOGSTYLE   = 0x0040
)

const (
	idProfileList = 200
	idSaveList    = 201

	idCreateProfile    = 301
	idRenameProfile    = 302
	idDeleteProfile    = 303
	idImportSeed       = 304
	idBackup           = 305
	idSwitch           = 306
	idLaunch           = 307
	idRefresh          = 308
	idHelp             = 309
	idPlay             = 310
	idFolders          = 311
	idBackground       = 312
	idImportExisting   = 313
	idOpenRandomizer   = 314
	idSettings         = 315
	idDuplicateProfile = 316
	idLockProfile      = 317
	idRecovery         = 318
	idHistory          = 319
	idNamedBackup      = 320

	idCurrentStatus    = 401
	idRandoStatus      = 402
	idProfileName      = 403
	idProfileMode      = 404
	idProfileSeed      = 405
	idSeedStatus       = 406
	idLatestSave       = 407
	idInfoStatus       = 408
	idSeedImportStatus = 409

	idPromptEdit   = 9001
	idPromptOK     = 9002
	idPromptCancel = 9003

	idFolderProfile    = 9201
	idFolderSaves      = 9202
	idFolderSeed       = 9203
	idFolderSeedImport = 9204
	idFolderAppData    = 9205
	idFolderModEngine  = 9206
	idFolderRandApp    = 9207
	idFolderApp        = 9208
	idFolderClose      = 9209
	idFolderExport     = 9210
	idFolderImport     = 9211

	idModalYes        = 9601
	idModalNo         = 9602
	idModalCancel     = 9603
	idModalOK         = 9604
	idModalEditOK     = 9605
	idModalEditCancel = 9606

	idSettingsClose           = 9701
	idSettingsApply           = 9702
	idSettingsLangFR          = 9703
	idSettingsLangEN          = 9704
	idSettingsBrowseSave      = 9705
	idSettingsBrowseData      = 9706
	idSettingsBrowseRef       = 9707
	idSettingsToggleME        = 9708
	idSettingsBrowseME        = 9709
	idSettingsToggleRando     = 9710
	idSettingsBrowseRando     = 9711
	idSettingsToggleNormalME  = 9712
	idSettingsToggleAutosave  = 9713
	idSettingsBackground      = 9714
	idSettingsClearBackground = 9715
	idSettingsPresetGold      = 9716
	idSettingsPresetBlue      = 9717
	idSettingsPresetViolet    = 9718
	idSettingsPresetRed       = 9719
	idSettingsPresetDark      = 9720
	idSettingsEditAccent      = 9721
	idSettingsEditSecondary   = 9722
	idSettingsEditPanel       = 9723
	idSettingsEditText        = 9724
	idSettingsEditProgress    = 9725
	idSettingsEditDarken      = 9726
	idSettingsDiagnostic      = 9727
	idSettingsBrowseGame      = 9728

	idPageBack  = 9801
	idHelpClose = 9802
)

type POINT struct{ X, Y int32 }
type RECT struct{ Left, Top, Right, Bottom int32 }

type OPENFILENAMEW struct {
	LStructSize       uint32
	HwndOwner         uintptr
	HInstance         uintptr
	LpstrFilter       *uint16
	LpstrCustomFilter *uint16
	NMaxCustFilter    uint32
	NFilterIndex      uint32
	LpstrFile         *uint16
	NMaxFile          uint32
	LpstrFileTitle    *uint16
	NMaxFileTitle     uint32
	LpstrInitialDir   *uint16
	LpstrTitle        *uint16
	Flags             uint32
	NFileOffset       uint16
	NFileExtension    uint16
	LpstrDefExt       *uint16
	LCustData         uintptr
	LpfnHook          uintptr
	LpTemplateName    *uint16
	PvReserved        uintptr
	DwReserved        uint32
	FlagsEx           uint32
}

type BROWSEINFOW struct {
	HwndOwner      uintptr
	PidlRoot       uintptr
	PszDisplayName *uint16
	LpszTitle      *uint16
	UlFlags        uint32
	Lpfn           uintptr
	LParam         uintptr
	IImage         int32
}

type BITMAPINFOHEADER struct {
	BiSize          uint32
	BiWidth         int32
	BiHeight        int32
	BiPlanes        uint16
	BiBitCount      uint16
	BiCompression   uint32
	BiSizeImage     uint32
	BiXPelsPerMeter int32
	BiYPelsPerMeter int32
	BiClrUsed       uint32
	BiClrImportant  uint32
}

type BITMAPINFO struct {
	BmiHeader BITMAPINFOHEADER
	BmiColors [1]uint32
}

type MSG struct {
	HWnd     uintptr
	Message  uint32
	WParam   uintptr
	LParam   uintptr
	Time     uint32
	Pt       POINT
	LPrivate uint32
}

type WNDCLASSEX struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     uintptr
	HIcon         uintptr
	HCursor       uintptr
	HbrBackground uintptr
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       uintptr
}

type DRAWITEMSTRUCT struct {
	CtlType    uint32
	CtlID      uint32
	ItemID     uint32
	ItemAction uint32
	ItemState  uint32
	HwndItem   uintptr
	HDC        uintptr
	RcItem     RECT
	ItemData   uintptr
}

type PROCESSENTRY32 struct {
	DwSize              uint32
	CntUsage            uint32
	Th32ProcessID       uint32
	Th32DefaultHeapID   uintptr
	Th32ModuleID        uint32
	CntThreads          uint32
	Th32ParentProcessID uint32
	PcPriClassBase      int32
	DwFlags             uint32
	SzExeFile           [MAX_PATH]uint16
}

// ----------------------------- App data model -------------------------------
type Config struct {
	Language                 string `json:"language"`
	FirstRunComplete         bool   `json:"firstRunComplete"`
	SteamID                  string `json:"steamId"`
	SavePath                 string `json:"savePath"`
	DataRoot                 string `json:"dataRoot"`
	GameExe                  string `json:"gameExe,omitempty"`
	UseModEngine             bool   `json:"useModEngine"`
	ModEngine                string `json:"modEngine,omitempty"`
	LaunchNormalViaModEngine bool   `json:"launchNormalViaModEngine"`
	UseRandomizer            bool   `json:"useRandomizer"`
	RandApp                  string `json:"randApp,omitempty"`
	LegacySaveRoot           string `json:"legacySaveRoot,omitempty"`
	ReferenceSource          string `json:"referenceSource,omitempty"`
	BackgroundImage          string `json:"backgroundImage,omitempty"`
	BackgroundDarken         int    `json:"backgroundDarken,omitempty"`
	ThemeName                string `json:"themeName,omitempty"`
	AccentColor              string `json:"accentColor,omitempty"`
	SecondaryColor           string `json:"secondaryColor,omitempty"`
	PanelColor               string `json:"panelColor,omitempty"`
	TextColor                string `json:"textColor,omitempty"`
	ProgressColor            string `json:"progressColor,omitempty"`
	StartMaximized           bool   `json:"startMaximized"`
	AutoSaveOnExit           bool   `json:"autoSaveOnExit"`
}

type AppState struct {
	CurrentProfileID string `json:"currentProfileId"`
	LastSelectedID   string `json:"lastSelectedId"`
}

type ProfileMeta struct {
	ID                 string `json:"id"`
	Name               string `json:"name"`
	Mode               string `json:"mode"` // normal | randomizer
	Seed               string `json:"seed,omitempty"`
	CreatedAt          string `json:"createdAt"`
	Locked             bool   `json:"locked,omitempty"`
	TotalPlaySeconds   int64  `json:"totalPlaySeconds,omitempty"`
	LastSessionSeconds int64  `json:"lastSessionSeconds,omitempty"`
	SessionCount       int    `json:"sessionCount,omitempty"`
	LastPlayedAt       string `json:"lastPlayedAt,omitempty"`
	Favorite           bool   `json:"favorite,omitempty"`
	Notes              string `json:"notes,omitempty"`
}

type SaveInfo struct {
	Label string
	Path  string
	Date  time.Time
}

type ProfileViewCache struct {
	Saves     []SaveInfo
	SeedReady bool
}

type MigrationInfo struct {
	Version            int      `json:"version"`
	CompletedAt        string   `json:"completedAt"`
	ImportedProfiles   []string `json:"importedProfiles"`
	TemplateImported   bool     `json:"templateImported"`
	RandomizerCaptured bool     `json:"randomizerCaptured"`
}

type taskProgress struct {
	Text    string
	Percent int
}

type taskResult struct {
	LoadedSavePath string
	Kind           string
	Err            error
	Message        string
	CurrentID      string
	SelectedID     string
	ShowInfoBox    bool
	InfoBoxTitle   string
	LaunchAfter    bool
}

// ----------------------------- Win32 bindings -------------------------------
var (
	user32   = syscall.NewLazyDLL("user32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	dwmapi   = syscall.NewLazyDLL("dwmapi.dll")
	comdlg32 = syscall.NewLazyDLL("comdlg32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	ole32    = syscall.NewLazyDLL("ole32.dll")
	uxtheme  = syscall.NewLazyDLL("uxtheme.dll")

	pRegisterClassExW         = user32.NewProc("RegisterClassExW")
	pCreateWindowExW          = user32.NewProc("CreateWindowExW")
	pDefWindowProcW           = user32.NewProc("DefWindowProcW")
	pShowWindow               = user32.NewProc("ShowWindow")
	pUpdateWindow             = user32.NewProc("UpdateWindow")
	pGetMessageW              = user32.NewProc("GetMessageW")
	pTranslateMessage         = user32.NewProc("TranslateMessage")
	pDispatchMessageW         = user32.NewProc("DispatchMessageW")
	pPostQuitMessage          = user32.NewProc("PostQuitMessage")
	pDestroyWindow            = user32.NewProc("DestroyWindow")
	pSendMessageW             = user32.NewProc("SendMessageW")
	pSetWindowTextW           = user32.NewProc("SetWindowTextW")
	pGetWindowTextW           = user32.NewProc("GetWindowTextW")
	pGetWindowTextLengthW     = user32.NewProc("GetWindowTextLengthW")
	pMessageBoxW              = user32.NewProc("MessageBoxW")
	pInvalidateRect           = user32.NewProc("InvalidateRect")
	pPostMessageW             = user32.NewProc("PostMessageW")
	pEnableWindow             = user32.NewProc("EnableWindow")
	pGetSystemMetrics         = user32.NewProc("GetSystemMetrics")
	pLoadCursorW              = user32.NewProc("LoadCursorW")
	pLoadImageW               = user32.NewProc("LoadImageW")
	pSetForegroundWindow      = user32.NewProc("SetForegroundWindow")
	pSetFocus                 = user32.NewProc("SetFocus")
	pGetClientRect            = user32.NewProc("GetClientRect")
	pMoveWindow               = user32.NewProc("MoveWindow")
	pSetTimer                 = user32.NewProc("SetTimer")
	pKillTimer                = user32.NewProc("KillTimer")
	pSetTextColor             = gdi32.NewProc("SetTextColor")
	pSetBkColor               = gdi32.NewProc("SetBkColor")
	pSetBkMode                = gdi32.NewProc("SetBkMode")
	pCreateSolidBrush         = gdi32.NewProc("CreateSolidBrush")
	pGetStockObject           = gdi32.NewProc("GetStockObject")
	pDeleteObject             = gdi32.NewProc("DeleteObject")
	pCreateFontW              = gdi32.NewProc("CreateFontW")
	pStretchDIBits            = gdi32.NewProc("StretchDIBits")
	pFillRect                 = user32.NewProc("FillRect")
	pDrawTextW                = user32.NewProc("DrawTextW")
	pGetModuleHandleW         = kernel32.NewProc("GetModuleHandleW")
	pCreateToolhelp32Snapshot = kernel32.NewProc("CreateToolhelp32Snapshot")
	pProcess32FirstW          = kernel32.NewProc("Process32FirstW")
	pProcess32NextW           = kernel32.NewProc("Process32NextW")
	pCloseHandle              = kernel32.NewProc("CloseHandle")
	pDwmSetWindowAttribute    = dwmapi.NewProc("DwmSetWindowAttribute")
	pSetProcessDPIAware       = user32.NewProc("SetProcessDPIAware")
	pGetOpenFileNameW         = comdlg32.NewProc("GetOpenFileNameW")
	pSHBrowseForFolderW       = shell32.NewProc("SHBrowseForFolderW")
	pSHGetPathFromIDListW     = shell32.NewProc("SHGetPathFromIDListW")
	pCoTaskMemFree            = ole32.NewProc("CoTaskMemFree")
	pSetWindowTheme           = uxtheme.NewProc("SetWindowTheme")
)

// ----------------------------- Global UI state ------------------------------
var (
	mainHwnd uintptr

	profileListHwnd uintptr
	saveListHwnd    uintptr

	currentStatusHwnd    uintptr
	randoStatusHwnd      uintptr
	profileNameHwnd      uintptr
	profileModeHwnd      uintptr
	profileSeedHwnd      uintptr
	seedStatusHwnd       uintptr
	latestSaveHwnd       uintptr
	playTimeHwnd         uintptr
	profileReadyHwnd     uintptr
	infoStatusHwnd       uintptr
	seedImportStatusHwnd uintptr
	progressHwnd         uintptr
	progressTextHwnd     uintptr

	actionButtons = map[int]uintptr{}

	fontNormal  uintptr
	fontSmall   uintptr
	fontTitle   uintptr
	fontSection uintptr
	brushBg     uintptr
	brushPanel  uintptr
	brushEdit   uintptr
	hollowBrush uintptr
	appIcon     uintptr

	cfg Config

	modelMu           sync.RWMutex
	profilesModel     []ProfileMeta
	currentProfileID  string
	selectedProfileID string
	selectedSaves     []SaveInfo
	profileListIDs    []string

	cacheMu      sync.RWMutex
	profileCache = map[string]ProfileViewCache{}

	busy             = true
	initialized      bool
	randoVisualState string

	taskMu          sync.Mutex
	pendingTask     taskResult
	progressMu      sync.Mutex
	pendingProgress taskProgress

	autoMu          sync.Mutex
	pendingAuto     taskResult
	gameWatchMu     sync.Mutex
	gameWatchActive bool

	promptMu    sync.Mutex
	promptState promptDialogState

	layoutMu      sync.Mutex
	controlLayout = map[uintptr]RECT{}

	bgMu     sync.RWMutex
	bgPixels []byte
	bgWidth  int
	bgHeight int

	windowMaximized  bool
	folderDialogHwnd uintptr

	modalActive     bool
	modalResult     int
	modalPanelHwnd  uintptr
	modalControls   []uintptr
	modalEditHwnd   uintptr
	modalEditResult string

	pagePanelHwnd uintptr
	pageControls  []uintptr
	mainControls  []uintptr
	pageKind      string

	settingsFirstRun         bool
	settingsTemp             Config
	settingsSaveEdit         uintptr
	settingsDataEdit         uintptr
	settingsGameEdit         uintptr
	settingsReferenceEdit    uintptr
	settingsModEngineEdit    uintptr
	settingsRandomizerEdit   uintptr
	settingsAccentEdit       uintptr
	settingsSecondaryEdit    uintptr
	settingsPanelEdit        uintptr
	settingsTextEdit         uintptr
	settingsProgressEdit     uintptr
	settingsDarkenEdit       uintptr
	settingsStatusHwnd       uintptr
	settingsBackgroundSource string
)

const (
	baseUIWidth  = 1234
	baseUIHeight = 885
)

var (
	colBg        = rgb(18, 18, 18)
	colPanel     = rgb(28, 28, 28)
	colPanel2    = rgb(42, 42, 42)
	colSecondary = rgb(55, 55, 55)
	colAccent    = rgb(203, 166, 80)
	colProgress  = rgb(203, 166, 80)
	colText      = rgb(239, 235, 220)
	colMuted     = rgb(168, 164, 154)
	// Safety/primary action colors intentionally stay fixed.
	colGold     = rgb(203, 166, 80)
	colGoldDark = rgb(122, 96, 40)
	colGreen    = rgb(100, 180, 125)
	colRed      = rgb(205, 92, 92)
)

func rgb(r, g, b byte) uintptr { return uintptr(r) | uintptr(g)<<8 | uintptr(b)<<16 }

func colorHex(c uintptr) string {
	r := byte(c & 0xff)
	g := byte((c >> 8) & 0xff)
	b := byte((c >> 16) & 0xff)
	return fmt.Sprintf("#%02X%02X%02X", r, g, b)
}

func parseColorHex(s string, fallback uintptr) uintptr {
	s = strings.TrimSpace(strings.TrimPrefix(s, "#"))
	if len(s) != 6 {
		return fallback
	}
	v, err := strconv.ParseUint(s, 16, 32)
	if err != nil {
		return fallback
	}
	r := byte((v >> 16) & 0xff)
	g := byte((v >> 8) & 0xff)
	b := byte(v & 0xff)
	return rgb(r, g, b)
}

func applyThemeFromConfig() {
	colAccent = parseColorHex(cfg.AccentColor, rgb(203, 166, 80))
	colSecondary = parseColorHex(cfg.SecondaryColor, rgb(55, 55, 55))
	colPanel = parseColorHex(cfg.PanelColor, rgb(28, 28, 28))
	colPanel2 = colPanel
	colText = parseColorHex(cfg.TextColor, rgb(239, 235, 220))
	colProgress = parseColorHex(cfg.ProgressColor, colAccent)
	if brushPanel != 0 {
		pDeleteObject.Call(brushPanel)
	}
	if brushEdit != 0 {
		pDeleteObject.Call(brushEdit)
	}
	brushPanel, _, _ = pCreateSolidBrush.Call(colPanel)
	brushEdit, _, _ = pCreateSolidBrush.Call(colPanel)
	if progressHwnd != 0 {
		pSendMessageW.Call(progressHwnd, PBM_SETBARCOLOR, 0, colProgress)
		pSendMessageW.Call(progressHwnd, PBM_SETBKCOLOR, 0, colPanel)
	}
}

func utf16Ptr(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func loword(v uintptr) int      { return int(v & 0xffff) }
func hiword(v uintptr) int      { return int((v >> 16) & 0xffff) }

func seedLabel(seed string) string {
	seed = strings.TrimSpace(seed)
	if seed == "" {
		return ""
	}
	lower := strings.ToLower(seed)
	if strings.HasPrefix(lower, "seed") {
		return seed
	}
	return "Seed " + seed
}

func L(fr, en string) string {
	if strings.EqualFold(strings.TrimSpace(cfg.Language), "en") {
		return en
	}
	return fr
}

func boolLabel(v bool) string {
	if v {
		return L("Oui", "Yes")
	}
	return L("Non", "No")
}

// ----------------------------- Paths/config ---------------------------------
func exeDir() string {
	exe, err := os.Executable()
	if err != nil {
		return "."
	}
	return filepath.Dir(exe)
}
func dataRoot() string {
	p := strings.TrimSpace(cfg.DataRoot)
	if p == "" {
		return filepath.Join(exeDir(), "data")
	}
	if filepath.IsAbs(p) {
		return p
	}
	return filepath.Join(exeDir(), p)
}
func profilesRoot() string { return filepath.Join(dataRoot(), "profiles") }
func templateRoot() string {
	return filepath.Join(dataRoot(), "template", "reference-save", cfg.SteamID)
}
func legacyTemplateRoot() string {
	return filepath.Join(dataRoot(), "template", "save-vide", cfg.SteamID)
}
func trashRoot() string              { return filepath.Join(dataRoot(), "trash") }
func emergencyRoot() string          { return filepath.Join(dataRoot(), "emergency") }
func rollbackRoot() string           { return filepath.Join(dataRoot(), "_rollback") }
func recoveryRoot() string           { return filepath.Join(dataRoot(), "recovery") }
func exportsRoot() string            { return filepath.Join(dataRoot(), "exports") }
func baseModsRoot() string           { return filepath.Join(dataRoot(), "modengine-base") }
func seedImportRoot() string         { return filepath.Join(dataRoot(), "seed-import") } // legacy Public Preview 1.1 compatibility
func seedsRoot() string              { return filepath.Join(dataRoot(), "seeds") }
func referencesRoot() string         { return filepath.Join(dataRoot(), "references") }
func modEngineReferenceRoot() string { return filepath.Join(referencesRoot(), "modengine") }
func vanillaModEngineConfigPath() string {
	return filepath.Join(modEngineReferenceRoot(), "config_eldenring.vanilla.toml")
}
func userModEngineConfigPath() string {
	return filepath.Join(modEngineReferenceRoot(), "config_eldenring.user.toml")
}
func appearanceRoot() string           { return filepath.Join(dataRoot(), "appearance") }
func configPath() string               { return filepath.Join(exeDir(), "config.json") }
func statePath() string                { return filepath.Join(dataRoot(), "state.json") }
func migrationPath() string            { return filepath.Join(dataRoot(), "migration-public-v1.json") }
func logPath() string                  { return filepath.Join(dataRoot(), "EldenRing_Save_Manager.log") }
func profileDir(id string) string      { return filepath.Join(profilesRoot(), id) }
func profileMetaPath(id string) string { return filepath.Join(profileDir(id), "profile.json") }
func profileSavesDir(id string) string { return filepath.Join(profileDir(id), "saves") }
func profileRandoDir(id string) string { return filepath.Join(profileDir(id), "randomizer") }
func seedLibraryDir(seed string) string {
	return filepath.Join(seedsRoot(), safePathComponent(seed, "seed"))
}
func profileHistoryPath(id string) string { return filepath.Join(profileDir(id), "history.jsonl") }
func appDataSave() string {
	if strings.TrimSpace(cfg.SavePath) != "" {
		return cfg.SavePath
	}
	return filepath.Join(os.Getenv("APPDATA"), "EldenRing", cfg.SteamID)
}
func modDir() string              { return filepath.Join(cfg.ModEngine, "mod") }
func modEngineConfigPath() string { return filepath.Join(cfg.ModEngine, "config_eldenring.toml") }
func launchBatPath() string       { return filepath.Join(cfg.ModEngine, "launchmod_eldenring.bat") }
func randomizerExePath() string   { return filepath.Join(cfg.RandApp, "EldenRingRandomizer.exe") }
func resolveAppPath(p string) string {
	if p == "" {
		return ""
	}
	if filepath.IsAbs(p) {
		return p
	}
	return filepath.Join(exeDir(), p)
}

func defaultConfig() Config {
	return Config{
		Language:                 "fr",
		FirstRunComplete:         false,
		SteamID:                  defaultSteamID,
		DataRoot:                 filepath.Join(exeDir(), "data"),
		BackgroundDarken:         34,
		ThemeName:                "Elden Ring",
		AccentColor:              "#CBA650",
		SecondaryColor:           "#373737",
		PanelColor:               "#1C1C1C",
		TextColor:                "#EFEBDA",
		ProgressColor:            "#CBA650",
		StartMaximized:           true,
		AutoSaveOnExit:           true,
		LaunchNormalViaModEngine: true,
	}
}

func loadOrCreateConfig() error {
	cfg = defaultConfig()
	b, err := os.ReadFile(configPath())
	if err == nil {
		var c Config
		if err := json.Unmarshal(b, &c); err != nil {
			return fmt.Errorf("config.json: %w", err)
		}
		if strings.TrimSpace(c.Language) != "" {
			cfg.Language = strings.ToLower(strings.TrimSpace(c.Language))
		}
		cfg.FirstRunComplete = c.FirstRunComplete
		if strings.TrimSpace(c.SteamID) != "" {
			cfg.SteamID = strings.TrimSpace(c.SteamID)
		}
		if strings.TrimSpace(c.SavePath) != "" {
			cfg.SavePath = c.SavePath
		}
		if strings.TrimSpace(c.DataRoot) != "" {
			cfg.DataRoot = c.DataRoot
		}
		if strings.TrimSpace(c.GameExe) != "" {
			cfg.GameExe = c.GameExe
		}
		cfg.UseModEngine = c.UseModEngine
		if strings.TrimSpace(c.ModEngine) != "" {
			cfg.ModEngine = c.ModEngine
		}
		if strings.Contains(string(b), "launchNormalViaModEngine") {
			cfg.LaunchNormalViaModEngine = true
		}
		cfg.UseRandomizer = c.UseRandomizer
		if strings.TrimSpace(c.RandApp) != "" {
			cfg.RandApp = c.RandApp
		}
		if strings.TrimSpace(c.LegacySaveRoot) != "" {
			cfg.LegacySaveRoot = c.LegacySaveRoot
		}
		if strings.TrimSpace(c.ReferenceSource) != "" {
			cfg.ReferenceSource = c.ReferenceSource
		}
		if strings.TrimSpace(c.BackgroundImage) != "" {
			cfg.BackgroundImage = c.BackgroundImage
		}
		if c.BackgroundDarken >= 0 && c.BackgroundDarken <= 90 && strings.Contains(string(b), "backgroundDarken") {
			cfg.BackgroundDarken = c.BackgroundDarken
		}
		if strings.TrimSpace(c.ThemeName) != "" {
			cfg.ThemeName = c.ThemeName
		}
		if strings.TrimSpace(c.AccentColor) != "" {
			cfg.AccentColor = c.AccentColor
		}
		if strings.TrimSpace(c.SecondaryColor) != "" {
			cfg.SecondaryColor = c.SecondaryColor
		}
		if strings.TrimSpace(c.PanelColor) != "" {
			cfg.PanelColor = c.PanelColor
		}
		if strings.TrimSpace(c.TextColor) != "" {
			cfg.TextColor = c.TextColor
		}
		if strings.TrimSpace(c.ProgressColor) != "" {
			cfg.ProgressColor = c.ProgressColor
		}
		if strings.Contains(string(b), "startMaximized") {
			cfg.StartMaximized = c.StartMaximized
		}
		if strings.Contains(string(b), "autoSaveOnExit") {
			cfg.AutoSaveOnExit = c.AutoSaveOnExit
		}
		if cfg.UseRandomizer && !cfg.UseModEngine {
			cfg.UseRandomizer = false
		}
		return nil
	}
	if !os.IsNotExist(err) {
		return err
	}
	b, _ = json.MarshalIndent(cfg, "", "  ")
	return os.WriteFile(configPath(), b, 0644)
}

func saveConfig() error {
	b, _ := json.MarshalIndent(cfg, "", "  ")
	return os.WriteFile(configPath(), b, 0644)
}

func ensureAppDirs() error {
	for _, p := range []string{dataRoot(), profilesRoot(), trashRoot(), emergencyRoot(), rollbackRoot(), recoveryRoot(), exportsRoot(), seedImportRoot(), seedsRoot(), appearanceRoot(), referencesRoot(), modEngineReferenceRoot(), filepath.Dir(templateRoot())} {
		if err := os.MkdirAll(p, 0755); err != nil {
			return err
		}
	}
	// Keep the pristine ModEngine2 config bundled with the manager as an immutable reference.
	// It is written only when missing; user/custom configurations are stored separately.
	if !fileExists(vanillaModEngineConfigPath()) {
		b, err := embeddedFS.ReadFile("config_eldenring.toml")
		if err != nil {
			return fmt.Errorf("référence config_eldenring.toml intégrée introuvable : %w", err)
		}
		if err := os.WriteFile(vanillaModEngineConfigPath(), b, 0644); err != nil {
			return fmt.Errorf("impossible de créer la référence ModEngine propre : %w", err)
		}
	}
	// Compatibility with Public Preview 1.0 / personal builds that used template\save-vide.
	if !fileExists(filepath.Join(templateRoot(), "ER0000.sl2")) && fileExists(filepath.Join(legacyTemplateRoot(), "ER0000.sl2")) {
		_ = mirrorCopy(legacyTemplateRoot(), templateRoot())
	}
	return nil
}

func loadState() AppState {
	var s AppState
	b, err := os.ReadFile(statePath())
	if err == nil {
		_ = json.Unmarshal(b, &s)
	}
	return s
}
func saveState() {
	modelMu.RLock()
	s := AppState{CurrentProfileID: currentProfileID, LastSelectedID: selectedProfileID}
	modelMu.RUnlock()
	b, _ := json.MarshalIndent(s, "", "  ")
	_ = os.MkdirAll(filepath.Dir(statePath()), 0755)
	_ = os.WriteFile(statePath(), b, 0644)
}

func loadProfilesFromDisk() ([]ProfileMeta, error) {
	entries, err := os.ReadDir(profilesRoot())
	if err != nil {
		if os.IsNotExist(err) {
			return []ProfileMeta{}, nil
		}
		return nil, err
	}
	out := []ProfileMeta{}
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		b, err := os.ReadFile(filepath.Join(profilesRoot(), e.Name(), "profile.json"))
		if err != nil {
			continue
		}
		var p ProfileMeta
		if json.Unmarshal(b, &p) != nil {
			continue
		}
		if p.ID == "" {
			p.ID = e.Name()
		}
		if p.Name == "" {
			p.Name = p.ID
		}
		if p.Mode != "randomizer" {
			p.Mode = "normal"
		}
		out = append(out, p)
	}
	sort.Slice(out, func(i, j int) bool {
		ti, ei := time.Parse(time.RFC3339, out[i].CreatedAt)
		tj, ej := time.Parse(time.RFC3339, out[j].CreatedAt)
		if ei == nil && ej == nil {
			return ti.Before(tj)
		}
		return strings.ToLower(out[i].Name) < strings.ToLower(out[j].Name)
	})
	return out, nil
}

func saveProfileMeta(p ProfileMeta) error {
	if p.ID == "" {
		return errors.New("ID de profil vide")
	}
	if p.CreatedAt == "" {
		p.CreatedAt = time.Now().Format(time.RFC3339)
	}
	if err := os.MkdirAll(profileDir(p.ID), 0755); err != nil {
		return err
	}
	b, _ := json.MarshalIndent(p, "", "  ")
	return os.WriteFile(profileMetaPath(p.ID), b, 0644)
}

func findProfile(id string) (ProfileMeta, bool) {
	modelMu.RLock()
	defer modelMu.RUnlock()
	for _, p := range profilesModel {
		if p.ID == id {
			return p, true
		}
	}
	return ProfileMeta{}, false
}

func nextProfileID() (string, error) {
	entries, err := os.ReadDir(profilesRoot())
	if err != nil && !os.IsNotExist(err) {
		return "", err
	}
	maxN := 0
	for _, e := range entries {
		if !e.IsDir() || !strings.HasPrefix(e.Name(), "profile-") {
			continue
		}
		n, err := strconv.Atoi(strings.TrimPrefix(e.Name(), "profile-"))
		if err == nil && n > maxN {
			maxN = n
		}
	}
	return fmt.Sprintf("profile-%03d", maxN+1), nil
}

// ----------------------------- Logging/progress -----------------------------
func logLine(text string) {
	_ = os.MkdirAll(dataRoot(), 0755)
	f, err := os.OpenFile(logPath(), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = fmt.Fprintf(f, "%s  %s\r\n", time.Now().Format("2006-01-02 15:04:05"), text)
}

type ProfileEvent struct {
	Time   string `json:"time"`
	Kind   string `json:"kind"`
	Detail string `json:"detail"`
}

func appendProfileEvent(profileID, kind, detail string) {
	if strings.TrimSpace(profileID) == "" {
		return
	}
	_ = os.MkdirAll(profileDir(profileID), 0755)
	e := ProfileEvent{Time: time.Now().Format(time.RFC3339), Kind: kind, Detail: detail}
	b, _ := json.Marshal(e)
	f, err := os.OpenFile(profileHistoryPath(profileID), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = f.Write(append(b, '\n'))
}

func readProfileEvents(profileID string, limit int) []ProfileEvent {
	b, err := os.ReadFile(profileHistoryPath(profileID))
	if err != nil {
		return nil
	}
	lines := strings.Split(strings.TrimSpace(string(b)), "\n")
	out := []ProfileEvent{}
	for _, line := range lines {
		if strings.TrimSpace(line) == "" {
			continue
		}
		var e ProfileEvent
		if json.Unmarshal([]byte(line), &e) == nil {
			out = append(out, e)
		}
	}
	if limit > 0 && len(out) > limit {
		out = out[len(out)-limit:]
	}
	for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
		out[i], out[j] = out[j], out[i]
	}
	return out
}

func postProgress(text string, percent int) {
	if percent < 0 {
		percent = 0
	}
	if percent > 100 {
		percent = 100
	}
	progressMu.Lock()
	pendingProgress = taskProgress{Text: text, Percent: percent}
	progressMu.Unlock()
	logLine(fmt.Sprintf("%d%% - %s", percent, text))
	if mainHwnd != 0 {
		pPostMessageW.Call(mainHwnd, WM_APP_PROGRESS, 0, 0)
	}
}

// ----------------------------- File helpers ---------------------------------
func fileExists(path string) bool { st, err := os.Stat(path); return err == nil && !st.IsDir() }
func dirExists(path string) bool  { st, err := os.Stat(path); return err == nil && st.IsDir() }
func pathExists(path string) bool { _, err := os.Stat(path); return err == nil }

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	st, err := in.Stat()
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		return err
	}
	out, err := os.OpenFile(dst, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, st.Mode())
	if err != nil {
		return err
	}
	_, cErr := io.Copy(out, in)
	closeErr := out.Close()
	if cErr != nil {
		return cErr
	}
	if closeErr != nil {
		return closeErr
	}
	return os.Chtimes(dst, st.ModTime(), st.ModTime())
}

func copyTree(src, dst string) error {
	return filepath.Walk(src, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		rel, err := filepath.Rel(src, path)
		if err != nil {
			return err
		}
		target := filepath.Join(dst, rel)
		if info.IsDir() {
			return os.MkdirAll(target, info.Mode())
		}
		return copyFile(path, target)
	})
}

func uniqueSiblingPath(dst, tag string) string {
	stamp := time.Now().Format("2006-01-02_15-04-05.000")
	base := dst + ".__" + tag + "__" + stamp
	candidate := base
	for i := 2; pathExists(candidate); i++ {
		candidate = fmt.Sprintf("%s_%d", base, i)
	}
	return candidate
}

func renameWithRetry(src, dst string) error {
	var last error
	for i := 0; i < 5; i++ {
		if err := os.Rename(src, dst); err == nil {
			return nil
		} else {
			last = err
		}
		time.Sleep(time.Duration(250*(i+1)) * time.Millisecond)
	}
	return last
}

func removeAllWithRetry(path string) error {
	if !pathExists(path) {
		return nil
	}
	var last error
	for i := 0; i < 5; i++ {
		if err := os.RemoveAll(path); err == nil && !pathExists(path) {
			return nil
		} else if err != nil {
			last = err
		} else {
			last = fmt.Errorf("le dossier existe encore après suppression")
		}
		time.Sleep(time.Duration(250*(i+1)) * time.Millisecond)
	}
	return last
}

// activatePreparedDirectory replaces dst with a fully prepared temporary directory.
// The previous destination is first secured under a unique timestamped name. If Windows
// refuses to rename the destination because a process keeps a folder handle open, the
// function falls back to a full safety copy before trying an in-place removal.
func activatePreparedDirectory(tmp, dst string) error {
	if !dirExists(tmp) {
		return fmt.Errorf("copie temporaire introuvable : %s", tmp)
	}
	old := uniqueSiblingPath(dst, "old")
	secured := false
	if dirExists(dst) {
		if err := renameWithRetry(dst, old); err == nil {
			secured = true
		} else {
			// A directory rename can fail on Windows even when the save files themselves are
			// writable. Preserve the whole folder first, then replace it without relying on
			// a directory rename.
			if err2 := copyTree(dst, old); err2 != nil {
				return fmt.Errorf("impossible de sécuriser l'ancienne destination. Ferme Elden Ring et tout programme utilisant la sauvegarde, puis réessaie : %w", err)
			}
			secured = true
			if err2 := removeAllWithRetry(dst); err2 != nil {
				return fmt.Errorf("ancienne destination sauvegardée dans %s, mais impossible de libérer le dossier actif. Ferme Elden Ring/Steam Cloud ou tout programme qui utilise ce dossier : %w", old, err2)
			}
		}
	}
	if err := renameWithRetry(tmp, dst); err != nil {
		// Best-effort rollback. Never delete the secured copy if rollback fails.
		_ = removeAllWithRetry(dst)
		if secured && dirExists(old) {
			if rerr := renameWithRetry(old, dst); rerr != nil {
				_ = copyTree(old, dst)
			}
		}
		return fmt.Errorf("impossible d'activer la nouvelle copie : %w", err)
	}
	if secured && dirExists(old) {
		if err := removeAllWithRetry(old); err != nil {
			// Do not fail a successful profile switch only because Windows kept the safety
			// folder open. It has a unique timestamp, so it cannot collide with a future run.
			logLine("nettoyage différé de " + old + " : " + err.Error())
		}
	}
	return nil
}

func mirrorCopy(src, dst string) error {
	saveStorageMu.Lock()
	defer saveStorageMu.Unlock()
	if fileExists(filepath.Join(src, saveArchiveName)) {
		expanded, cleanup, err := expandStoredSave(src)
		if err != nil {
			return err
		}
		defer cleanup()
		src = expanded
	}
	if !dirExists(src) {
		return fmt.Errorf("dossier source introuvable : %s", src)
	}
	if !fileExists(filepath.Join(src, "ER0000.sl2")) {
		return fmt.Errorf("ER0000.sl2 introuvable dans : %s", src)
	}
	tmp := uniqueSiblingPath(dst, "tmp")
	if err := copyTree(src, tmp); err != nil {
		_ = removeAllWithRetry(tmp)
		return err
	}
	if !fileExists(filepath.Join(tmp, "ER0000.sl2")) {
		_ = removeAllWithRetry(tmp)
		return errors.New("ER0000.sl2 absent après la copie temporaire")
	}
	if err := activatePreparedDirectory(tmp, dst); err != nil {
		_ = removeAllWithRetry(tmp)
		return err
	}
	return nil
}

func replaceDirectoryFromSource(src, dst string) error {
	if !dirExists(src) {
		return fmt.Errorf("dossier source introuvable : %s", src)
	}
	tmp := uniqueSiblingPath(dst, "tmp")
	if err := copyTree(src, tmp); err != nil {
		_ = removeAllWithRetry(tmp)
		return err
	}
	if err := activatePreparedDirectory(tmp, dst); err != nil {
		_ = removeAllWithRetry(tmp)
		return err
	}
	return nil
}

func uniqueSnapshotName() string {
	base := time.Now().Format("2006-01-02_15-04-05")
	name := base
	for i := 2; ; i++ {
		if !dirExists(filepath.Join(dataRoot(), ".namecheck", name)) {
			return name
		}
		name = fmt.Sprintf("%s_%d", base, i)
	}
}

func nextSnapshotDir(profileID string) string {
	base := time.Now().Format("2006-01-02_15-04-05")
	name := base
	for i := 2; ; i++ {
		p := filepath.Join(profileSavesDir(profileID), name)
		if !pathExists(p) {
			return p
		}
		name = fmt.Sprintf("%s_%d", base, i)
	}
}

func listProfileSaves(profileID string) []SaveInfo {
	root := profileSavesDir(profileID)
	out := []SaveInfo{}
	entries, err := os.ReadDir(root)
	if err != nil {
		return out
	}
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		candidate := filepath.Join(root, e.Name(), cfg.SteamID)
		if !storedSaveExists(candidate) {
			continue
		}
		t := parseSnapshotTime(e.Name())
		label := displaySnapshotLabel(e.Name(), t)
		if !fileExists(filepath.Join(candidate, "ER0000.sl2")) {
			label += L(" · compressée", " · compressed")
		}
		out = append(out, SaveInfo{Label: label, Path: candidate, Date: t})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Date.After(out[j].Date) })
	return out
}

func scanProfileViewCache(p ProfileMeta) ProfileViewCache {
	return ProfileViewCache{
		Saves:     listProfileSaves(p.ID),
		SeedReady: validateRandomizerPackage(profileRandoDir(p.ID)) == nil,
	}
}

func rebuildProfileCacheForProfiles(ps []ProfileMeta) {
	fresh := make(map[string]ProfileViewCache, len(ps))
	for _, p := range ps {
		fresh[p.ID] = scanProfileViewCache(p)
	}
	cacheMu.Lock()
	profileCache = fresh
	cacheMu.Unlock()
}

func getProfileViewCache(id string) ProfileViewCache {
	cacheMu.RLock()
	c, ok := profileCache[id]
	cacheMu.RUnlock()
	if !ok {
		return ProfileViewCache{}
	}
	c.Saves = append([]SaveInfo(nil), c.Saves...)
	return c
}

func parseSnapshotTime(name string) time.Time {
	candidates := []string{"2006-01-02_15-04-05", "02-01-06"}
	raw := name
	if strings.HasPrefix(raw, "important_") {
		raw = strings.TrimPrefix(raw, "important_")
	}
	if len(raw) > 19 && strings.Count(raw, "_") >= 2 {
		raw = raw[:19]
	}
	for _, layout := range candidates {
		if t, err := time.ParseInLocation(layout, raw, time.Local); err == nil {
			return t
		}
	}
	return time.Unix(0, 0)
}
func displaySnapshotLabel(name string, t time.Time) string {
	if strings.HasPrefix(name, "important_") {
		rest := strings.TrimPrefix(name, "important_")
		label := "Important"
		if len(rest) > 20 {
			label = strings.TrimPrefix(rest[20:], "_")
		}
		label = strings.ReplaceAll(label, "_", " ")
		if t.Unix() > 0 {
			return "★ " + label + " — " + t.Format("02-01-06 15:04")
		}
		return "★ " + label
	}
	if t.Unix() <= 0 {
		return name
	}
	if strings.Contains(name, "_") && len(name) >= 19 {
		return t.Format("02-01-06 15:04:05")
	}
	return t.Format("02-01-06")
}

func backupCurrentProfile(profileID string) (string, error) {
	if profileID == "" {
		return "", errors.New("aucun profil actuel")
	}
	if _, ok := findProfile(profileID); !ok {
		return "", errors.New("profil actuel introuvable")
	}
	src := appDataSave()
	if !fileExists(filepath.Join(src, "ER0000.sl2")) {
		return "", fmt.Errorf("ER0000.sl2 est introuvable dans %s", src)
	}
	destRoot := nextSnapshotDir(profileID)
	dest := filepath.Join(destRoot, cfg.SteamID)
	if err := mirrorCopy(src, dest); err != nil {
		return "", err
	}
	return displaySnapshotLabel(filepath.Base(destRoot), parseSnapshotTime(filepath.Base(destRoot))), nil
}

func backupCurrentProfileNamed(profileID, name string) (string, error) {
	name = strings.TrimSpace(name)
	if name == "" {
		return "", errors.New(L("le nom du point est vide", "named point is empty"))
	}
	if profileID == "" {
		return "", errors.New(L("aucun profil actuel", "no current profile"))
	}
	src := appDataSave()
	if !fileExists(filepath.Join(src, "ER0000.sl2")) {
		return "", fmt.Errorf("ER0000.sl2 introuvable dans %s", src)
	}
	folder := "important_" + time.Now().Format("2006-01-02_15-04-05") + "_" + sanitizeFileName(name)
	destRoot := filepath.Join(profileSavesDir(profileID), folder)
	for n := 2; pathExists(destRoot); n++ {
		destRoot = filepath.Join(profileSavesDir(profileID), fmt.Sprintf("%s_%d", folder, n))
	}
	dest := filepath.Join(destRoot, cfg.SteamID)
	if err := mirrorCopy(src, dest); err != nil {
		return "", err
	}
	label := displaySnapshotLabel(filepath.Base(destRoot), parseSnapshotTime(filepath.Base(destRoot)))
	appendProfileEvent(profileID, "named-backup", label)
	return label, nil
}

func emergencyBackup() (string, error) {
	src := appDataSave()
	if !fileExists(filepath.Join(src, "ER0000.sl2")) {
		return "", nil
	}
	root := filepath.Join(emergencyRoot(), time.Now().Format("2006-01-02_15-04-05"))
	dest := filepath.Join(root, cfg.SteamID)
	if err := mirrorCopy(src, dest); err != nil {
		return "", err
	}
	return root, nil
}

// ----------------------------- Legacy migration -----------------------------
func legacyValidSaves(root string) []struct {
	Name, Path string
	Date       time.Time
} {
	out := []struct {
		Name, Path string
		Date       time.Time
	}{}
	entries, err := os.ReadDir(root)
	if err == nil {
		for _, e := range entries {
			if !e.IsDir() {
				continue
			}
			t, err := time.ParseInLocation("02-01-06", e.Name(), time.Local)
			if err != nil {
				continue
			}
			p := filepath.Join(root, e.Name(), cfg.SteamID)
			if fileExists(filepath.Join(p, "ER0000.sl2")) {
				out = append(out, struct {
					Name, Path string
					Date       time.Time
				}{e.Name(), p, t})
			}
		}
	}
	legacy := filepath.Join(root, cfg.SteamID)
	if fileExists(filepath.Join(legacy, "ER0000.sl2")) {
		st, _ := os.Stat(filepath.Join(legacy, "ER0000.sl2"))
		t := time.Unix(0, 0)
		if st != nil {
			t = st.ModTime()
		}
		out = append(out, struct {
			Name, Path string
			Date       time.Time
		}{"ancienne-save", legacy, t})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Date.After(out[j].Date) })
	return out
}

func importTemplateIfNeeded() (bool, error) {
	if fileExists(filepath.Join(templateRoot(), "ER0000.sl2")) {
		return false, nil
	}
	root := filepath.Join(cfg.LegacySaveRoot, "save-base", "save-vide")
	saves := legacyValidSaves(root)
	if len(saves) == 0 {
		return false, nil
	}
	if err := mirrorCopy(saves[0].Path, templateRoot()); err != nil {
		return false, err
	}
	return true, nil
}

func importLegacyProfile(name, mode, seed, legacyRoot string) (ProfileMeta, bool, error) {
	saves := legacyValidSaves(legacyRoot)
	if len(saves) == 0 {
		return ProfileMeta{}, false, nil
	}
	id, err := nextProfileID()
	if err != nil {
		return ProfileMeta{}, false, err
	}
	p := ProfileMeta{ID: id, Name: name, Mode: mode, Seed: seed, CreatedAt: time.Now().Format(time.RFC3339)}
	if err := saveProfileMeta(p); err != nil {
		return ProfileMeta{}, false, err
	}
	for i, s := range saves {
		folderName := s.Name
		if folderName == "ancienne-save" {
			folderName = fmt.Sprintf("legacy-%02d", i+1)
		}
		dest := filepath.Join(profileSavesDir(id), folderName, cfg.SteamID)
		if err := mirrorCopy(s.Path, dest); err != nil {
			return ProfileMeta{}, false, err
		}
	}
	return p, true, nil
}

func runMigration() (string, error) {
	if fileExists(migrationPath()) {
		return "", nil
	}
	_ = os.MkdirAll(filepath.Dir(migrationPath()), 0755)
	info := MigrationInfo{Version: 10, CompletedAt: time.Now().Format(time.RFC3339)}
	info.TemplateImported = fileExists(filepath.Join(templateRoot(), "ER0000.sl2"))

	// Public build: no PC-specific legacy folder is assumed. If an older config
	// explicitly contains a legacySaveRoot, import remains available as a best effort.
	if strings.TrimSpace(cfg.LegacySaveRoot) != "" && dirExists(cfg.LegacySaveRoot) {
		existing, _ := loadProfilesFromDisk()
		if len(existing) == 0 {
			postProgress(L("Initialisation : import des anciennes saves normales…", "Initialization: importing old normal saves…"), 28)
			if p, ok, err := importLegacyProfile(L("Base principale", "Main base profile"), "normal", "", filepath.Join(cfg.LegacySaveRoot, "save-base", "save-principale")); err != nil {
				return "", err
			} else if ok {
				info.ImportedProfiles = append(info.ImportedProfiles, p.Name)
			}
			postProgress(L("Initialisation : import de l'ancienne save Randomizer…", "Initialization: importing old Randomizer save…"), 38)
			if p, ok, err := importLegacyProfile("Randomizer seed-1", "randomizer", "seed-1", filepath.Join(cfg.LegacySaveRoot, "save-rando", "seed-1")); err != nil {
				return "", err
			} else if ok {
				info.ImportedProfiles = append(info.ImportedProfiles, p.Name)
				if cfg.UseRandomizer {
					if err := importRandomizerFilesIntoProfile(p.ID, "seed-1", true); err == nil {
						info.RandomizerCaptured = true
					}
				}
			}
		}
	}
	b, _ := json.MarshalIndent(info, "", "  ")
	if err := os.WriteFile(migrationPath(), b, 0644); err != nil {
		return "", err
	}
	if len(info.ImportedProfiles) == 0 {
		return "", nil
	}
	return L("Anciennes sauvegardes importées : ", "Old saves imported: ") + strings.Join(info.ImportedProfiles, ", "), nil
}

// ----------------------------- Randomizer transfer bridge ------------------
func restoreOriginalTransfer(randApp string) error {
	randApp = strings.TrimSpace(randApp)
	if randApp == "" {
		return nil
	}
	backup := filepath.Join(randApp, "transfer.original.ProfileManager.bat")
	transfer := filepath.Join(randApp, "transfer.bat")
	if !fileExists(backup) {
		return nil
	}
	return copyFile(backup, transfer)
}

func isManagedRandomizerRootFile(name string) bool {
	low := strings.ToLower(name)

	if strings.HasPrefix(low, "randomizer") {
		return strings.HasSuffix(low, ".dll") || strings.HasSuffix(low, ".ini") || strings.HasSuffix(low, ".txt")
	}
	return false
}

// The original working transfer.bat copies every DLL/INI/TXT found in the
// Randomizer's dedicated dll folder. That folder belongs to the Randomizer, so
// it is safe to capture all files with those extensions from there. When the
// source is ModEngine itself we stay conservative and only capture known
// Randomizer/helper files, so unrelated user mods are left alone.
func isRandomizerDLLFolderPayload(name string) bool {
	if isSeparateTransmogFile(name) {
		return false
	}
	switch strings.ToLower(filepath.Ext(name)) {
	case ".dll", ".ini", ".txt":
		return true
	default:
		return false
	}
}

func findRandomizerDataRoot(root string) string {
	for _, candidate := range []string{filepath.Join(root, "mod"), root, filepath.Join(root, "randapp")} {
		if fileExists(filepath.Join(candidate, "regulation.bin")) {
			return candidate
		}
	}
	return ""
}

// copyRandomizerPackage captures everything this manager is responsible for from an
// already working Randomizer/ModEngine setup. It intentionally ignores unrelated mods.
func copyRandomizerPackage(root, dest string) error {
	root = strings.TrimSpace(root)
	if !dirExists(root) {
		return fmt.Errorf("dossier Randomizer introuvable : %s", root)
	}
	dataRoot := findRandomizerDataRoot(root)
	if dataRoot == "" {
		return fmt.Errorf("regulation.bin Randomizer introuvable dans %s", root)
	}
	tmp := uniqueSiblingPath(dest, "tmp")
	if err := os.MkdirAll(tmp, 0755); err != nil {
		return err
	}
	fail := func(err error) error {
		_ = removeAllWithRetry(tmp)
		return err
	}
	if err := copyFile(filepath.Join(dataRoot, "regulation.bin"), filepath.Join(tmp, "regulation.bin")); err != nil {
		return fail(err)
	}
	for _, n := range managedRandoDirs {
		for _, candidateRoot := range []string{dataRoot} {
			src := filepath.Join(candidateRoot, n)
			if dirExists(src) {
				if err := copyTree(src, filepath.Join(tmp, n)); err != nil {
					return fail(err)
				}
				break
			}
		}
	}
	// Keep seed/config metadata with the seed. config_eldenring.toml may be modified by
	// an existing Randomizer setup, so it must travel with that seed instead of being
	// rebuilt from guesses.
	for _, name := range []string{"config_eldenringrandomizer.toml", "config_eldenring.toml"} {
		for _, candidateRoot := range []string{root, dataRoot} {
			src := filepath.Join(candidateRoot, name)
			if fileExists(src) {
				_ = os.MkdirAll(filepath.Join(tmp, "metadata"), 0755)
				if err := copyFile(src, filepath.Join(tmp, "metadata", name)); err != nil {
					return fail(err)
				}
				break
			}
		}
	}
	// DLL/helper files. Match the user's known-good transfer.bat exactly when a
	// dedicated Randomizer dll folder exists: copy every *.dll, *.ini and *.txt.
	// For an import from an already configured ModEngine root, only copy the
	// Randomizer/helper files so unrelated third-party mods are never captured.
	dllFolder := filepath.Join(dataRoot, "dll")
	if dirExists(dllFolder) {
		entries, err := os.ReadDir(dllFolder)
		if err != nil {
			return fail(err)
		}
		for _, e := range entries {
			if e.IsDir() || !isRandomizerDLLFolderPayload(e.Name()) {
				continue
			}
			_ = os.MkdirAll(filepath.Join(tmp, "root"), 0755)
			if err := copyFile(filepath.Join(dllFolder, e.Name()), filepath.Join(tmp, "root", e.Name())); err != nil {
				return fail(err)
			}
		}
	} else {
		entries, err := os.ReadDir(root)
		if err == nil {
			for _, e := range entries {
				if e.IsDir() || !isManagedRandomizerRootFile(e.Name()) {
					continue
				}
				_ = os.MkdirAll(filepath.Join(tmp, "root"), 0755)
				if err := copyFile(filepath.Join(root, e.Name()), filepath.Join(tmp, "root", e.Name())); err != nil {
					return fail(err)
				}
			}
		}
	}
	if err := recordRandomizerSourceShape(dataRoot, tmp); err != nil {
		return fail(err)
	}
	if err := validateRandomizerPackage(tmp); err != nil {
		return fail(err)
	}
	if err := activatePreparedDirectory(tmp, dest); err != nil {
		return fail(err)
	}
	return nil
}

func copyRandomizerFromSeedImport(dest string) error {
	return copyRandomizerPackage(seedImportRoot(), dest)
}

// ----------------------------- Randomizer management ------------------------
var managedRandoDirs = []string{"chr", "diste", "event", "map", "msg", "script", "sfx"}

func removePathIfExists(p string) error {
	st, err := os.Stat(p)
	if os.IsNotExist(err) {
		return nil
	}
	if err != nil {
		return err
	}
	if st.IsDir() {
		return os.RemoveAll(p)
	}
	return os.Remove(p)
}

func captureBaseModState() error {
	if !cfg.UseModEngine || !dirExists(cfg.ModEngine) {
		return nil
	}
	tmp := uniqueSiblingPath(baseModsRoot(), "tmp")
	if err := os.MkdirAll(filepath.Join(tmp, "mod"), 0755); err != nil {
		return err
	}
	md := modDir()
	// Only the paths the Randomizer may replace are captured. Other user mods stay where
	// they are and are never managed by this application.
	for _, n := range managedRandoDirs {
		src := filepath.Join(md, n)
		if dirExists(src) {
			if err := copyTree(src, filepath.Join(tmp, "mod", n)); err != nil {
				_ = removeAllWithRetry(tmp)
				return err
			}
		}
	}
	if fileExists(filepath.Join(md, "regulation.bin")) {
		if err := copyFile(filepath.Join(md, "regulation.bin"), filepath.Join(tmp, "mod", "regulation.bin")); err != nil {
			_ = removeAllWithRetry(tmp)
			return err
		}
	}
	if entries, err := os.ReadDir(cfg.ModEngine); err == nil {
		for _, e := range entries {
			if e.IsDir() || !isManagedRandomizerRootFile(e.Name()) {
				continue
			}
			_ = os.MkdirAll(filepath.Join(tmp, "root"), 0755)
			if err := copyFile(filepath.Join(cfg.ModEngine, e.Name()), filepath.Join(tmp, "root", e.Name())); err != nil {
				_ = removeAllWithRetry(tmp)
				return err
			}
		}
	}
	if fileExists(modEngineConfigPath()) {
		if err := copyFile(modEngineConfigPath(), filepath.Join(tmp, "config_eldenring.toml")); err != nil {
			_ = removeAllWithRetry(tmp)
			return err
		}
		_ = os.MkdirAll(modEngineReferenceRoot(), 0755)
		// The user's own config is kept separately and never overwritten automatically.
		if !fileExists(userModEngineConfigPath()) {
			_ = copyFile(modEngineConfigPath(), userModEngineConfigPath())
		}
	}
	meta := map[string]any{
		"capturedAt":               time.Now().Format(time.RFC3339),
		"modEngine":                cfg.ModEngine,
		"randomizerStateAtCapture": detectRandoState(),
	}
	b, _ := json.MarshalIndent(meta, "", "  ")
	_ = os.WriteFile(filepath.Join(tmp, "baseline.json"), b, 0644)
	if err := activatePreparedDirectory(tmp, baseModsRoot()); err != nil {
		_ = removeAllWithRetry(tmp)
		return err
	}
	return nil
}

func restoreTrustedBaseModState() error {
	if !cfg.UseModEngine {
		return nil
	}
	if err := cleanRandomizerFromModEngine(); err != nil {
		return err
	}
	root := filepath.Join(baseModsRoot(), "mod")
	if dirExists(root) {
		entries, err := os.ReadDir(root)
		if err != nil {
			return err
		}
		for _, e := range entries {
			src := filepath.Join(root, e.Name())
			dst := filepath.Join(modDir(), e.Name())
			if e.IsDir() {
				if err := copyTree(src, dst); err != nil {
					return err
				}
			} else {
				if err := copyFile(src, dst); err != nil {
					return err
				}
			}
		}
	}
	rootFiles := filepath.Join(baseModsRoot(), "root")
	if dirExists(rootFiles) {
		entries, _ := os.ReadDir(rootFiles)
		for _, e := range entries {
			if e.IsDir() || isSeparateTransmogFile(e.Name()) {
				continue
			}
			if err := copyFile(filepath.Join(rootFiles, e.Name()), filepath.Join(cfg.ModEngine, e.Name())); err != nil {
				return err
			}
		}
	}
	// Restore the user's original ModEngine config when available. The pristine bundled
	// config is only a fallback for a clean/no-custom-config installation.
	configSrc := filepath.Join(baseModsRoot(), "config_eldenring.toml")
	if !fileExists(configSrc) {
		if fileExists(userModEngineConfigPath()) {
			configSrc = userModEngineConfigPath()
		} else if fileExists(vanillaModEngineConfigPath()) {
			configSrc = vanillaModEngineConfigPath()
		}
	}
	if fileExists(configSrc) {
		if err := copyFile(configSrc, modEngineConfigPath()); err != nil {
			return err
		}
	}
	return nil
}

func cleanRandomizerFromModEngine() error {
	md := modDir()
	for _, n := range managedRandoDirs {
		if err := removePathIfExists(filepath.Join(md, n)); err != nil {
			return err
		}
		if err := removePathIfExists(filepath.Join(md, n+".RANDO_OFF")); err != nil {
			return err
		}
	}
	if err := removePathIfExists(filepath.Join(md, "regulation.bin")); err != nil {
		return err
	}
	if err := removePathIfExists(filepath.Join(md, "regulation.bin.RANDO_OFF")); err != nil {
		return err
	}

	patterns := []string{"Randomizer*.dll", "Randomizer*.ini", "Randomizer*.txt", "Randomizer*.dll.bak", "Randomizer*.ini.bak", "Randomizer*.txt.bak"}
	for _, pat := range patterns {
		matches, _ := filepath.Glob(filepath.Join(cfg.ModEngine, pat))
		for _, p := range matches {
			if err := removePathIfExists(p); err != nil {
				return err
			}
		}
	}
	return nil
}

func detectRandoState() string {
	if validateNormalEnvironment() == nil {
		return L("DÉSACTIVÉ", "DISABLED")
	}
	active, legacyOff := 0, 0
	md := modDir()
	for _, n := range managedRandoDirs {
		if pathExists(filepath.Join(md, n)) {
			active++
		}
		if pathExists(filepath.Join(md, n+".RANDO_OFF")) {
			legacyOff++
		}
	}
	if fileExists(filepath.Join(md, "regulation.bin")) {
		active++
	}
	if fileExists(filepath.Join(md, "regulation.bin.RANDO_OFF")) {
		legacyOff++
	}
	a, _ := filepath.Glob(filepath.Join(cfg.ModEngine, "Randomizer*.dll"))
	active += len(a)
	b, _ := filepath.Glob(filepath.Join(cfg.ModEngine, "Randomizer*.dll.bak"))
	legacyOff += len(b)
	if active > 0 && legacyOff > 0 {
		return L("MIXTE / À VÉRIFIER", "MIXED / CHECK")
	}
	if active > 0 {
		return L("ACTIF", "ACTIVE")
	}
	if legacyOff > 0 {
		return L("DÉSACTIVÉ (ancien format)", "DISABLED (legacy format)")
	}
	return L("DÉSACTIVÉ", "DISABLED")
}

func copyRandomizerFromRandApp(dest string) error {
	return copyRandomizerPackage(cfg.RandApp, dest)
}

func copyRandomizerFromModEngine(dest string) error {
	return copyRandomizerPackage(cfg.ModEngine, dest)
}

type randomizerImportSource struct {
	Path  string
	Label string
}

func availableRandomizerImportSources() []randomizerImportSource {
	var out []randomizerImportSource
	if findRandomizerDataRoot(cfg.RandApp) != "" {
		out = append(out, randomizerImportSource{cfg.RandApp, L("EldenRingRandomizer (fichiers générés actuels)", "EldenRingRandomizer (current generated files)")})
	}
	if findRandomizerDataRoot(cfg.ModEngine) != "" {
		out = append(out, randomizerImportSource{cfg.ModEngine, L("ModEngine 2 (Randomizer déjà installé)", "ModEngine 2 (already installed Randomizer)")})
	}
	if findRandomizerDataRoot(seedImportRoot()) != "" {
		out = append(out, randomizerImportSource{seedImportRoot(), L("ancien dossier seed-import", "legacy seed-import folder")})
	}
	return out
}

func currentRandomizerImportSource() (string, string) {
	sources := availableRandomizerImportSources()
	if len(sources) == 0 {
		return "", ""
	}
	if len(sources) > 1 {
		return sources[0].Path, L("plusieurs sources détectées", "multiple sources detected")
	}
	return sources[0].Path, sources[0].Label
}

// chooseRandomizerImportSource avoids guessing when the Randomizer folder and ModEngine 2
// both contain a seed (a very common case for existing installations).
func chooseRandomizerImportSource() (string, string, bool) {
	sources := availableRandomizerImportSources()
	if len(sources) == 0 {
		return "", "", false
	}
	if len(sources) == 1 {
		return sources[0].Path, sources[0].Label, true
	}
	// Prefer an explicit choice between the two meaningful live locations. Legacy seed-import
	// remains an automatic fallback only when it is the sole available source.
	var randSrc, meSrc *randomizerImportSource
	for i := range sources {
		s := &sources[i]
		if strings.EqualFold(filepath.Clean(s.Path), filepath.Clean(cfg.RandApp)) {
			randSrc = s
		}
		if strings.EqualFold(filepath.Clean(s.Path), filepath.Clean(cfg.ModEngine)) {
			meSrc = s
		}
	}
	if randSrc != nil && meSrc != nil {
		r := messageBox(L("Choisir la source du seed", "Choose seed source"),
			L("Deux seeds/configurations sont détectées.\n\nOUI = prendre les fichiers actuellement générés dans EldenRingRandomizer.\nNON = prendre le Randomizer actuellement installé dans ModEngine 2 (à vérifier).\nANNULER = ne rien importer.\n\nAucun original ne sera supprimé.",
				"Two seeds/setups were detected.\n\nYES = use the files currently generated in EldenRingRandomizer.\nNO = use the Randomizer currently installed in ModEngine 2 (to be checked).\nCANCEL = import nothing.\n\nNo original will be deleted."), MB_YESNO|MB_ICONQUESTION)
		if r == IDYES {
			return randSrc.Path, randSrc.Label, true
		}
		if r == IDNO {
			return meSrc.Path, meSrc.Label, true
		}
		return "", "", false
	}

	return sources[0].Path, sources[0].Label, true
}

func storeSeedInLibrary(seed, profileID string) error {
	seed = strings.TrimSpace(seed)
	if seed == "" {
		return nil
	}
	src := profileRandoDir(profileID)
	if err := validateRandomizerPackage(src); err != nil {
		return err
	}
	return replaceDirectoryFromSource(src, seedLibraryDir(seed))
}

func attachLibrarySeedToProfile(profileID, seed string) error {
	seed = strings.TrimSpace(seed)
	if seed == "" {
		return errors.New(L("nom de seed vide", "empty seed name"))
	}
	src := seedLibraryDir(seed)
	if err := validateRandomizerPackage(src); err != nil {
		return err
	}
	if err := replaceDirectoryFromSource(src, profileRandoDir(profileID)); err != nil {
		return err
	}
	b, err := os.ReadFile(profileMetaPath(profileID))
	if err != nil {
		return err
	}
	var p ProfileMeta
	if err := json.Unmarshal(b, &p); err != nil {
		return err
	}
	p.Seed = seed
	return saveProfileMeta(p)
}

func importRandomizerFilesIntoProfile(profileID, seed string, migration bool) error {
	dest := profileRandoDir(profileID)
	var err error
	if migration {
		err = copyRandomizerFromSeedImport(dest)
		if err != nil {
			err = copyRandomizerFromRandApp(dest)
		}
		if err != nil {
			err = copyRandomizerFromModEngine(dest)
		}
	} else {
		source, _ := currentRandomizerImportSource()
		if source == "" {
			return errors.New(L("aucune seed Randomizer détectée. Génère-la dans EldenRingRandomizer ou laisse ta seed actuelle dans ModEngine 2, puis réessaie", "no Randomizer seed detected. Generate it in EldenRingRandomizer or leave your current seed in ModEngine 2, then try again"))
		}
		err = copyRandomizerPackage(source, dest)
	}
	if err != nil {
		return err
	}
	b, err := os.ReadFile(profileMetaPath(profileID))
	if err != nil {
		return err
	}
	var p ProfileMeta
	if err := json.Unmarshal(b, &p); err != nil {
		return err
	}
	if strings.TrimSpace(seed) != "" {
		p.Seed = strings.TrimSpace(seed)
	}
	if err := saveProfileMeta(p); err != nil {
		return err
	}
	if p.Seed != "" {
		if err := storeSeedInLibrary(p.Seed, profileID); err != nil {
			logLine("seed library: " + err.Error())
		}
	}
	return nil
}

func validateRandoProfile(p ProfileMeta) error {
	if p.Mode != "randomizer" {
		return nil
	}
	return validateRandomizerPackage(profileRandoDir(p.ID))
}

// Deploy only the selected seed, then validate it before allowing a launch.
func deployRandomizerProfile(p ProfileMeta) error {
	if err := validateRandoProfile(p); err != nil {
		return err
	}
	if p.Mode != "randomizer" {
		return errors.New("profil Randomizer requis")
	}
	if err := removePreviousSeedForDeployment(); err != nil {
		return err
	}
	src := profileRandoDir(p.ID)
	md := modDir()
	if err := os.MkdirAll(md, 0755); err != nil {
		return err
	}
	if err := copyFile(filepath.Join(src, "regulation.bin"), filepath.Join(md, "regulation.bin")); err != nil {
		return err
	}
	for _, n := range managedRandoDirs {
		srcDir := filepath.Join(src, n)
		if dirExists(srcDir) {
			if err := copyTree(srcDir, filepath.Join(md, n)); err != nil {
				return err
			}
		}
	}
	if dirExists(filepath.Join(src, "root")) {
		entries, err := os.ReadDir(filepath.Join(src, "root"))
		if err != nil {
			return err
		}
		for _, e := range entries {
			if e.IsDir() || isSeparateTransmogFile(e.Name()) {
				continue
			}
			if err := copyFile(filepath.Join(src, "root", e.Name()), filepath.Join(cfg.ModEngine, e.Name())); err != nil {
				return err
			}
		}
	}
	// The transfer.bat that is known to work also requires ModEngine to actually
	// load the transferred helper DLLs. Preserve the user's config and add only
	// missing RandomizerHelper / RandomizerCrashFix DLL entries.
	if err := ensureRandomizerDLLsInConfig(src); err != nil {
		return err
	}
	return validateDeployedRandomizer(p)
}

func snapshotModState(dest string) error {
	_ = os.RemoveAll(dest)
	if err := os.MkdirAll(dest, 0755); err != nil {
		return err
	}
	md := modDir()
	for _, n := range managedRandoDirs {
		for _, candidate := range []string{n, n + ".RANDO_OFF"} {
			src := filepath.Join(md, candidate)
			if dirExists(src) {
				if err := copyTree(src, filepath.Join(dest, "mod", candidate)); err != nil {
					return err
				}
			}
		}
	}
	for _, candidate := range []string{"regulation.bin", "regulation.bin.RANDO_OFF"} {
		if fileExists(filepath.Join(md, candidate)) {
			if err := copyFile(filepath.Join(md, candidate), filepath.Join(dest, "mod", candidate)); err != nil {
				return err
			}
		}
	}
	patterns := []string{"Randomizer*.dll", "Randomizer*.ini", "Randomizer*.txt", "Randomizer*.dll.bak", "Randomizer*.ini.bak", "Randomizer*.txt.bak"}
	for _, pat := range patterns {
		matches, _ := filepath.Glob(filepath.Join(cfg.ModEngine, pat))
		for _, src := range matches {
			if err := copyFile(src, filepath.Join(dest, "root", filepath.Base(src))); err != nil {
				return err
			}
		}
	}
	return nil
}

func restoreModState(src string) error {
	if err := cleanRandomizerFromModEngine(); err != nil {
		return err
	}
	if dirExists(filepath.Join(src, "mod")) {
		entries, _ := os.ReadDir(filepath.Join(src, "mod"))
		for _, e := range entries {
			s := filepath.Join(src, "mod", e.Name())
			d := filepath.Join(modDir(), e.Name())
			if e.IsDir() {
				if err := copyTree(s, d); err != nil {
					return err
				}
			} else {
				if err := copyFile(s, d); err != nil {
					return err
				}
			}
		}
	}
	if dirExists(filepath.Join(src, "root")) {
		entries, _ := os.ReadDir(filepath.Join(src, "root"))
		for _, e := range entries {
			if !e.IsDir() {
				if err := copyFile(filepath.Join(src, "root", e.Name()), filepath.Join(cfg.ModEngine, e.Name())); err != nil {
					return err
				}
			}
		}
	}
	return nil
}

// ----------------------------- Profile operations ---------------------------
func createProfile(name, mode, seed string) (ProfileMeta, error) {
	name = strings.TrimSpace(name)
	if name == "" {
		return ProfileMeta{}, errors.New(L("le nom du profil est vide", "profile name is empty"))
	}
	sourceTemplate := templateRoot()
	if !fileExists(filepath.Join(sourceTemplate, "ER0000.sl2")) {
		return ProfileMeta{}, errors.New(L("aucune save de référence protégée n'est disponible. Configure-la dans PARAMÈTRES avant de créer un nouveau profil", "no protected reference save is available. Configure it in SETTINGS before creating a new profile"))
	}
	if mode == "randomizer" && (!cfg.UseModEngine || !cfg.UseRandomizer) {
		return ProfileMeta{}, errors.New(L("les profils Randomizer nécessitent ModEngine 2 + Elden Ring Randomizer configurés dans PARAMÈTRES", "Randomizer profiles require ModEngine 2 + Elden Ring Randomizer configured in SETTINGS"))
	}
	id, err := nextProfileID()
	if err != nil {
		return ProfileMeta{}, err
	}
	p := ProfileMeta{ID: id, Name: name, Mode: mode, Seed: strings.TrimSpace(seed), CreatedAt: time.Now().Format(time.RFC3339)}
	if p.Mode != "randomizer" {
		p.Mode = "normal"
		p.Seed = ""
	}
	if err := saveProfileMeta(p); err != nil {
		return ProfileMeta{}, err
	}
	destRoot := nextSnapshotDir(id)
	dest := filepath.Join(destRoot, cfg.SteamID)
	if err := mirrorCopy(sourceTemplate, dest); err != nil {
		_ = os.RemoveAll(profileDir(id))
		return ProfileMeta{}, err
	}
	if p.Mode == "randomizer" {
		_ = os.MkdirAll(profileRandoDir(id), 0755)
	}
	return p, nil
}

func createProfileFromExisting(name, mode, sourceDir string) (ProfileMeta, error) {
	name = strings.TrimSpace(name)
	if name == "" {
		return ProfileMeta{}, errors.New(L("le nom du profil est vide", "profile name is empty"))
	}
	if !fileExists(filepath.Join(sourceDir, "ER0000.sl2")) {
		return ProfileMeta{}, errors.New(L("ER0000.sl2 est introuvable dans la sauvegarde sélectionnée", "ER0000.sl2 cannot be found in the selected save"))
	}
	id, err := nextProfileID()
	if err != nil {
		return ProfileMeta{}, err
	}
	p := ProfileMeta{ID: id, Name: name, Mode: mode, CreatedAt: time.Now().Format(time.RFC3339)}
	if p.Mode != "randomizer" {
		p.Mode = "normal"
	}
	if err := saveProfileMeta(p); err != nil {
		return ProfileMeta{}, err
	}
	destRoot := nextSnapshotDir(id)
	dest := filepath.Join(destRoot, cfg.SteamID)
	if err := mirrorCopy(sourceDir, dest); err != nil {
		_ = os.RemoveAll(profileDir(id))
		return ProfileMeta{}, err
	}
	if p.Mode == "randomizer" {
		_ = os.MkdirAll(profileRandoDir(id), 0755)
	}
	return p, nil
}

func renameProfile(id, newName string) error {
	newName = strings.TrimSpace(newName)
	if newName == "" {
		return errors.New("le nom est vide")
	}
	b, err := os.ReadFile(profileMetaPath(id))
	if err != nil {
		return err
	}
	var p ProfileMeta
	if err := json.Unmarshal(b, &p); err != nil {
		return err
	}
	p.Name = newName
	return saveProfileMeta(p)
}

func deleteProfileToTrash(id string) error {
	if id == "" {
		return errors.New("aucun profil sélectionné")
	}
	src := profileDir(id)
	if !dirExists(src) {
		return errors.New("profil introuvable")
	}
	if err := os.MkdirAll(trashRoot(), 0755); err != nil {
		return err
	}
	dst := filepath.Join(trashRoot(), fmt.Sprintf("%s_%s", id, time.Now().Format("2006-01-02_15-04-05")))
	return os.Rename(src, dst)
}

func formatPlayTime(seconds int64) string {
	if seconds < 0 {
		seconds = 0
	}
	h := seconds / 3600
	m := (seconds % 3600) / 60
	if h > 0 {
		return fmt.Sprintf("%dh %02dmin", h, m)
	}
	return fmt.Sprintf("%dmin", m)
}

func updateProfileMeta(id string, fn func(*ProfileMeta)) error {
	b, err := os.ReadFile(profileMetaPath(id))
	if err != nil {
		return err
	}
	var p ProfileMeta
	if err := json.Unmarshal(b, &p); err != nil {
		return err
	}
	fn(&p)
	return saveProfileMeta(p)
}

func duplicateProfile(id, newName string) (ProfileMeta, error) {
	src, ok := findProfile(id)
	if !ok {
		return ProfileMeta{}, errors.New(L("profil introuvable", "profile not found"))
	}
	newName = strings.TrimSpace(newName)
	if newName == "" {
		return ProfileMeta{}, errors.New(L("le nom du profil est vide", "profile name is empty"))
	}
	newID, err := nextProfileID()
	if err != nil {
		return ProfileMeta{}, err
	}
	dst := profileDir(newID)
	if err := copyTree(profileDir(id), dst); err != nil {
		return ProfileMeta{}, err
	}
	src.ID = newID
	src.Name = newName
	src.CreatedAt = time.Now().Format(time.RFC3339)
	src.Locked = false
	src.TotalPlaySeconds = 0
	src.LastSessionSeconds = 0
	src.SessionCount = 0
	src.LastPlayedAt = ""
	if err := saveProfileMeta(src); err != nil {
		_ = os.RemoveAll(dst)
		return ProfileMeta{}, err
	}
	return src, nil
}

func setProfileLocked(id string, locked bool) error {
	return updateProfileMeta(id, func(p *ProfileMeta) { p.Locked = locked })
}

func recoverySaveDir() string { return filepath.Join(recoveryRoot(), "latest", cfg.SteamID) }

func createRecoverySnapshot() error {
	if !fileExists(filepath.Join(appDataSave(), "ER0000.sl2")) {
		return errors.New(L("aucune save AppData à sauvegarder en récupération", "no AppData save is available for recovery"))
	}
	root := filepath.Join(recoveryRoot(), "latest")
	_ = os.RemoveAll(root)
	if err := mirrorCopy(appDataSave(), recoverySaveDir()); err != nil {
		return err
	}
	meta := map[string]any{"createdAt": time.Now().Format(time.RFC3339), "currentProfileId": currentProfileID, "savePath": appDataSave()}
	b, _ := json.MarshalIndent(meta, "", "  ")
	_ = os.WriteFile(filepath.Join(root, "recovery.json"), b, 0644)
	return nil
}

func restoreRecoverySnapshot() error {
	src := recoverySaveDir()
	if !fileExists(filepath.Join(src, "ER0000.sl2")) {
		return errors.New(L("aucune sauvegarde de récupération disponible", "no recovery save is available"))
	}
	return mirrorCopy(src, appDataSave())
}

func waitForSaveStable(path string, timeout time.Duration) {
	deadline := time.Now().Add(timeout)
	var lastSize int64 = -1
	var lastMod time.Time
	stable := 0
	for time.Now().Before(deadline) {
		st, err := os.Stat(path)
		if err == nil {
			if st.Size() == lastSize && st.ModTime().Equal(lastMod) {
				stable++
			} else {
				stable = 0
				lastSize = st.Size()
				lastMod = st.ModTime()
			}
			if stable >= 3 {
				return
			}
		}
		time.Sleep(1 * time.Second)
	}
}

func sanitizeFileName(s string) string {
	s = strings.TrimSpace(s)
	if s == "" {
		return "profile"
	}
	bad := `<>:"/\\|?*`
	for _, r := range bad {
		s = strings.ReplaceAll(s, string(r), "_")
	}
	return strings.TrimSpace(s)
}

// safePathComponent is used for user-provided names that become directory names.
// It prevents values such as "." or ".." from escaping the manager's data folders.
func safePathComponent(s, fallback string) string {
	s = sanitizeFileName(s)
	s = strings.Trim(s, " .")
	if s == "" || s == "." || s == ".." {
		return fallback
	}
	return s
}

func zipDirectory(srcDir, zipPath string) error {
	if err := os.MkdirAll(filepath.Dir(zipPath), 0755); err != nil {
		return err
	}
	f, err := os.Create(zipPath)
	if err != nil {
		return err
	}
	defer f.Close()
	zw := zip.NewWriter(f)
	defer zw.Close()
	return filepath.Walk(srcDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		rel, err := filepath.Rel(srcDir, path)
		if err != nil {
			return err
		}
		if rel == "." {
			return nil
		}
		h, err := zip.FileInfoHeader(info)
		if err != nil {
			return err
		}
		h.Name = filepath.ToSlash(rel)
		if info.IsDir() {
			h.Name += "/"
		} else {
			h.Method = zip.Deflate
		}
		w, err := zw.CreateHeader(h)
		if err != nil {
			return err
		}
		if info.IsDir() {
			return nil
		}
		r, err := os.Open(path)
		if err != nil {
			return err
		}
		_, cpErr := io.Copy(w, r)
		closeErr := r.Close()
		if cpErr != nil {
			return cpErr
		}
		return closeErr
	})
}

func unzipProfile(zipPath, tmp string) error {
	zr, err := zip.OpenReader(zipPath)
	if err != nil {
		return err
	}
	defer zr.Close()
	_ = os.RemoveAll(tmp)
	if err := os.MkdirAll(tmp, 0755); err != nil {
		return err
	}
	cleanRoot := filepath.Clean(tmp) + string(os.PathSeparator)
	for _, f := range zr.File {
		dst := filepath.Join(tmp, filepath.FromSlash(f.Name))
		clean := filepath.Clean(dst)
		if clean != filepath.Clean(tmp) && !strings.HasPrefix(clean, cleanRoot) {
			return errors.New("invalid zip path")
		}
		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(clean, 0755); err != nil {
				return err
			}
			continue
		}
		if err := os.MkdirAll(filepath.Dir(clean), 0755); err != nil {
			return err
		}
		rc, err := f.Open()
		if err != nil {
			return err
		}
		out, err := os.Create(clean)
		if err != nil {
			rc.Close()
			return err
		}
		_, cpErr := io.Copy(out, rc)
		out.Close()
		rc.Close()
		if cpErr != nil {
			return cpErr
		}
	}
	return nil
}

func exportProfile(id string) (string, error) {
	p, ok := findProfile(id)
	if !ok {
		return "", errors.New(L("profil introuvable", "profile not found"))
	}
	name := sanitizeFileName(p.Name) + "_" + time.Now().Format("2006-01-02_15-04-05") + ".zip"
	dst := filepath.Join(exportsRoot(), name)
	if err := zipDirectory(profileDir(id), dst); err != nil {
		return "", err
	}
	return dst, nil
}

func importProfileZip(zipPath string) (ProfileMeta, error) {
	tmp := filepath.Join(dataRoot(), "_import_tmp")
	if err := unzipProfile(zipPath, tmp); err != nil {
		return ProfileMeta{}, err
	}
	defer os.RemoveAll(tmp)
	metaPath := filepath.Join(tmp, "profile.json")
	b, err := os.ReadFile(metaPath)
	if err != nil {
		return ProfileMeta{}, errors.New(L("profile.json est absent du ZIP", "profile.json is missing from the ZIP"))
	}
	var p ProfileMeta
	if err := json.Unmarshal(b, &p); err != nil {
		return ProfileMeta{}, err
	}
	newID, err := nextProfileID()
	if err != nil {
		return ProfileMeta{}, err
	}
	p.ID = newID
	p.Name = strings.TrimSpace(p.Name) + L(" (importé)", " (imported)")
	p.CreatedAt = time.Now().Format(time.RFC3339)
	p.Locked = false
	dst := profileDir(newID)
	if err := copyTree(tmp, dst); err != nil {
		return ProfileMeta{}, err
	}
	if err := saveProfileMeta(p); err != nil {
		_ = os.RemoveAll(dst)
		return ProfileMeta{}, err
	}
	return p, nil
}

// ----------------------------- Initialization -------------------------------
func initializeApp() taskResult {
	postProgress(L("Initialisation…", "Initializing…"), 5)
	if err := loadOrCreateConfig(); err != nil {
		return taskResult{Kind: "init", Err: err}
	}
	if err := validateConfiguredPaths(); err != nil {
		return taskResult{Kind: "init", Err: err}
	}
	postProgress(L("Initialisation : création des dossiers du gestionnaire…", "Initialization: creating manager folders…"), 10)
	if err := ensureAppDirs(); err != nil {
		return taskResult{Kind: "init", Err: err}
	}
	if strings.TrimSpace(cfg.BackgroundImage) != "" {
		if err := loadBackgroundImage(resolveAppPath(cfg.BackgroundImage)); err != nil {
			logLine("background: " + err.Error())
		}
	}
	if cfg.UseRandomizer {
		postProgress(L("Initialisation : vérification du Randomizer…", "Initialization: checking Randomizer…"), 18)
		// Public Preview 1.4 no longer modifies transfer.bat. Restore a backup left by 1.1 if present.
		if err := restoreOriginalTransfer(cfg.RandApp); err != nil {
			logLine("restore legacy transfer.bat: " + err.Error())
		}
	}
	migrationMessage, err := runMigration()
	if err != nil {
		return taskResult{Kind: "init", Err: fmt.Errorf("migration: %w", err)}
	}
	postProgress(L("Initialisation : lecture des profils…", "Initialization: reading profiles…"), 68)
	ps, err := loadProfilesFromDisk()
	if err != nil {
		return taskResult{Kind: "init", Err: err}
	}
	postProgress(L("Initialisation : index des sauvegardes…", "Initialization: indexing saves…"), 76)
	maintainSaveStorage(ps)
	rebuildProfileCacheForProfiles(ps)
	st := loadState()
	cur, sel := st.CurrentProfileID, st.LastSelectedID
	exists := func(id string) bool {
		for _, p := range ps {
			if p.ID == id {
				return true
			}
		}
		return false
	}
	if cur != "" && !exists(cur) {
		cur = ""
	}
	if sel == "" || !exists(sel) {
		if cur != "" {
			sel = cur
		} else if len(ps) > 0 {
			sel = ps[0].ID
		}
	}
	modelMu.Lock()
	profilesModel = ps
	currentProfileID = cur
	selectedProfileID = sel
	modelMu.Unlock()
	postProgress(L("Initialisation : vérification des intégrations…", "Initialization: checking integrations…"), 86)
	if cfg.UseModEngine {
		_ = detectRandoState()
	} else {
		randoVisualState = L("NON CONFIGURÉ", "NOT CONFIGURED")
	}
	postProgress(L("Prêt.", "Ready."), 100)
	return taskResult{Kind: "init", Message: migrationMessage, CurrentID: cur, SelectedID: sel, ShowInfoBox: migrationMessage != "", InfoBoxTitle: L("Import des anciennes sauvegardes", "Old save import")}
}

func reloadModel(selectID string) error {
	ps, err := loadProfilesFromDisk()
	if err != nil {
		return err
	}
	maintainSaveStorage(ps)
	rebuildProfileCacheForProfiles(ps)
	modelMu.Lock()
	profilesModel = ps
	if selectID != "" {
		selectedProfileID = selectID
	}
	if selectedProfileID == "" && len(ps) > 0 {
		selectedProfileID = ps[0].ID
	}
	foundSel := false
	foundCur := currentProfileID == ""
	for _, p := range ps {
		if p.ID == selectedProfileID {
			foundSel = true
		}
		if p.ID == currentProfileID {
			foundCur = true
		}
	}
	if !foundSel {
		if len(ps) > 0 {
			selectedProfileID = ps[0].ID
		} else {
			selectedProfileID = ""
		}
	}
	if !foundCur {
		currentProfileID = ""
	}
	modelMu.Unlock()
	saveState()
	return nil
}

// ----------------------------- Process helpers ------------------------------
func isGameRunning() bool {
	const invalidHandle = ^uintptr(0)
	snap, _, _ := pCreateToolhelp32Snapshot.Call(TH32CS_SNAPPROCESS, 0)
	if snap == 0 || snap == invalidHandle {
		return false
	}
	defer pCloseHandle.Call(snap)
	var pe PROCESSENTRY32
	pe.DwSize = uint32(unsafe.Sizeof(pe))
	r, _, _ := pProcess32FirstW.Call(snap, uintptr(unsafe.Pointer(&pe)))
	for r != 0 {
		name := strings.ToLower(syscall.UTF16ToString(pe.SzExeFile[:]))
		if name == "eldenring.exe" {
			return true
		}
		r, _, _ = pProcess32NextW.Call(snap, uintptr(unsafe.Pointer(&pe)))
	}
	return false
}

// ----------------------------- Public setup / path pickers ------------------
func chooseFile(title, filterText string) (string, bool) {
	buf := make([]uint16, 32768)
	filter := []uint16{}
	for _, r := range filterText {
		filter = append(filter, uint16(r))
	}
	if len(filter) == 0 || filter[len(filter)-1] != 0 {
		filter = append(filter, 0)
	}
	of := OPENFILENAMEW{
		LStructSize: uint32(unsafe.Sizeof(OPENFILENAMEW{})), HwndOwner: mainHwnd,
		LpstrFilter: &filter[0], NFilterIndex: 1, LpstrFile: &buf[0], NMaxFile: uint32(len(buf)),
		LpstrTitle: utf16Ptr(title), Flags: OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
	}
	r, _, _ := pGetOpenFileNameW.Call(uintptr(unsafe.Pointer(&of)))
	if r == 0 {
		return "", false
	}
	return syscall.UTF16ToString(buf), true
}

func chooseFolder(title string) (string, bool) {
	buf := make([]uint16, MAX_PATH)
	bi := BROWSEINFOW{
		HwndOwner:      mainHwnd,
		PszDisplayName: &buf[0],
		LpszTitle:      utf16Ptr(title),
		UlFlags:        BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE,
	}
	pidl, _, _ := pSHBrowseForFolderW.Call(uintptr(unsafe.Pointer(&bi)))
	if pidl == 0 {
		return "", false
	}
	defer pCoTaskMemFree.Call(pidl)
	pathBuf := make([]uint16, 32768)
	r, _, _ := pSHGetPathFromIDListW.Call(pidl, uintptr(unsafe.Pointer(&pathBuf[0])))
	if r == 0 {
		return "", false
	}
	return syscall.UTF16ToString(pathBuf), true
}

func chooseSaveFolder() (string, string, bool) {
	file, ok := chooseFile(
		L("Sélectionne ER0000.sl2", "Select ER0000.sl2"),
		"Elden Ring save (ER0000.sl2)\x00ER0000.sl2\x00"+L("Tous les fichiers", "All files")+"\x00*.*\x00\x00",
	)
	if !ok {
		return "", "", false
	}
	if !strings.EqualFold(filepath.Base(file), "ER0000.sl2") {
		messageBox(L("Mauvais fichier", "Wrong file"), L("Sélectionne le fichier ER0000.sl2 situé dans le dossier de sauvegarde Elden Ring.", "Select the ER0000.sl2 file inside your Elden Ring save folder."), MB_OK|MB_ICONWARNING)
		return "", "", false
	}
	dir := filepath.Dir(file)
	steam := filepath.Base(dir)
	if strings.TrimSpace(steam) == "" {
		steam = "steam-profile"
	}
	return dir, steam, true
}

func chooseModEngineFolder() (string, bool) {
	file, ok := chooseFile(
		L("Sélectionne launchmod_eldenring.bat", "Select launchmod_eldenring.bat"),
		"launchmod_eldenring.bat\x00launchmod_eldenring.bat\x00"+L("Tous les fichiers", "All files")+"\x00*.*\x00\x00",
	)
	if !ok {
		return "", false
	}
	if !strings.EqualFold(filepath.Base(file), "launchmod_eldenring.bat") {
		messageBox(L("Mauvais fichier", "Wrong file"), L("Sélectionne launchmod_eldenring.bat dans le dossier principal de ModEngine 2.", "Select launchmod_eldenring.bat in the main ModEngine 2 folder."), MB_OK|MB_ICONWARNING)
		return "", false
	}
	return filepath.Dir(file), true
}

func chooseRandomizerFolder() (string, bool) {
	file, ok := chooseFile(
		L("Sélectionne EldenRingRandomizer.exe", "Select EldenRingRandomizer.exe"),
		"EldenRingRandomizer.exe\x00EldenRingRandomizer.exe\x00"+L("Tous les fichiers", "All files")+"\x00*.*\x00\x00",
	)
	if !ok {
		return "", false
	}
	if !strings.EqualFold(filepath.Base(file), "EldenRingRandomizer.exe") {
		messageBox(L("Mauvais fichier", "Wrong file"), L("Sélectionne EldenRingRandomizer.exe dans le dossier du Randomizer.", "Select EldenRingRandomizer.exe in the Randomizer folder."), MB_OK|MB_ICONWARNING)
		return "", false
	}
	return filepath.Dir(file), true
}

func validateConfiguredPaths() error {
	if strings.TrimSpace(cfg.SavePath) == "" || !fileExists(filepath.Join(cfg.SavePath, "ER0000.sl2")) {
		return errors.New(L("la sauvegarde Elden Ring n'est pas configurée ou ER0000.sl2 est introuvable", "Elden Ring save is not configured or ER0000.sl2 cannot be found"))
	}
	if strings.TrimSpace(cfg.DataRoot) == "" {
		return errors.New(L("le dossier de stockage n'est pas configuré", "storage folder is not configured"))
	}
	if cfg.UseModEngine {
		if !fileExists(filepath.Join(cfg.ModEngine, "launchmod_eldenring.bat")) {
			return errors.New(L("ModEngine 2 est activé mais launchmod_eldenring.bat est introuvable", "ModEngine 2 is enabled but launchmod_eldenring.bat cannot be found"))
		}
	}
	if cfg.UseRandomizer {
		if !cfg.UseModEngine {
			return errors.New(L("le Randomizer nécessite ModEngine 2", "Randomizer integration requires ModEngine 2"))
		}
		if !fileExists(filepath.Join(cfg.RandApp, "EldenRingRandomizer.exe")) {
			return errors.New(L("le Randomizer est activé mais EldenRingRandomizer.exe est introuvable", "Randomizer integration is enabled but EldenRingRandomizer.exe cannot be found"))
		}
	}
	return nil
}

func copyTemplateFrom(source string) error {
	if !fileExists(filepath.Join(source, "ER0000.sl2")) {
		return errors.New(L("ER0000.sl2 est introuvable dans la save modèle", "ER0000.sl2 cannot be found in the template save"))
	}
	if err := os.MkdirAll(filepath.Dir(templateRoot()), 0755); err != nil {
		return err
	}
	return mirrorCopy(source, templateRoot())
}

func languageChoice() string {
	r := messageBox("Language / Langue", "Choisir la langue / Choose language\n\nOUI / YES = Français\nNON / NO = English", MB_YESNO|MB_ICONQUESTION)
	if r == IDYES {
		return "fr"
	}
	return "en"
}

func runSetupWizard(reconfigure bool) bool {
	oldRandApp := cfg.RandApp
	if !reconfigure || strings.TrimSpace(cfg.Language) == "" {
		cfg.Language = languageChoice()
	} else if messageBox(L("Langue", "Language"), L("Voulez-vous changer la langue ?", "Do you want to change the language?"), MB_YESNO|MB_ICONQUESTION) == IDYES {
		cfg.Language = languageChoice()
	}

	messageBox(
		L("Configuration", "Setup"),
		L("L'assistant va te demander les chemins importants. Tu n'as pas besoin de les taper : sélectionne simplement les bons fichiers/dossiers avec Parcourir.", "The wizard will ask for the important paths. You do not need to type them: simply select the correct files/folders using Browse."),
		MB_OK|MB_ICONINFORMATION,
	)

	// Save path is always required on first setup; optional to change later.
	if !reconfigure || strings.TrimSpace(cfg.SavePath) == "" || messageBox(L("Sauvegarde Elden Ring", "Elden Ring save"), L("Modifier le dossier de sauvegarde Elden Ring ?", "Change the Elden Ring save folder?"), MB_YESNO|MB_ICONQUESTION) == IDYES {
		for {
			messageBox(L("Sauvegarde Elden Ring", "Elden Ring save"), L("Sélectionne le fichier ER0000.sl2 du compte/profil Steam que le gestionnaire doit utiliser.", "Select the ER0000.sl2 file for the Steam account/profile the manager should use."), MB_OK|MB_ICONINFORMATION)
			dir, steam, ok := chooseSaveFolder()
			if !ok {
				if reconfigure {
					break
				}
				if messageBox(L("Configuration requise", "Setup required"), L("Le dossier de sauvegarde est obligatoire. Réessayer ?", "The save folder is required. Try again?"), MB_YESNO|MB_ICONWARNING) != IDYES {
					return false
				}
				continue
			}
			cfg.SavePath, cfg.SteamID = dir, steam
			break
		}
	}

	if !reconfigure || strings.TrimSpace(cfg.DataRoot) == "" {
		if messageBox(L("Stockage", "Storage"), L("Stocker profils, saves et seeds dans le dossier de l'application ?\n\nC'est l'option recommandée.", "Store profiles, saves and seeds next to the application?\n\nThis is the recommended option."), MB_YESNO|MB_ICONQUESTION) == IDYES {
			cfg.DataRoot = filepath.Join(exeDir(), "data")
		} else if dir, ok := chooseFolder(L("Choisir le dossier de stockage", "Choose storage folder")); ok {
			cfg.DataRoot = filepath.Join(dir, "EldenRingProfileManagerData")
		} else {
			cfg.DataRoot = filepath.Join(exeDir(), "data")
		}
	} else if messageBox(L("Stockage", "Storage"), L("Changer le dossier de stockage ?\n\nAttention : cette version ne déplace pas automatiquement les profils existants. Choisis Non si tu as déjà des profils.", "Change the storage folder?\n\nWarning: this version does not automatically move existing profiles. Choose No if you already have profiles."), MB_YESNO|MB_ICONWARNING) == IDYES {
		if dir, ok := chooseFolder(L("Choisir le nouveau dossier de stockage", "Choose the new storage folder")); ok {
			cfg.DataRoot = filepath.Join(dir, "EldenRingProfileManagerData")
		}
	}

	if err := ensureAppDirs(); err != nil {
		messageBox(L("Erreur", "Error"), err.Error(), MB_OK|MB_ICONERROR)
		return false
	}

	// Template for new profiles.
	if !fileExists(filepath.Join(templateRoot(), "ER0000.sl2")) || (reconfigure && messageBox(L("Save modèle", "Template save"), L("Remplacer la save modèle utilisée pour créer de nouveaux profils ?", "Replace the template save used to create new profiles?"), MB_YESNO|MB_ICONQUESTION) == IDYES) {
		useCurrent := messageBox(L("Save modèle", "Template save"), L("Utiliser la save actuellement sélectionnée comme modèle ?\n\nPour créer de nouveaux profils vides, sélectionne idéalement une save-vide.", "Use the currently selected save as the template?\n\nFor empty new profiles, ideally select a blank save."), MB_YESNO|MB_ICONQUESTION) == IDYES
		source := cfg.SavePath
		if !useCurrent {
			messageBox(L("Save modèle", "Template save"), L("Sélectionne ER0000.sl2 de la save qui servira de modèle aux nouveaux profils.", "Select the ER0000.sl2 file from the save that should be used as the new-profile template."), MB_OK|MB_ICONINFORMATION)
			if dir, _, ok := chooseSaveFolder(); ok {
				source = dir
			}
		}
		if strings.TrimSpace(source) != "" {
			if err := copyTemplateFrom(source); err != nil {
				messageBox(L("Save modèle", "Template save"), L("La save modèle n'a pas pu être copiée :\n", "The template save could not be copied:\n")+err.Error(), MB_OK|MB_ICONWARNING)
			}
		}
	}

	// Optional ModEngine.
	if !reconfigure || messageBox(L("ModEngine 2", "ModEngine 2"), L("Modifier la configuration ModEngine 2 ?", "Change ModEngine 2 configuration?"), MB_YESNO|MB_ICONQUESTION) == IDYES {
		cfg.UseModEngine = messageBox(L("ModEngine 2", "ModEngine 2"), L("Utilises-tu ModEngine 2 ?\n\nModEngine 2 est requis pour lancer les profils.", "Do you use ModEngine 2?\n\nModEngine 2 is required to launch profiles."), MB_YESNO|MB_ICONQUESTION) == IDYES
		if cfg.UseModEngine {
			messageBox(L("ModEngine 2", "ModEngine 2"), L("Sélectionne launchmod_eldenring.bat dans ton dossier ModEngine 2.", "Select launchmod_eldenring.bat in your ModEngine 2 folder."), MB_OK|MB_ICONINFORMATION)
			if dir, ok := chooseModEngineFolder(); ok {
				cfg.ModEngine = dir
			} else if !reconfigure {
				cfg.UseModEngine = false
			}
			if cfg.UseModEngine {
				cfg.LaunchNormalViaModEngine = true
			}
		} else {
			cfg.ModEngine = ""
			cfg.LaunchNormalViaModEngine = false
		}
	}

	// Optional Randomizer; only meaningful with ModEngine.
	if cfg.UseModEngine {
		if !reconfigure || messageBox(L("Randomizer", "Randomizer"), L("Modifier la configuration Elden Ring Randomizer ?", "Change Elden Ring Randomizer configuration?"), MB_YESNO|MB_ICONQUESTION) == IDYES {
			cfg.UseRandomizer = messageBox(L("Randomizer", "Randomizer"), L("Utilises-tu Elden Ring Randomizer ?\n\nLe Randomizer est optionnel.", "Do you use Elden Ring Randomizer?\n\nThe Randomizer is optional."), MB_YESNO|MB_ICONQUESTION) == IDYES
			if cfg.UseRandomizer {
				messageBox(L("Randomizer", "Randomizer"), L("Sélectionne EldenRingRandomizer.exe.", "Select EldenRingRandomizer.exe."), MB_OK|MB_ICONINFORMATION)
				if dir, ok := chooseRandomizerFolder(); ok {
					cfg.RandApp = dir
				} else if !reconfigure {
					cfg.UseRandomizer = false
				}
			} else {
				cfg.RandApp = ""
			}
		}
	} else {
		cfg.UseRandomizer = false
		cfg.RandApp = ""
	}

	if strings.TrimSpace(oldRandApp) != "" && (!cfg.UseRandomizer || !strings.EqualFold(filepath.Clean(oldRandApp), filepath.Clean(cfg.RandApp))) {
		if err := restoreOriginalTransfer(oldRandApp); err != nil {
			logLine("restore original transfer: " + err.Error())
		}
	}

	if cfg.UseRandomizer && cfg.UseModEngine {
		needCapture := !dirExists(baseModsRoot())
		if reconfigure && dirExists(baseModsRoot()) {
			needCapture = messageBox(L("État ModEngine normal", "Normal ModEngine state"), L("Recapturer l'état NORMAL de ModEngine 2 ?\n\nUtilise cette option seulement quand le Randomizer n'est pas déployé. Le gestionnaire restaurera ensuite ces fichiers quand tu charges un profil normal.", "Recapture the NORMAL ModEngine 2 state?\n\nUse this only when the Randomizer is not deployed. The manager will restore these files when you load a normal profile."), MB_YESNO|MB_ICONQUESTION) == IDYES
		}
		if needCapture {
			if messageBox(L("Sécurité ModEngine", "ModEngine safety"), L("Pour protéger les autres mods, le gestionnaire peut sauvegarder l'état NORMAL actuel des dossiers ModEngine qui peuvent être remplacés par le Randomizer.\n\nIMPORTANT : assure-toi que le Randomizer n'est PAS actuellement transféré dans ModEngine.\n\nCapturer l'état normal maintenant ?", "To protect other mods, the manager can save the current NORMAL state of ModEngine folders that may be replaced by the Randomizer.\n\nIMPORTANT: make sure the Randomizer is NOT currently transferred into ModEngine.\n\nCapture the normal state now?"), MB_YESNO|MB_ICONWARNING) == IDYES {
				if err := captureBaseModState(); err != nil {
					messageBox(L("Sécurité ModEngine", "ModEngine safety"), L("La capture de l'état normal a échoué :\n", "Normal-state capture failed:\n")+err.Error(), MB_OK|MB_ICONWARNING)
				}
			}
		}
	}

	cfg.FirstRunComplete = true
	if err := saveConfig(); err != nil {
		messageBox(L("Erreur", "Error"), L("Impossible d'enregistrer config.json :\n", "Unable to save config.json:\n")+err.Error(), MB_OK|MB_ICONERROR)
		return false
	}
	if err := validateConfiguredPaths(); err != nil {
		messageBox(L("Configuration incomplète", "Incomplete setup"), err.Error(), MB_OK|MB_ICONWARNING)
		return reconfigure
	}
	if cfg.UseRandomizer {
		_ = restoreOriginalTransfer(cfg.RandApp)
	}
	messageBox(L("Configuration terminée", "Setup complete"), L("La configuration est terminée. Tu peux la modifier plus tard avec le bouton PARAMÈTRES.", "Setup is complete. You can change it later with the SETTINGS button."), MB_OK|MB_ICONINFORMATION)
	return true
}

func destroyPage() {
	pSendMessageW.Call(mainHwnd, WM_SETREDRAW, 0, 0)
	for i := len(pageControls) - 1; i >= 0; i-- {
		if pageControls[i] != 0 {
			pDestroyWindow.Call(pageControls[i])
		}
	}
	pageControls = nil
	pagePanelHwnd = 0
	pageKind = ""
	settingsStatusHwnd = 0
	setMainControlsVisible(true)
	pSendMessageW.Call(mainHwnd, WM_SETREDRAW, 1, 0)
	invalidate(mainHwnd)
	pUpdateWindow.Call(mainHwnd)
	if initialized {
		setControlsEnabled(!busy)
	}
}

func pageAdd(parent uintptr, class, text string, exStyle, style uint32, x, y, w, h, id int, font uintptr) uintptr {
	actualParent := parent
	if pagePanelHwnd != 0 && parent == pagePanelHwnd {
		actualParent = mainHwnd
	}
	hwnd := createChild(actualParent, class, text, exStyle, style, x, y, w, h, id, font)
	pageControls = append(pageControls, hwnd)
	return hwnd
}

func pageClientSize() (int, int) {
	var rc RECT
	pGetClientRect.Call(mainHwnd, uintptr(unsafe.Pointer(&rc)))
	return int(rc.Right - rc.Left), int(rc.Bottom - rc.Top)
}

func settingsToggleText() {
	for id, value := range map[int]bool{
		idSettingsToggleME:       settingsTemp.UseModEngine,
		idSettingsToggleRando:    settingsTemp.UseRandomizer,
		idSettingsToggleNormalME: settingsTemp.LaunchNormalViaModEngine,
		idSettingsToggleAutosave: settingsTemp.AutoSaveOnExit,
	} {
		h := uintptr(0)
		for _, c := range pageControls {
			// IDs are not stored by handle, so use actionButtons only for main page.
			_ = c
		}
		// Find the control using GetDlgItem would be ideal; create handles are cached below via helper globals not needed.
		_ = id
		_ = value
		_ = h
	}
}

var settingsToggleMEHwnd, settingsToggleRandoHwnd, settingsToggleNormalMEHwnd, settingsToggleAutosaveHwnd uintptr
var settingsLangFRHwnd, settingsLangENHwnd uintptr

func updateSettingsButtons() {
	if settingsToggleMEHwnd != 0 {
		setWindowText(settingsToggleMEHwnd, L("ModEngine 2 : ", "ModEngine 2: ")+strings.ToUpper(boolLabel(settingsTemp.UseModEngine)))
	}
	if settingsToggleRandoHwnd != 0 {
		setWindowText(settingsToggleRandoHwnd, L("Randomizer : ", "Randomizer: ")+strings.ToUpper(boolLabel(settingsTemp.UseRandomizer)))
	}
	if settingsToggleNormalMEHwnd != 0 {
		setWindowText(settingsToggleNormalMEHwnd, L("Tous les profils passent par ModEngine 2.", "All profiles launch through ModEngine 2."))
	}
	if settingsToggleAutosaveHwnd != 0 {
		setWindowText(settingsToggleAutosaveHwnd, L("Autosave après le jeu : ", "Autosave after game: ")+strings.ToUpper(boolLabel(settingsTemp.AutoSaveOnExit)))
	}
	if settingsLangFRHwnd != 0 {
		if settingsTemp.Language == "fr" {
			setWindowText(settingsLangFRHwnd, "✓ Français")
		} else {
			setWindowText(settingsLangFRHwnd, "Français")
		}
	}
	if settingsLangENHwnd != 0 {
		if settingsTemp.Language == "en" {
			setWindowText(settingsLangENHwnd, "✓ English")
		} else {
			setWindowText(settingsLangENHwnd, "English")
		}
	}
	for _, h := range []uintptr{settingsToggleMEHwnd, settingsToggleRandoHwnd, settingsToggleNormalMEHwnd, settingsToggleAutosaveHwnd, settingsLangFRHwnd, settingsLangENHwnd} {
		invalidate(h)
	}
}

func setSettingsStatus(text string) {
	if settingsStatusHwnd != 0 {
		setWindowText(settingsStatusHwnd, text)
	}
}

func showSettingsPage(firstRun bool) {
	if pageKind != "" {
		destroyPage()
	}
	beginPageBuild()
	settingsFirstRun = firstRun
	settingsTemp = cfg
	settingsBackgroundSource = ""
	if strings.TrimSpace(settingsTemp.Language) == "" {
		settingsTemp.Language = "fr"
	}
	if strings.TrimSpace(settingsTemp.DataRoot) == "" {
		settingsTemp.DataRoot = filepath.Join(exeDir(), "data")
	}
	// The raw color editors from 1.1 are intentionally hidden from the normal settings
	// screen. Presets remain available; this keeps first setup understandable.
	settingsAccentEdit, settingsSecondaryEdit, settingsPanelEdit, settingsTextEdit, settingsProgressEdit, settingsDarkenEdit = 0, 0, 0, 0, 0, 0
	pageKind = "settings"
	setControlsEnabled(false)
	cw, ch := pageClientSize()
	if cw < 1050 {
		cw = 1050
	}
	if ch < 760 {
		ch = 760
	}
	pagePanelHwnd = pageAdd(mainHwnd, "STATIC", "", 0, WS_CHILD|WS_VISIBLE|WS_BORDER, 0, 0, cw, ch, 0, 0)
	panel := pagePanelHwnd
	title := L("PARAMÈTRES", "SETTINGS")
	sub := L("Les chemins importants se règlent ici une fois. Ensuite le gestionnaire automatise le reste sans charger un profil tout seul.", "Set the important paths here once. Then the manager automates the rest without ever loading a profile by itself.")
	if firstRun {
		title = L("CONFIGURATION INITIALE", "INITIAL SETUP")
		sub = L("Indique tes dossiers et tes deux sauvegardes. Les installations ModEngine/Randomizer déjà modifiées seront prises comme référence, pas écrasées.", "Choose your folders and two saves. Existing customized ModEngine/Randomizer installations are used as references, not overwritten.")
	}
	pageAdd(panel, "STATIC", title, 0, WS_CHILD|WS_VISIBLE, 34, 22, cw-68, 42, 0, fontTitle)
	pageAdd(panel, "STATIC", sub, 0, WS_CHILD|WS_VISIBLE, 36, 66, cw-72, 42, 0, fontNormal)

	leftX := 42
	leftW := cw/2 - 70
	rightX := cw/2 + 18
	rightW := cw - rightX - 42

	// LEFT — saves + storage.
	y := 122
	pageAdd(panel, "STATIC", L("LANGUE", "LANGUAGE"), 0, WS_CHILD|WS_VISIBLE, leftX, y, leftW, 26, 0, fontSection)
	settingsLangFRHwnd = pageAdd(panel, "BUTTON", "Français", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, leftX, y+34, 150, 38, idSettingsLangFR, fontNormal)
	settingsLangENHwnd = pageAdd(panel, "BUTTON", "English", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, leftX+160, y+34, 150, 38, idSettingsLangEN, fontNormal)

	y += 92
	pageAdd(panel, "STATIC", L("SAVE ACTUELLE / DOSSIER APPDATA", "CURRENT SAVE / APPDATA FOLDER"), 0, WS_CHILD|WS_VISIBLE, leftX, y, leftW, 26, 0, fontSection)
	pageAdd(panel, "STATIC", L("Le dossier Steam qui contient ER0000.sl2. C'est la destination où un profil est installé seulement quand tu cliques Charger la partie.", "The Steam folder containing ER0000.sl2. A profile is installed there only when you click Load save."), 0, WS_CHILD|WS_VISIBLE, leftX, y+28, leftW, 48, 0, fontSmall)
	settingsSaveEdit = pageAdd(panel, "EDIT", settingsTemp.SavePath, WS_EX_CLIENTEDGE, WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL, leftX, y+80, leftW-118, 34, 0, fontSmall)
	pageAdd(panel, "BUTTON", L("Parcourir", "Browse"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, leftX+leftW-108, y+80, 108, 34, idSettingsBrowseSave, fontSmall)

	y += 132
	pageAdd(panel, "STATIC", L("SAVE DE RÉFÉRENCE — MODÈLE PROTÉGÉ", "REFERENCE SAVE — PROTECTED TEMPLATE"), 0, WS_CHILD|WS_VISIBLE, leftX, y, leftW, 26, 0, fontSection)
	warning := L("Choisis une sauvegarde qui sert uniquement à créer de futurs profils/runs/seeds. Ne choisis pas une partie que tu veux continuer à jouer. L'app en garde une copie protégée.", "Choose a save used only to create future profiles/runs/seeds. Do not choose a playthrough you want to continue. The app keeps a protected copy.")
	pageAdd(panel, "STATIC", warning, 0, WS_CHILD|WS_VISIBLE, leftX, y+28, leftW, 58, 0, fontSmall)
	refText := settingsTemp.ReferenceSource
	if strings.TrimSpace(refText) == "" && fileExists(filepath.Join(templateRoot(), "ER0000.sl2")) {
		refText = L("Copie protégée déjà configurée", "Protected copy already configured")
	}
	settingsReferenceEdit = pageAdd(panel, "EDIT", refText, WS_EX_CLIENTEDGE, WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL, leftX, y+90, leftW-118, 34, 0, fontSmall)
	pageAdd(panel, "BUTTON", L("Choisir", "Choose"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, leftX+leftW-108, y+90, 108, 34, idSettingsBrowseRef, fontSmall)

	y += 138
	pageAdd(panel, "STATIC", L("STOCKAGE DU GESTIONNAIRE", "MANAGER STORAGE"), 0, WS_CHILD|WS_VISIBLE, leftX, y, leftW, 26, 0, fontSection)
	pageAdd(panel, "STATIC", L("Profils, historiques, backups, seeds et références. Le dossier data proposé convient dans la plupart des cas.", "Profiles, history, backups, seeds and references. The suggested data folder is fine for most users."), 0, WS_CHILD|WS_VISIBLE, leftX, y+28, leftW, 40, 0, fontSmall)
	settingsDataEdit = pageAdd(panel, "EDIT", settingsTemp.DataRoot, WS_EX_CLIENTEDGE, WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL, leftX, y+70, leftW-118, 34, 0, fontSmall)
	pageAdd(panel, "BUTTON", L("Parcourir", "Browse"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, leftX+leftW-108, y+70, 108, 34, idSettingsBrowseData, fontSmall)

	// RIGHT — game + integrations.
	y2 := 122
	pageAdd(panel, "STATIC", "ELDEN RING", 0, WS_CHILD|WS_VISIBLE, rightX, y2, rightW, 26, 0, fontSection)
	pageAdd(panel, "STATIC", L("Sélectionne eldenring.exe. Tous les profils passent par ModEngine 2 ; ce chemin permet de vérifier ton installation.", "Select eldenring.exe. All profiles launch through ModEngine 2; this path lets the manager verify your installation."), 0, WS_CHILD|WS_VISIBLE, rightX, y2+28, rightW, 40, 0, fontSmall)
	settingsGameEdit = pageAdd(panel, "EDIT", settingsTemp.GameExe, WS_EX_CLIENTEDGE, WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL, rightX, y2+70, rightW-118, 34, 0, fontSmall)
	pageAdd(panel, "BUTTON", L("Parcourir", "Browse"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, rightX+rightW-108, y2+70, 108, 34, idSettingsBrowseGame, fontSmall)

	y2 += 122
	pageAdd(panel, "STATIC", L("MODENGINE 2 / RANDOMIZER", "MODENGINE 2 / RANDOMIZER"), 0, WS_CHILD|WS_VISIBLE, rightX, y2, rightW, 26, 0, fontSection)
	settingsToggleMEHwnd = pageAdd(panel, "BUTTON", "", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, rightX, y2+34, rightW, 36, idSettingsToggleME, fontSmall)
	settingsModEngineEdit = pageAdd(panel, "EDIT", settingsTemp.ModEngine, WS_EX_CLIENTEDGE, WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL, rightX, y2+76, rightW-118, 34, 0, fontSmall)
	pageAdd(panel, "BUTTON", L("Parcourir", "Browse"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, rightX+rightW-108, y2+76, 108, 34, idSettingsBrowseME, fontSmall)
	settingsToggleRandoHwnd = pageAdd(panel, "BUTTON", "", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, rightX, y2+118, rightW, 36, idSettingsToggleRando, fontSmall)
	settingsRandomizerEdit = pageAdd(panel, "EDIT", settingsTemp.RandApp, WS_EX_CLIENTEDGE, WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL, rightX, y2+160, rightW-118, 34, 0, fontSmall)
	pageAdd(panel, "BUTTON", L("Parcourir", "Browse"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, rightX+rightW-108, y2+160, 108, 34, idSettingsBrowseRando, fontSmall)
	settingsToggleNormalMEHwnd = pageAdd(panel, "STATIC", "", 0, WS_CHILD|WS_VISIBLE, rightX, y2+202, rightW, 36, 0, fontSmall)
	settingsToggleAutosaveHwnd = pageAdd(panel, "BUTTON", "", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, rightX, y2+244, rightW, 36, idSettingsToggleAutosave, fontSmall)
	pageAdd(panel, "STATIC", L("Si ModEngine2 ou le Randomizer sont déjà modifiés et fonctionnent chez toi, l'app prend cette configuration comme référence. Elle ne gère aucun autre mod.", "If ModEngine2 or the Randomizer are already customized and working, the app uses that setup as its reference. It does not manage any other mods."), 0, WS_CHILD|WS_VISIBLE, rightX, y2+286, rightW, 52, 0, fontSmall)

	y2 += 350
	pageAdd(panel, "STATIC", L("APPARENCE", "APPEARANCE"), 0, WS_CHILD|WS_VISIBLE, rightX, y2, rightW, 26, 0, fontSection)
	pageAdd(panel, "BUTTON", L("Choisir un fond", "Choose background"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, rightX, y2+34, (rightW-10)/2, 36, idSettingsBackground, fontSmall)
	pageAdd(panel, "BUTTON", L("Retirer le fond", "Remove background"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, rightX+(rightW-10)/2+10, y2+34, (rightW-10)/2, 36, idSettingsClearBackground, fontSmall)
	bw := (rightW - 20) / 5
	pageAdd(panel, "BUTTON", "Gold", 0, WS_CHILD|WS_VISIBLE|BS_OWNERDRAW, rightX, y2+78, bw, 32, idSettingsPresetGold, fontSmall)
	pageAdd(panel, "BUTTON", "Blue", 0, WS_CHILD|WS_VISIBLE|BS_OWNERDRAW, rightX+bw+5, y2+78, bw, 32, idSettingsPresetBlue, fontSmall)
	pageAdd(panel, "BUTTON", "Violet", 0, WS_CHILD|WS_VISIBLE|BS_OWNERDRAW, rightX+2*(bw+5), y2+78, bw, 32, idSettingsPresetViolet, fontSmall)
	pageAdd(panel, "BUTTON", "Red", 0, WS_CHILD|WS_VISIBLE|BS_OWNERDRAW, rightX+3*(bw+5), y2+78, bw, 32, idSettingsPresetRed, fontSmall)
	pageAdd(panel, "BUTTON", "Dark", 0, WS_CHILD|WS_VISIBLE|BS_OWNERDRAW, rightX+4*(bw+5), y2+78, bw, 32, idSettingsPresetDark, fontSmall)

	bottomY := ch - 82
	settingsStatusHwnd = pageAdd(panel, "STATIC", L("Prêt. TESTER LES CHEMINS permet de vérifier la configuration avant d'appliquer.", "Ready. TEST PATHS checks the configuration before applying."), 0, WS_CHILD|WS_VISIBLE, 42, bottomY-36, cw-84, 28, 0, fontSmall)
	pageAdd(panel, "BUTTON", L("TESTER LES CHEMINS", "TEST PATHS"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 42, bottomY, 180, 44, idSettingsDiagnostic, fontNormal)
	cancelText := L("ANNULER", "CANCEL")
	if firstRun {
		cancelText = L("ANNULER LA CONFIGURATION", "CANCEL SETUP")
	}
	pageAdd(panel, "BUTTON", cancelText, 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, cw-376, bottomY, 160, 44, idSettingsClose, fontNormal)
	applyText := L("APPLIQUER", "APPLY")
	if firstRun {
		applyText = L("TERMINER", "FINISH")
	}
	pageAdd(panel, "BUTTON", applyText, 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, cw-204, bottomY, 162, 44, idSettingsApply, fontSection)
	updateSettingsButtons()
	endPageBuild()
}

func validHexColor(s string) bool {
	s = strings.TrimPrefix(strings.TrimSpace(s), "#")
	if len(s) != 6 {
		return false
	}
	_, err := strconv.ParseUint(s, 16, 32)
	return err == nil
}

func applySettingsPreset(name string) {
	switch name {
	case "gold":
		settingsTemp.ThemeName = "Elden Ring"
		settingsTemp.AccentColor = "#CBA650"
		settingsTemp.SecondaryColor = "#373737"
		settingsTemp.PanelColor = "#1C1C1C"
		settingsTemp.TextColor = "#EFEBDA"
		settingsTemp.ProgressColor = "#CBA650"
	case "blue":
		settingsTemp.ThemeName = "Blue Night"
		settingsTemp.AccentColor = "#5685D8"
		settingsTemp.SecondaryColor = "#303A4D"
		settingsTemp.PanelColor = "#171D29"
		settingsTemp.TextColor = "#E8EDF7"
		settingsTemp.ProgressColor = "#5685D8"
	case "violet":
		settingsTemp.ThemeName = "Violet"
		settingsTemp.AccentColor = "#9A70D6"
		settingsTemp.SecondaryColor = "#40354A"
		settingsTemp.PanelColor = "#211B29"
		settingsTemp.TextColor = "#F0EAF6"
		settingsTemp.ProgressColor = "#9A70D6"
	case "red":
		settingsTemp.ThemeName = "Dark Red"
		settingsTemp.AccentColor = "#B86A6A"
		settingsTemp.SecondaryColor = "#453232"
		settingsTemp.PanelColor = "#251A1A"
		settingsTemp.TextColor = "#F2E8E8"
		settingsTemp.ProgressColor = "#B86A6A"
	case "dark":
		settingsTemp.ThemeName = "Dark"
		settingsTemp.AccentColor = "#AFAFAF"
		settingsTemp.SecondaryColor = "#333333"
		settingsTemp.PanelColor = "#181818"
		settingsTemp.TextColor = "#EEEEEE"
		settingsTemp.ProgressColor = "#AFAFAF"
	}
	setWindowText(settingsAccentEdit, settingsTemp.AccentColor)
	setWindowText(settingsSecondaryEdit, settingsTemp.SecondaryColor)
	setWindowText(settingsPanelEdit, settingsTemp.PanelColor)
	setWindowText(settingsTextEdit, settingsTemp.TextColor)
	setWindowText(settingsProgressEdit, settingsTemp.ProgressColor)
}

func maybeCreateInitialProfileFromCurrentSave() error {
	entries, err := os.ReadDir(profilesRoot())
	if err == nil {
		for _, e := range entries {
			if e.IsDir() && fileExists(filepath.Join(profilesRoot(), e.Name(), "profile.json")) {
				return nil
			}
		}
	}
	if !fileExists(filepath.Join(cfg.SavePath, "ER0000.sl2")) {
		return nil
	}
	if messageBox(L("Créer le premier profil ?", "Create first profile?"), L("La save actuelle peut être importée maintenant comme premier profil.\n\nElle sera COPIÉE dans le gestionnaire et ne sera pas rechargée automatiquement.\n\nCréer ce premier profil ?", "The current save can now be imported as your first profile.\n\nIt will be COPIED into the manager and will not be loaded automatically.\n\nCreate this first profile?"), MB_YESNO|MB_ICONQUESTION) != IDYES {
		return nil
	}
	name, ok := promptText(L("Premier profil", "First profile"), L("Nom du profil :", "Profile name:"), L("Ma partie", "My playthrough"))
	if !ok || strings.TrimSpace(name) == "" {
		return nil
	}
	mode := "normal"
	seed := ""
	if cfg.UseRandomizer && cfg.UseModEngine {
		if messageBox(L("Partie Randomizer ?", "Randomizer playthrough?"), L("Cette save utilise-t-elle déjà le Randomizer ?", "Does this save already use the Randomizer?"), MB_YESNO|MB_ICONQUESTION) == IDYES {
			mode = "randomizer"
		}
	}
	p, err := createProfileFromExisting(name, mode, cfg.SavePath)
	if err != nil {
		return err
	}
	if mode == "randomizer" {
		if len(availableRandomizerImportSources()) > 0 {
			source, label, picked := chooseRandomizerImportSource()
			if picked && source != "" && messageBox(L("Configuration Randomizer détectée", "Randomizer setup detected"), L("Configuration choisie :\n", "Selected setup:\n")+label+L("\n\nL'importer avec ce profil ?", "\n\nImport it with this profile?"), MB_YESNO|MB_ICONQUESTION) == IDYES {
				if v, ok := promptText(L("Nom du seed", "Seed name"), L("Nom / numéro du seed :", "Seed name / number:"), "existing"); ok && strings.TrimSpace(v) != "" {
					seed = strings.TrimSpace(v)
					if err := copyRandomizerPackage(source, profileRandoDir(p.ID)); err != nil {
						return err
					}
					b, _ := os.ReadFile(profileMetaPath(p.ID))
					var pm ProfileMeta
					if json.Unmarshal(b, &pm) == nil {
						pm.Seed = seed
						_ = saveProfileMeta(pm)
						_ = storeSeedInLibrary(seed, p.ID)
					}
				}
			}
		}
	}
	modelMu.Lock()
	selectedProfileID = p.ID
	// Deliberately do NOT set currentProfileID: importing/setup never loads a profile.
	modelMu.Unlock()
	saveState()
	return nil
}

func applySettingsPage() {
	if isGameRunning() {
		setSettingsStatus(L("⚠ Ferme Elden Ring avant de modifier les chemins.", "⚠ Close Elden Ring before changing paths."))
		return
	}
	t := settingsTemp
	t.SavePath = strings.TrimSpace(getWindowText(settingsSaveEdit))
	t.DataRoot = strings.TrimSpace(getWindowText(settingsDataEdit))
	t.GameExe = strings.TrimSpace(getWindowText(settingsGameEdit))
	refInput := strings.TrimSpace(getWindowText(settingsReferenceEdit))
	t.ModEngine = strings.TrimSpace(getWindowText(settingsModEngineEdit))
	t.RandApp = strings.TrimSpace(getWindowText(settingsRandomizerEdit))
	if settingsAccentEdit != 0 {
		t.AccentColor = strings.TrimSpace(getWindowText(settingsAccentEdit))
		t.SecondaryColor = strings.TrimSpace(getWindowText(settingsSecondaryEdit))
		t.PanelColor = strings.TrimSpace(getWindowText(settingsPanelEdit))
		t.TextColor = strings.TrimSpace(getWindowText(settingsTextEdit))
		t.ProgressColor = strings.TrimSpace(getWindowText(settingsProgressEdit))
	}
	if settingsDarkenEdit != 0 {
		darken, err := strconv.Atoi(strings.TrimSpace(getWindowText(settingsDarkenEdit)))
		if err != nil || darken < 0 || darken > 90 {
			setSettingsStatus(L("✕ Assombrissement : entre une valeur de 0 à 90.", "✕ Darkening: enter a value from 0 to 90."))
			return
		}
		t.BackgroundDarken = darken
	}
	for _, c := range []string{t.AccentColor, t.SecondaryColor, t.PanelColor, t.TextColor, t.ProgressColor} {
		if !validHexColor(c) {
			setSettingsStatus(L("✕ Couleur invalide. Utilise le format #RRGGBB, par exemple #CBA650.", "✕ Invalid color. Use #RRGGBB format, e.g. #CBA650."))
			return
		}
	}
	if !fileExists(filepath.Join(t.SavePath, "ER0000.sl2")) {
		setSettingsStatus(L("✕ ER0000.sl2 est introuvable dans la save Elden Ring sélectionnée.", "✕ ER0000.sl2 cannot be found in the selected Elden Ring save."))
		return
	}
	if strings.TrimSpace(t.GameExe) == "" || !fileExists(t.GameExe) || !strings.EqualFold(filepath.Base(t.GameExe), "eldenring.exe") {
		setSettingsStatus(L("✕ Sélectionne eldenring.exe dans ton installation Elden Ring.", "✕ Select eldenring.exe from your Elden Ring installation."))
		return
	}
	if strings.TrimSpace(t.DataRoot) == "" {
		setSettingsStatus(L("✕ Choisis un dossier de stockage.", "✕ Choose a storage folder."))
		return
	}
	if t.UseModEngine && !fileExists(filepath.Join(t.ModEngine, "launchmod_eldenring.bat")) {
		setSettingsStatus(L("✕ launchmod_eldenring.bat est introuvable.", "✕ launchmod_eldenring.bat cannot be found."))
		return
	}
	if t.UseRandomizer {
		if !t.UseModEngine {
			setSettingsStatus(L("✕ Le Randomizer nécessite ModEngine 2.", "✕ Randomizer requires ModEngine 2."))
			return
		}
		if !fileExists(filepath.Join(t.RandApp, "EldenRingRandomizer.exe")) {
			setSettingsStatus(L("✕ EldenRingRandomizer.exe est introuvable.", "✕ EldenRingRandomizer.exe cannot be found."))
			return
		}
	}
	// Reference save is mandatory on first setup. Later, the protected copy may remain without a new source path.
	needRefCopy := false
	refSource := ""
	if fileExists(filepath.Join(refInput, "ER0000.sl2")) {
		refSource = refInput
		needRefCopy = true
	}
	if settingsFirstRun && !needRefCopy && !fileExists(filepath.Join(templateRoot(), "ER0000.sl2")) {
		setSettingsStatus(L("✕ Choisis une SAVE DE RÉFÉRENCE. Elle doit être un modèle que tu ne comptes pas continuer à jouer.", "✕ Choose a REFERENCE SAVE. It must be a template you do not plan to keep playing."))
		return
	}
	if !settingsFirstRun && strings.TrimSpace(t.DataRoot) != strings.TrimSpace(cfg.DataRoot) && len(profilesModel) > 0 {
		if messageBox(L("Changer le stockage ?", "Change storage?"), L("Les profils existants ne seront PAS déplacés automatiquement vers le nouveau stockage.\n\nSi tu veux garder tes profils actuels ici, choisis Annuler et conserve le chemin actuel.", "Existing profiles will NOT be moved automatically to the new storage.\n\nIf you want to keep your current profiles here, choose Cancel and keep the current path."), MB_YESNO|MB_ICONWARNING) != IDYES {
			return
		}
	}
	oldRand := cfg.RandApp
	oldME := cfg.ModEngine
	cfg = t
	if needRefCopy {
		cfg.ReferenceSource = refSource
	}
	if strings.TrimSpace(cfg.SteamID) == "" {
		cfg.SteamID = filepath.Base(filepath.Clean(cfg.SavePath))
	}
	if err := ensureAppDirs(); err != nil {
		setSettingsStatus("✕ " + err.Error())
		return
	}
	if settingsBackgroundSource != "" {
		ext := strings.ToLower(filepath.Ext(settingsBackgroundSource))
		if ext != ".png" && ext != ".jpg" && ext != ".jpeg" {
			setSettingsStatus(L("✕ Le fond doit être PNG ou JPG.", "✕ Background must be PNG or JPG."))
			return
		}
		if err := os.MkdirAll(appearanceRoot(), 0755); err != nil {
			setSettingsStatus("✕ " + err.Error())
			return
		}
		dst := filepath.Join(appearanceRoot(), "background"+ext)
		if err := copyFile(settingsBackgroundSource, dst); err != nil {
			setSettingsStatus("✕ " + err.Error())
			return
		}
		cfg.BackgroundImage = dst
	} else if settingsTemp.BackgroundImage == "" {
		cfg.BackgroundImage = ""
	}
	if needRefCopy {
		if err := copyTemplateFrom(refSource); err != nil {
			setSettingsStatus(L("✕ Impossible de créer la copie protégée de la save de référence : ", "✕ Unable to create protected reference save copy: ") + err.Error())
			return
		}
	}
	if strings.TrimSpace(oldRand) != "" && (!cfg.UseRandomizer || !strings.EqualFold(filepath.Clean(oldRand), filepath.Clean(cfg.RandApp))) {
		_ = restoreOriginalTransfer(oldRand)
	}
	if cfg.UseModEngine {
		// Existing ModEngine installations are references, not targets to reset. Capture the
		// user's current configuration once (or again when the selected ModEngine folder changes).
		pathChanged := strings.TrimSpace(oldME) != "" && !strings.EqualFold(filepath.Clean(oldME), filepath.Clean(cfg.ModEngine))
		if pathChanged {
			_ = removeAllWithRetry(baseModsRoot())
			_ = os.Remove(userModEngineConfigPath())
		}
		if fileExists(modEngineConfigPath()) && !fileExists(userModEngineConfigPath()) {
			_ = os.MkdirAll(modEngineReferenceRoot(), 0755)
			if err := copyFile(modEngineConfigPath(), userModEngineConfigPath()); err != nil {
				setSettingsStatus(L("✕ Impossible de protéger config_eldenring.toml : ", "✕ Unable to protect config_eldenring.toml: ") + err.Error())
				return
			}
		}
		if !dirExists(baseModsRoot()) {
			if err := captureBaseModState(); err != nil {
				setSettingsStatus(L("✕ Référence ModEngine impossible : ", "✕ Could not capture ModEngine reference: ") + err.Error())
				return
			}
		}
	}
	if cfg.UseRandomizer {
		// 1.2 imports generated files directly. Never replace the user's transfer.bat.
		_ = restoreOriginalTransfer(cfg.RandApp)
	}
	if settingsFirstRun {
		if err := maybeCreateInitialProfileFromCurrentSave(); err != nil {
			setSettingsStatus(L("⚠ Configuration enregistrée, mais import du premier profil impossible : ", "⚠ Setup saved, but first profile import failed: ") + err.Error())
			return
		}
	}
	cfg.FirstRunComplete = true
	if err := saveConfig(); err != nil {
		setSettingsStatus("✕ config.json: " + err.Error())
		return
	}
	applyThemeFromConfig()
	if cfg.BackgroundImage != "" {
		_ = loadBackgroundImage(resolveAppPath(cfg.BackgroundImage))
	} else {
		_ = loadBackgroundImage("")
	}
	setSettingsStatus(L("✓ Paramètres enregistrés. Redémarrage du gestionnaire…", "✓ Settings saved. Restarting manager…"))
	exe, err := os.Executable()
	if err == nil {
		_ = exec.Command(exe).Start()
	}
	pDestroyWindow.Call(mainHwnd)
}

func doSettings() {
	showSettingsPage(false)
}

// ----------------------------- Appearance / layout -------------------------
func loadBackgroundImage(path string) error {
	if strings.TrimSpace(path) == "" {
		bgMu.Lock()
		bgPixels = nil
		bgWidth, bgHeight = 0, 0
		bgMu.Unlock()
		return nil
	}
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	img, _, err := image.Decode(f)
	if err != nil {
		return fmt.Errorf("image de fond illisible (PNG/JPG) : %w", err)
	}
	b := img.Bounds()
	w, h := b.Dx(), b.Dy()
	if w <= 0 || h <= 0 {
		return errors.New("image de fond vide")
	}
	pix := make([]byte, w*h*4)
	darken := cfg.BackgroundDarken
	if darken < 60 {
		darken = 60
	}
	if darken < 0 {
		darken = 0
	}
	if darken > 90 {
		darken = 90
	}
	factor := float64(100-darken) / 100.0
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			r, g, bl, a := img.At(b.Min.X+x, b.Min.Y+y).RGBA()
			af := float64(a) / 65535.0
			r8 := byte(float64(r>>8) * af * factor)
			g8 := byte(float64(g>>8) * af * factor)
			b8 := byte(float64(bl>>8) * af * factor)
			i := (y*w + x) * 4
			pix[i+0] = b8
			pix[i+1] = g8
			pix[i+2] = r8
			pix[i+3] = 0
		}
	}
	bgMu.Lock()
	bgPixels, bgWidth, bgHeight = pix, w, h
	bgMu.Unlock()
	return nil
}

func drawBackground(hwnd, hdc uintptr) bool {
	bgMu.RLock()
	pix := bgPixels
	w, h := bgWidth, bgHeight
	bgMu.RUnlock()
	var rc RECT
	pGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
	cw, ch := int(rc.Right-rc.Left), int(rc.Bottom-rc.Top)
	if len(pix) == 0 || w <= 0 || h <= 0 || cw <= 0 || ch <= 0 {
		pFillRect.Call(hdc, uintptr(unsafe.Pointer(&rc)), brushBg)
		return false
	}
	bi := BITMAPINFO{BmiHeader: BITMAPINFOHEADER{
		BiSize: uint32(unsafe.Sizeof(BITMAPINFOHEADER{})), BiWidth: int32(w), BiHeight: -int32(h),
		BiPlanes: 1, BiBitCount: 32, BiCompression: BI_RGB, BiSizeImage: uint32(len(pix)),
	}}
	// "Cover" mode: preserve the image aspect ratio and crop excess instead of stretching faces/artwork.
	sx, sy, sw, sh := 0, 0, w, h
	targetRatio := float64(cw) / float64(ch)
	imageRatio := float64(w) / float64(h)
	if imageRatio > targetRatio {
		sw = int(float64(h) * targetRatio)
		sx = (w - sw) / 2
	} else if imageRatio < targetRatio {
		sh = int(float64(w) / targetRatio)
		sy = (h - sh) / 2
	}
	pStretchDIBits.Call(hdc, 0, 0, uintptr(cw), uintptr(ch), uintptr(sx), uintptr(sy), uintptr(sw), uintptr(sh), uintptr(unsafe.Pointer(&pix[0])), uintptr(unsafe.Pointer(&bi)), DIB_RGB_COLORS, SRCCOPY)
	return true
}

func chooseImageFile() (string, bool) {
	buf := make([]uint16, 32768)
	filterText := "Images PNG/JPG\x00*.png;*.jpg;*.jpeg\x00PNG (*.png)\x00*.png\x00JPEG (*.jpg;*.jpeg)\x00*.jpg;*.jpeg\x00Tous les fichiers\x00*.*\x00\x00"
	filter := []uint16{}
	for _, r := range filterText {
		filter = append(filter, uint16(r))
	}
	of := OPENFILENAMEW{
		LStructSize: uint32(unsafe.Sizeof(OPENFILENAMEW{})), HwndOwner: mainHwnd,
		LpstrFilter: &filter[0], NFilterIndex: 1, LpstrFile: &buf[0], NMaxFile: uint32(len(buf)),
		LpstrTitle: utf16Ptr("Choisir l'image de fond"), Flags: OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
	}
	r, _, _ := pGetOpenFileNameW.Call(uintptr(unsafe.Pointer(&of)))
	if r == 0 {
		return "", false
	}
	return syscall.UTF16ToString(buf), true
}

func setCustomBackground() {
	path, ok := chooseImageFile()
	if !ok {
		return
	}
	ext := strings.ToLower(filepath.Ext(path))
	if ext != ".png" && ext != ".jpg" && ext != ".jpeg" {
		messageBox(L("Fond", "Background"), L("Choisis une image PNG ou JPG.", "Choose a PNG or JPG image."), MB_OK|MB_ICONWARNING)
		return
	}
	startTask(L("Application du fond personnalisé…", "Applying custom background…"), func() taskResult {
		postProgress(L("Copie de l'image dans le dossier du gestionnaire…", "Copying image into manager storage…"), 25)
		if err := os.MkdirAll(appearanceRoot(), 0755); err != nil {
			return taskResult{Kind: "background", Err: err}
		}
		dst := filepath.Join(appearanceRoot(), "background"+ext)
		if !strings.EqualFold(filepath.Clean(path), filepath.Clean(dst)) {
			if err := copyFile(path, dst); err != nil {
				return taskResult{Kind: "background", Err: err}
			}
		}
		postProgress(L("Préparation visuelle du fond…", "Preparing background…"), 60)
		cfg.BackgroundImage = dst
		if cfg.BackgroundDarken == 0 {
			cfg.BackgroundDarken = 42
		}
		if err := saveConfig(); err != nil {
			logLine("Config background: " + err.Error())
		}
		if err := loadBackgroundImage(dst); err != nil {
			return taskResult{Kind: "background", Err: err}
		}
		return taskResult{Kind: "background", Message: L("Fond personnalisé appliqué. Il sera conservé au prochain lancement.", "Custom background applied. It will be kept on next launch.")}
	})
}

func layoutControls(clientW, clientH int) {
	if clientW <= 0 || clientH <= 0 {
		return
	}
	sx := float64(clientW) / float64(baseUIWidth)
	sy := float64(clientH) / float64(baseUIHeight)
	layoutMu.Lock()
	defer layoutMu.Unlock()
	for hwnd, r := range controlLayout {
		x := int(float64(r.Left) * sx)
		y := int(float64(r.Top) * sy)
		w := int(float64(r.Right-r.Left) * sx)
		h := int(float64(r.Bottom-r.Top) * sy)
		if w < 1 {
			w = 1
		}
		if h < 1 {
			h = 1
		}
		pMoveWindow.Call(hwnd, uintptr(x), uintptr(y), uintptr(w), uintptr(h), 1)
	}
}

func openExplorer(path string) {
	if strings.TrimSpace(path) == "" {
		messageBox(L("Chemin non configuré", "Path not configured"), L("Ce chemin n'est pas configuré. Ouvre PARAMÈTRES pour le définir.", "This path is not configured. Open SETTINGS to define it."), MB_OK|MB_ICONINFORMATION)
		return
	}
	if !pathExists(path) {
		messageBox(L("Dossier introuvable", "Folder not found"), L("Le dossier n'existe pas :\n", "The folder does not exist:\n")+path, MB_OK|MB_ICONWARNING)
		return
	}
	cmd := exec.Command("explorer.exe", path)
	_ = cmd.Start()
}

// ----------------------------- UI helpers -----------------------------------
func createChild(parent uintptr, class, text string, exStyle, style uint32, x, y, w, h, id int, font uintptr) uintptr {
	hwnd, _, _ := pCreateWindowExW.Call(uintptr(exStyle), uintptr(unsafe.Pointer(utf16Ptr(class))), uintptr(unsafe.Pointer(utf16Ptr(text))), uintptr(style), uintptr(x), uintptr(y), uintptr(w), uintptr(h), parent, uintptr(id), 0, 0)
	if font != 0 {
		pSendMessageW.Call(hwnd, WM_SETFONT, font, 0)
	}
	return hwnd
}
func createControl(class, text string, style uint32, x, y, w, h, id int, font uintptr) uintptr {
	if class == "STATIC" {
		style = (style &^ 0x1f) | 0x0d
	} // SS_OWNERDRAW
	hwnd := createChild(mainHwnd, class, text, 0, style, x, y, w, h, id, font)
	if hwnd != 0 {
		layoutMu.Lock()
		controlLayout[hwnd] = RECT{Left: int32(x), Top: int32(y), Right: int32(x + w), Bottom: int32(y + h)}
		layoutMu.Unlock()
		mainControls = append(mainControls, hwnd)
	}
	return hwnd
}

func setMainControlsVisible(visible bool) {
	cmd := uintptr(SW_HIDE)
	if visible {
		cmd = SW_SHOW
	}
	for _, h := range mainControls {
		if h != 0 {
			pShowWindow.Call(h, cmd)
		}
	}
}

func beginPageBuild() {
	pSendMessageW.Call(mainHwnd, WM_SETREDRAW, 0, 0)
	setMainControlsVisible(false)
}

func endPageBuild() {
	pSendMessageW.Call(mainHwnd, WM_SETREDRAW, 1, 0)
	invalidate(mainHwnd)
	pUpdateWindow.Call(mainHwnd)
}
func setWindowText(hwnd uintptr, s string) {
	if hwnd != 0 {
		pSetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(utf16Ptr(s))))
	}
}
func getWindowText(hwnd uintptr) string {
	if hwnd == 0 {
		return ""
	}
	n, _, _ := pGetWindowTextLengthW.Call(hwnd)
	buf := make([]uint16, int(n)+1)
	if n > 0 {
		pGetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), n+1)
	}
	return syscall.UTF16ToString(buf)
}

func setPageControlsEnabled(enable bool) {
	if modalActive {
		enable = false
	}
	v := uintptr(0)
	if enable {
		v = 1
	}
	for _, h := range pageControls {
		if h != 0 {
			pEnableWindow.Call(h, v)
		}
	}
}

func closeInlineModal() {
	for _, h := range modalControls {
		if h != 0 {
			pDestroyWindow.Call(h)
		}
	}
	modalControls = nil
	modalPanelHwnd = 0
	modalEditHwnd = 0
	modalActive = false
	invalidate(mainHwnd)
}

func modalRect(width, height int) (int, int, int, int) {
	var rc RECT
	pGetClientRect.Call(mainHwnd, uintptr(unsafe.Pointer(&rc)))
	cw, ch := int(rc.Right-rc.Left), int(rc.Bottom-rc.Top)
	if width > cw-40 {
		width = cw - 40
	}
	if height > ch-40 {
		height = ch - 40
	}
	if width < 420 {
		width = 420
	}
	if height < 190 {
		height = 190
	}
	return (cw - width) / 2, (ch - height) / 2, width, height
}

func invalidate(hwnd uintptr) {
	if hwnd != 0 {
		pInvalidateRect.Call(hwnd, 0, 1)
	}
}
func buttonText(hwnd uintptr) string {
	n, _, _ := pGetWindowTextLengthW.Call(hwnd)
	if n == 0 {
		return ""
	}
	buf := make([]uint16, int(n)+1)
	pGetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), n+1)
	return syscall.UTF16ToString(buf)
}

func drawOwnerButton(dis *DRAWITEMSTRUCT) {
	id := int(dis.CtlID)
	fill := colSecondary
	text := colText
	switch id {
	case idPlay:
		fill = colGold
		text = rgb(20, 20, 20)
	case idLaunch:
		fill = rgb(50, 105, 68)
	case idCreateProfile:
		fill = rgb(55, 80, 62)
	case idDeleteProfile:
		fill = rgb(95, 48, 48)
	case idImportSeed:
		fill = rgb(66, 61, 45)
	case idBackup, idNamedBackup, idRenameProfile, idRefresh, idHelp, idSwitch, idFolders, idHistory, idBackground, idOpenRandomizer, idSettings, idDuplicateProfile, idLockProfile, idRecovery, idImportExisting:
		fill = rgb(55, 55, 55)
	}
	if dis.ItemState&ODS_SELECTED != 0 {
		fill = colGoldDark
	}
	br, _, _ := pCreateSolidBrush.Call(fill)
	pFillRect.Call(dis.HDC, uintptr(unsafe.Pointer(&dis.RcItem)), br)
	pDeleteObject.Call(br)
	pSetBkMode.Call(dis.HDC, TRANSPARENT)
	pSetTextColor.Call(dis.HDC, text)
	txt := buttonText(dis.HwndItem)
	pDrawTextW.Call(dis.HDC, uintptr(unsafe.Pointer(utf16Ptr(txt))), uintptr(^uint32(0)), uintptr(unsafe.Pointer(&dis.RcItem)), DT_CENTER|DT_VCENTER|DT_SINGLELINE)
}

func drawOwnerList(dis *DRAWITEMSTRUCT) {
	if dis.ItemID == ^uint32(0) {
		return
	}
	fill := colPanel
	textColor := colText
	if dis.ItemState&ODS_SELECTED != 0 {
		fill = colAccent
		textColor = rgb(18, 18, 18)
	}
	br, _, _ := pCreateSolidBrush.Call(fill)
	pFillRect.Call(dis.HDC, uintptr(unsafe.Pointer(&dis.RcItem)), br)
	pDeleteObject.Call(br)
	pSetBkMode.Call(dis.HDC, TRANSPARENT)
	pSetTextColor.Call(dis.HDC, textColor)
	idx := int(dis.ItemID)
	label := ""
	if int(dis.CtlID) == idProfileList {
		modelMu.RLock()
		if idx >= 0 && idx < len(profileListIDs) {
			id := profileListIDs[idx]
			for _, p := range profilesModel {
				if p.ID == id {
					suffix := L("Normal", "Normal")
					if p.Mode == "randomizer" {
						suffix = "Randomizer"
						if p.Seed != "" {
							suffix += " • " + seedLabel(p.Seed)
						}
					}
					if p.Favorite {
						label = "★ "
					}
					label += fmt.Sprintf("%s    [%s]", p.Name, suffix)
					break
				}
			}
		}
		modelMu.RUnlock()
	} else if int(dis.CtlID) == idSaveList {
		if idx >= 0 && idx < len(selectedSaves) {
			label = selectedSaves[idx].Label
			if idx == 0 {
				label = "★  " + label + L("   — dernière sauvegarde", "   — latest save")
			}
		}
	}
	r := dis.RcItem
	r.Left += 10
	pDrawTextW.Call(dis.HDC, uintptr(unsafe.Pointer(utf16Ptr(label))), uintptr(^uint32(0)), uintptr(unsafe.Pointer(&r)), DT_VCENTER|DT_SINGLELINE)
}

func createUI() {
	createControl("STATIC", L("ELDEN RING  •  PROFILE MANAGER — APERÇU PUBLIC 1.4.7", "ELDEN RING  •  PROFILE MANAGER — PUBLIC PREVIEW 1.4.7"), WS_CHILD|WS_VISIBLE|SS_LEFT, 36, 22, 700, 44, 0, fontTitle)
	createControl("STATIC", L("Choisis ton profil • vérifie l’état • joue", "Choose your profile • check status • play"), WS_CHILD|WS_VISIBLE|SS_LEFT, 38, 67, 690, 24, 0, fontNormal)
	actionButtons[idFolders] = createControl("BUTTON", L("PROFIL / OUTILS", "PROFILE / TOOLS"), WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 748, 50, 146, 40, idFolders, fontSmall)
	actionButtons[idHistory] = createControl("BUTTON", L("SAUVEGARDES", "SAVES"), WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 904, 50, 118, 40, idHistory, fontSmall)
	actionButtons[idSettings] = createControl("BUTTON", L("PARAMÈTRES", "SETTINGS"), WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 1032, 50, 126, 40, idSettings, fontSmall)
	actionButtons[idHelp] = createControl("BUTTON", L("? AIDE", "? HELP"), WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 1168, 50, 64, 40, idHelp, fontSmall)

	createControl("STATIC", L("PROFIL INSTALLÉ DANS ELDEN RING", "PROFILE INSTALLED IN ELDEN RING"), WS_CHILD|WS_VISIBLE, 36, 108, 280, 26, 0, fontSection)
	currentStatusHwnd = createControl("STATIC", L("Initialisation…", "Initializing…"), WS_CHILD|WS_VISIBLE, 320, 110, 540, 24, idCurrentStatus, fontNormal)
	randoStatusHwnd = createControl("STATIC", L("Intégrations : …", "Integrations: …"), WS_CHILD|WS_VISIBLE, 870, 108, 350, 26, idRandoStatus, fontSection)

	createControl("STATIC", L("MES PROFILS", "MY PROFILES"), WS_CHILD|WS_VISIBLE, 36, 160, 200, 26, 0, fontSection)
	profileListHwnd = createControl("LISTBOX", "", WS_CHILD|WS_VISIBLE|WS_BORDER|WS_VSCROLL|LBS_NOTIFY|LBS_OWNERDRAWFIXED|LBS_HASSTRINGS|LBS_NOINTEGRALHEIGHT, 36, 194, 380, 298, idProfileList, fontNormal)
	actionButtons[idCreateProfile] = createControl("BUTTON", L("+ Nouveau profil", "+ New profile"), WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 36, 504, 186, 36, idCreateProfile, fontSmall)
	actionButtons[idImportExisting] = createControl("BUTTON", L("Importer un profil", "Import profile"), WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 230, 504, 186, 36, idImportExisting, fontSmall)
	createControl("STATIC", L("Renommer, dupliquer, verrouiller et supprimer → PROFIL / OUTILS", "Rename, duplicate, lock and delete → PROFILE / TOOLS"), WS_CHILD|WS_VISIBLE, 36, 548, 380, 30, 0, fontSmall)

	createControl("STATIC", L("PROFIL SÉLECTIONNÉ", "SELECTED PROFILE"), WS_CHILD|WS_VISIBLE, 452, 160, 260, 26, 0, fontSection)
	createControl("STATIC", L("Nom", "Name"), WS_CHILD|WS_VISIBLE, 452, 200, 90, 24, 0, fontSmall)
	profileNameHwnd = createControl("STATIC", "—", WS_CHILD|WS_VISIBLE, 548, 200, 350, 24, idProfileName, fontNormal)
	seedImportStatusHwnd = createControl("STATIC", L("Seed détecté : vérification…", "Detected seed: checking…"), WS_CHILD|WS_VISIBLE, 920, 200, 278, 24, idSeedImportStatus, fontSmall)
	createControl("STATIC", L("Mode", "Mode"), WS_CHILD|WS_VISIBLE, 452, 232, 90, 24, 0, fontSmall)
	profileModeHwnd = createControl("STATIC", "—", WS_CHILD|WS_VISIBLE, 548, 232, 300, 24, idProfileMode, fontNormal)
	createControl("STATIC", "Seed", WS_CHILD|WS_VISIBLE, 452, 264, 90, 24, 0, fontSmall)
	profileSeedHwnd = createControl("STATIC", "—", WS_CHILD|WS_VISIBLE, 548, 264, 300, 24, idProfileSeed, fontNormal)
	createControl("STATIC", L("Fichiers seed", "Seed files"), WS_CHILD|WS_VISIBLE, 452, 296, 90, 24, 0, fontSmall)
	seedStatusHwnd = createControl("STATIC", "—", WS_CHILD|WS_VISIBLE, 548, 296, 350, 24, idSeedStatus, fontNormal)
	createControl("STATIC", L("Dernière save", "Latest save"), WS_CHILD|WS_VISIBLE, 452, 328, 90, 24, 0, fontSmall)
	latestSaveHwnd = createControl("STATIC", "—", WS_CHILD|WS_VISIBLE, 548, 328, 350, 24, idLatestSave, fontNormal)
	createControl("STATIC", L("Temps de jeu", "Playtime"), WS_CHILD|WS_VISIBLE, 452, 356, 90, 24, 0, fontSmall)
	playTimeHwnd = createControl("STATIC", "—", WS_CHILD|WS_VISIBLE, 548, 356, 350, 24, 0, fontNormal)
	profileReadyHwnd = createControl("STATIC", L("État du profil : …", "Profile state: …"), WS_CHILD|WS_VISIBLE, 920, 364, 278, 24, 0, fontSmall)

	actionButtons[idImportSeed] = createControl("BUTTON", L("Importer le seed actuel", "Import current seed"), WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 920, 232, 278, 38, idImportSeed, fontNormal)
	actionButtons[idOpenRandomizer] = createControl("BUTTON", L("Ouvrir EldenRingRandomizer", "Open EldenRingRandomizer"), WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 920, 278, 278, 38, idOpenRandomizer, fontSmall)
	actionButtons[idRefresh] = createControl("BUTTON", L("Actualiser", "Refresh"), WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 920, 324, 278, 36, idRefresh, fontNormal)

	createControl("STATIC", L("SAUVEGARDES DU PROFIL", "PROFILE SAVES"), WS_CHILD|WS_VISIBLE, 452, 390, 300, 26, 0, fontSection)
	createControl("STATIC", L("La plus récente est sélectionnée automatiquement", "Newest save is selected automatically"), WS_CHILD|WS_VISIBLE, 720, 392, 470, 24, 0, fontSmall)
	saveListHwnd = createControl("LISTBOX", "", WS_CHILD|WS_VISIBLE|WS_BORDER|WS_VSCROLL|LBS_NOTIFY|LBS_OWNERDRAWFIXED|LBS_HASSTRINGS|LBS_NOINTEGRALHEIGHT, 452, 424, 746, 154, idSaveList, fontNormal)

	createControl("STATIC", L("Backups, points importants et récupération → SAUVEGARDES", "Backups, important points and recovery → SAVES"), WS_CHILD|WS_VISIBLE, 36, 610, 380, 30, 0, fontSmall)
	actionButtons[idPlay] = createControl("BUTTON", L("1 · CHARGER LA PARTIE", "1 · LOAD SAVE"), WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 452, 604, 746, 64, idPlay, fontSection)

	createControl("STATIC", L("OPÉRATION", "OPERATION"), WS_CHILD|WS_VISIBLE, 36, 698, 150, 26, 0, fontSection)
	progressHwnd = createControl("msctls_progress32", "", WS_CHILD|WS_VISIBLE, 36, 730, 1162, 22, 0, 0)
	// Disable the Windows themed blue progress style so the user-selected color is respected.
	pSetWindowTheme.Call(progressHwnd, uintptr(unsafe.Pointer(utf16Ptr(""))), uintptr(unsafe.Pointer(utf16Ptr(""))))
	pSendMessageW.Call(progressHwnd, PBM_SETRANGE32, 0, 100)
	pSendMessageW.Call(progressHwnd, PBM_SETPOS, 0, 0)
	pSendMessageW.Call(progressHwnd, PBM_SETBARCOLOR, 0, colProgress)
	pSendMessageW.Call(progressHwnd, PBM_SETBKCOLOR, 0, colPanel)
	pSendMessageW.Call(profileListHwnd, LB_SETITEMHEIGHT, 0, 30)
	pSendMessageW.Call(saveListHwnd, LB_SETITEMHEIGHT, 0, 28)
	progressTextHwnd = createControl("STATIC", L("Initialisation en cours…", "Initialization in progress…"), WS_CHILD|WS_VISIBLE, 36, 760, 1162, 26, 0, fontNormal)

	createControl("STATIC", L("ÉTAT", "STATUS"), WS_CHILD|WS_VISIBLE, 36, 800, 100, 26, 0, fontSection)
	infoStatusHwnd = createControl("STATIC", L("Démarrage du gestionnaire…", "Starting manager…"), WS_CHILD|WS_VISIBLE, 36, 830, 1162, 42, idInfoStatus, fontNormal)
	setControlsEnabled(false)
}

func setInfo(s string) { setWindowText(infoStatusHwnd, s) }

func selectedProfile() (ProfileMeta, bool) {
	modelMu.RLock()
	defer modelMu.RUnlock()
	for _, p := range profilesModel {
		if p.ID == selectedProfileID {
			return p, true
		}
	}
	return ProfileMeta{}, false
}
func currentProfile() (ProfileMeta, bool) {
	modelMu.RLock()
	defer modelMu.RUnlock()
	for _, p := range profilesModel {
		if p.ID == currentProfileID {
			return p, true
		}
	}
	return ProfileMeta{}, false
}

func refreshProfileList() {
	if profileListHwnd == 0 {
		return
	}
	modelMu.RLock()
	ps := append([]ProfileMeta(nil), profilesModel...)
	selID := selectedProfileID
	modelMu.RUnlock()
	profileListIDs = nil
	pSendMessageW.Call(profileListHwnd, LB_RESETCONTENT, 0, 0)
	selIndex := 0
	for i, p := range ps {
		suffix := L("Normal", "Normal")
		if p.Mode == "randomizer" {
			suffix = "Randomizer"
			if p.Seed != "" {
				suffix += " • " + seedLabel(p.Seed)
			}
		}
		label := fmt.Sprintf("%s    [%s]", p.Name, suffix)
		pSendMessageW.Call(profileListHwnd, LB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16Ptr(label))))
		profileListIDs = append(profileListIDs, p.ID)
		if p.ID == selID {
			selIndex = i
		}
	}
	if len(ps) > 0 {
		pSendMessageW.Call(profileListHwnd, LB_SETCURSEL, uintptr(selIndex), 0)
	}
}

func refreshSelectedDetails() {
	if cfg.UseRandomizer {
		if _, label := currentRandomizerImportSource(); label != "" {
			setWindowText(seedImportStatusHwnd, L("Seed détecté : ", "Seed detected: ")+label)
		} else {
			setWindowText(seedImportStatusHwnd, L("Aucun seed prêt à importer", "No seed ready to import"))
		}
	} else {
		setWindowText(seedImportStatusHwnd, L("Randomizer : non configuré", "Randomizer: not configured"))
	}
	p, ok := selectedProfile()
	if !ok {
		for _, h := range []uintptr{profileNameHwnd, profileModeHwnd, profileSeedHwnd, seedStatusHwnd, latestSaveHwnd, playTimeHwnd, profileReadyHwnd} {
			setWindowText(h, "—")
		}
		selectedSaves = nil
		if saveListHwnd != 0 {
			pSendMessageW.Call(saveListHwnd, LB_RESETCONTENT, 0, 0)
		}
		return
	}
	setWindowText(profileNameHwnd, p.Name)
	if p.Mode == "randomizer" {
		setWindowText(profileModeHwnd, "Randomizer")
		if p.Seed == "" {
			setWindowText(profileSeedHwnd, L("Non définie", "Not set"))
		} else {
			setWindowText(profileSeedHwnd, p.Seed)
		}
		cached := getProfileViewCache(p.ID)
		if !cfg.UseRandomizer || !cfg.UseModEngine {
			setWindowText(seedStatusHwnd, L("INTÉGRATION REQUISE — configure ModEngine 2 + Randomizer", "INTEGRATION REQUIRED — configure ModEngine 2 + Randomizer"))
		} else if cached.SeedReady {
			setWindowText(seedStatusHwnd, L("Prête — fichiers sauvegardés avec ce profil", "Ready — files stored with this profile"))
		} else {
			setWindowText(seedStatusHwnd, L("NON IMPORTÉE — génère la seed puis importe-la", "NOT IMPORTED — generate the seed then import it"))
		}
	} else {
		setWindowText(profileModeHwnd, L("Normal", "Normal"))
		setWindowText(profileSeedHwnd, "—")
		setWindowText(seedStatusHwnd, L("Non utilisé", "Not used"))
	}
	lastSession := formatPlayTime(p.LastSessionSeconds)
	playText := fmt.Sprintf(L("Total %s • Dernière %s • %d sessions", "Total %s • Last %s • %d sessions"), formatPlayTime(p.TotalPlaySeconds), lastSession, p.SessionCount)
	setWindowText(playTimeHwnd, playText)
	cached := getProfileViewCache(p.ID)
	ready := L("✓ PRÊT À JOUER", "✓ READY TO PLAY")
	if len(cached.Saves) == 0 {
		ready = L("✕ AUCUNE SAVE", "✕ NO SAVE")
	} else if p.Mode == "randomizer" && (!cfg.UseModEngine || !cfg.UseRandomizer) {
		ready = L("⚠ CONFIGURATION REQUISE", "⚠ SETUP REQUIRED")
	} else if p.Mode == "randomizer" && !cached.SeedReady {
		ready = L("⚠ SEED À IMPORTER", "⚠ IMPORT SEED")
	}
	if p.Locked {
		ready += L(" • 🔒 verrouillé", " • 🔒 locked")
	}
	setWindowText(profileReadyHwnd, ready)
	selectedSaves = cached.Saves
	pSendMessageW.Call(saveListHwnd, LB_RESETCONTENT, 0, 0)
	for i, sv := range selectedSaves {
		label := sv.Label
		if i == 0 {
			label = "★  " + label + L("   — dernière sauvegarde", "   — latest save")
		}
		pSendMessageW.Call(saveListHwnd, LB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16Ptr(label))))
	}
	if len(selectedSaves) > 0 {
		pSendMessageW.Call(saveListHwnd, LB_SETCURSEL, 0, 0)
		setWindowText(latestSaveHwnd, selectedSaves[0].Label)
	} else {
		setWindowText(latestSaveHwnd, L("Aucune sauvegarde", "No save"))
	}
}

func refreshAllUI() {
	curText := L("Aucun profil chargé", "No profile loaded")
	if p, ok := currentProfile(); ok {
		curText = p.Name + "  •  "
		if p.Mode == "randomizer" {
			curText += "Randomizer"
			if p.Seed != "" {
				curText += " • " + seedLabel(p.Seed)
			}
		} else {
			curText += "Normal"
		}
	}
	setWindowText(currentStatusHwnd, curText)
	invalidate(currentStatusHwnd)
	pUpdateWindow.Call(currentStatusHwnd)
	if cfg.UseModEngine {
		randoVisualState = detectRandoState()
		modText := L("ModEngine : OUI", "ModEngine: YES")
		if cfg.UseRandomizer {
			setWindowText(randoStatusHwnd, modText+" • Randomizer: "+randoVisualState)
		} else {
			setWindowText(randoStatusHwnd, modText+L(" • Randomizer : NON", " • Randomizer: NO"))
		}
	} else {
		randoVisualState = L("NON CONFIGURÉ", "NOT CONFIGURED")
		setWindowText(randoStatusHwnd, L("ModEngine : NON • Randomizer : NON", "ModEngine: NO • Randomizer: NO"))
	}
	refreshProfileList()
	refreshSelectedDetails()
	if h := actionButtons[idLockProfile]; h != 0 {
		if p, ok := selectedProfile(); ok && p.Locked {
			setWindowText(h, L("Déverrou", "Unlock"))
		} else {
			setWindowText(h, L("Verrou", "Lock"))
		}
	}
	setControlsEnabled(!busy && initialized)
	for _, h := range actionButtons {
		invalidate(h)
	}
}

func setControlsEnabled(enable bool) {
	defer updatePrimaryAction()
	if modalActive {
		enable = false
	}
	v := uintptr(0)
	if enable {
		v = 1
	}
	for _, h := range actionButtons {
		pEnableWindow.Call(h, v)
	}
	if profileListHwnd != 0 {
		pEnableWindow.Call(profileListHwnd, v)
	}
	if saveListHwnd != 0 {
		pEnableWindow.Call(saveListHwnd, v)
	}
	if enable {
		// Context-sensitive buttons.
		_, selOK := selectedProfile()
		_, curOK := currentProfile()
		if h := actionButtons[idRenameProfile]; h != 0 {
			if selOK {
				pEnableWindow.Call(h, 1)
			} else {
				pEnableWindow.Call(h, 0)
			}
		}
		if h := actionButtons[idDeleteProfile]; h != 0 {
			if p, ok := selectedProfile(); ok && !p.Locked {
				pEnableWindow.Call(h, 1)
			} else {
				pEnableWindow.Call(h, 0)
			}
		}
		if h := actionButtons[idDuplicateProfile]; h != 0 {
			if selOK {
				pEnableWindow.Call(h, 1)
			} else {
				pEnableWindow.Call(h, 0)
			}
		}
		if h := actionButtons[idLockProfile]; h != 0 {
			if selOK {
				pEnableWindow.Call(h, 1)
			} else {
				pEnableWindow.Call(h, 0)
			}
		}
		if h := actionButtons[idRecovery]; h != 0 {
			if fileExists(filepath.Join(recoverySaveDir(), "ER0000.sl2")) {
				pEnableWindow.Call(h, 1)
			} else {
				pEnableWindow.Call(h, 0)
			}
		}
		if h := actionButtons[idSwitch]; h != 0 {
			if selOK && len(selectedSaves) > 0 {
				pEnableWindow.Call(h, 1)
			} else {
				pEnableWindow.Call(h, 0)
			}
		}
		if h := actionButtons[idPlay]; h != 0 {
			if selOK && len(selectedSaves) > 0 {
				pEnableWindow.Call(h, 1)
			} else {
				pEnableWindow.Call(h, 0)
			}
		}
		for _, bid := range []int{idBackup, idNamedBackup} {
			if h := actionButtons[bid]; h != 0 {
				if curOK {
					pEnableWindow.Call(h, 1)
				} else {
					pEnableWindow.Call(h, 0)
				}
			}
		}
		if h := actionButtons[idLaunch]; h != 0 {
			if curOK {
				pEnableWindow.Call(h, 1)
			} else {
				pEnableWindow.Call(h, 0)
			}
		}
		if h := actionButtons[idImportSeed]; h != 0 {
			if p, ok := selectedProfile(); ok && p.Mode == "randomizer" && cfg.UseRandomizer && cfg.UseModEngine {
				pEnableWindow.Call(h, 1)
			} else {
				pEnableWindow.Call(h, 0)
			}
		}
		if h := actionButtons[idOpenRandomizer]; h != 0 {
			if cfg.UseRandomizer {
				pEnableWindow.Call(h, 1)
			} else {
				pEnableWindow.Call(h, 0)
			}
		}
	}
}

func setBusy(v bool) {
	busy = v
	if v {
		primaryAction = primaryActionState{}
	}
	setControlsEnabled(!v && initialized)
}

func startTask(status string, fn func() taskResult) {
	if busy {
		return
	}
	setBusy(true)
	setInfo(status)
	postProgress(status, 3)
	go func() {
		var r taskResult
		func() {
			defer func() {
				if rec := recover(); rec != nil {
					r = taskResult{Err: fmt.Errorf(L("erreur interne : %v", "internal error: %v"), rec)}
				}
			}()
			r = fn()
		}()
		taskMu.Lock()
		pendingTask = r
		taskMu.Unlock()
		pPostMessageW.Call(mainHwnd, WM_APP_TASKDONE, 0, 0)
	}()
}

func startInitialization() {
	busy = true
	initialized = false
	setControlsEnabled(false)
	postProgress(L("Initialisation en cours…", "Initialization in progress…"), 2)
	go func() {
		r := initializeApp()
		taskMu.Lock()
		pendingTask = r
		taskMu.Unlock()
		pPostMessageW.Call(mainHwnd, WM_APP_TASKDONE, 0, 0)
	}()
}

// ----------------------------- Actions --------------------------------------
func doCreateProfile() {
	name, ok := promptText(L("Nouveau profil", "New profile"), L("Nom du profil :\n\nUne copie indépendante de la SAVE DE RÉFÉRENCE protégée sera utilisée. La référence ne sera jamais jouée ni modifiée par cette run.", "Profile name:\n\nAn independent copy of the protected REFERENCE SAVE will be used. The reference will never be played or modified by this run."), "")
	if !ok || strings.TrimSpace(name) == "" {
		return
	}
	mode, seed := "normal", ""
	if cfg.UseModEngine && cfg.UseRandomizer {
		typeChoice := messageBox(L("Type du profil", "Profile type"), L("Ce profil utilisera-t-il le Randomizer ?\n\nOui = Randomizer\nNon = Jeu normal", "Will this profile use the Randomizer?\n\nYes = Randomizer\nNo = Normal game"), MB_YESNO|MB_ICONQUESTION)
		if typeChoice != IDYES && typeChoice != IDNO {
			return
		}
		if typeChoice == IDYES {
			mode = "randomizer"
			seedChoice := messageBox(L("Seed Randomizer", "Randomizer seed"), L("Veux-tu réutiliser un seed déjà importé dans le gestionnaire ?\n\nOui = entrer le nom/numéro d'un seed de la bibliothèque\nNon = créer le profil maintenant et importer/générer un seed plus tard", "Reuse a seed already imported into the manager?\n\nYes = enter a seed name/number from the library\nNo = create the profile now and import/generate a seed later"), MB_YESNO|MB_ICONQUESTION)
			if seedChoice != IDYES && seedChoice != IDNO {
				return
			}
			if seedChoice == IDYES {
				v, ok := promptText(L("Réutiliser un seed", "Reuse a seed"), L("Nom / numéro du seed :", "Seed name / number:"), "")
				if !ok || strings.TrimSpace(v) == "" {
					return
				}
				{
					v = strings.TrimSpace(v)
					if v != "" && validateRandomizerPackage(seedLibraryDir(v)) == nil {
						seed = v
					} else if v != "" {
						messageBox(L("Seed introuvable", "Seed not found"), L("Ce seed n'existe pas encore dans la bibliothèque. Le profil sera créé sans seed ; tu pourras l'importer ensuite.", "This seed is not in the library yet. The profile will be created without a seed; you can import it later."), MB_OK|MB_ICONWARNING)
					}
				}
			}
		}
	}
	startTask(L("Création du profil…", "Creating profile…"), func() taskResult {
		postProgress(L("Création du profil…", "Creating profile…"), 20)
		p, err := createProfile(name, mode, seed)
		if err != nil {
			return taskResult{Kind: "create", Err: err}
		}
		if mode == "randomizer" && seed != "" {
			postProgress(L("Association du seed existant…", "Attaching existing seed…"), 58)
			if err := attachLibrarySeedToProfile(p.ID, seed); err != nil {
				_ = os.RemoveAll(profileDir(p.ID))
				return taskResult{Kind: "create", Err: err}
			}
		}
		postProgress(L("Création de la première sauvegarde…", "Creating first save…"), 72)
		if err := reloadModel(p.ID); err != nil {
			return taskResult{Kind: "create", Err: err}
		}
		msg := L("Profil créé : ", "Profile created: ") + p.Name
		if mode == "randomizer" && seed == "" {
			msg += L("\n\nAucun seed n'a été chargé automatiquement. Génère/importes-en un quand tu veux, puis clique JOUER pour l'appliquer.", "\n\nNo seed was loaded automatically. Generate/import one whenever you want, then click PLAY to apply it.")
		} else if seed != "" {
			msg += L("\n\nSeed associé : ", "\n\nAttached seed: ") + seed + L("\nLe profil n'a PAS été chargé automatiquement.", "\nThe profile was NOT loaded automatically.")
		}
		return taskResult{Kind: "create", Message: msg, SelectedID: p.ID, ShowInfoBox: true, InfoBoxTitle: L("Profil créé", "Profile created")}
	})
}

func doImportExistingSave() {
	path, ok := chooseFile(L("Choisir ER0000.sl2 à importer", "Choose ER0000.sl2 to import"), "Elden Ring Save\x00ER0000.sl2\x00"+L("Tous les fichiers", "All files")+"\x00*.*\x00\x00")
	if !ok {
		return
	}
	if !strings.EqualFold(filepath.Base(path), "ER0000.sl2") {
		messageBox(L("Fichier invalide", "Invalid file"), L("Sélectionne le fichier ER0000.sl2 de la sauvegarde à importer.", "Select the ER0000.sl2 file from the save you want to import."), MB_OK|MB_ICONWARNING)
		return
	}
	name, ok := promptText(L("Importer une sauvegarde existante", "Import an existing save"), L("Nom du nouveau profil :", "New profile name:"), "")
	if !ok || strings.TrimSpace(name) == "" {
		return
	}
	r := messageBox(L("Type du profil", "Profile type"), L("Cette sauvegarde appartient-elle à une run Randomizer ?\n\nOui = profil Randomizer (la seed pourra être importée ensuite)\nNon = profil Normal", "Does this save belong to a Randomizer run?\n\nYes = Randomizer profile (the seed can be imported later)\nNo = Normal profile"), MB_YESNO|MB_ICONQUESTION)
	if r == IDCANCEL {
		return
	}
	mode := "normal"
	if r == IDYES {
		mode = "randomizer"
	}
	source := filepath.Dir(path)
	startTask(L("Import de la sauvegarde existante…", "Importing existing save…"), func() taskResult {
		postProgress(L("Création du profil…", "Creating profile…"), 25)
		p, err := createProfileFromExisting(name, mode, source)
		if err != nil {
			return taskResult{Kind: "import-existing", Err: err}
		}
		postProgress(L("Vérification de la copie…", "Verifying copy…"), 75)
		if err := reloadModel(p.ID); err != nil {
			return taskResult{Kind: "import-existing", Err: err}
		}
		msg := L("Sauvegarde importée sans modifier l'original.", "Save imported without modifying the original.")
		if mode == "randomizer" {
			msg += L("\n\nLe profil est marqué Randomizer. Importe sa seed avant de jouer si elle n'est pas encore associée.", "\n\nThe profile is marked Randomizer. Import its seed before playing if it is not already associated.")
		}
		return taskResult{Kind: "import-existing", Message: msg, SelectedID: p.ID, ShowInfoBox: true, InfoBoxTitle: L("Import terminé", "Import complete")}
	})
}

func doRenameProfile() {
	p, ok := selectedProfile()
	if !ok {
		return
	}
	name, ok := promptText(L("Renommer le profil", "Rename profile"), L("Nouveau nom :", "New name:"), p.Name)
	if !ok {
		return
	}
	name = strings.TrimSpace(name)
	if name == "" || name == p.Name {
		return
	}
	startTask(L("Renommage du profil…", "Renaming profile…"), func() taskResult {
		postProgress(L("Renommage du profil…", "Renaming profile…"), 35)
		if err := renameProfile(p.ID, name); err != nil {
			return taskResult{Kind: "rename", Err: err}
		}
		postProgress(L("Actualisation du profil…", "Refreshing profile…"), 82)
		if err := reloadModel(p.ID); err != nil {
			return taskResult{Kind: "rename", Err: err}
		}
		return taskResult{Kind: "rename", Message: L("Profil renommé en « ", "Profile renamed to ‘") + name + L(" ».", "’."), SelectedID: p.ID}
	})
}

func doDeleteProfile() {
	p, ok := selectedProfile()
	if !ok {
		return
	}
	if p.Locked {
		messageBox(L("Profil verrouillé", "Profile locked"), L("Déverrouille ce profil avant de le supprimer.", "Unlock this profile before deleting it."), MB_OK|MB_ICONWARNING)
		return
	}
	warning := L("Le profil « ", "Profile ‘") + p.Name + L(" » sera déplacé dans la corbeille interne.\n\nLes fichiers ne seront pas supprimés immédiatement.", "’ will be moved to the internal trash.\n\nFiles will not be permanently deleted immediately.")
	modelMu.RLock()
	isCurrent := currentProfileID == p.ID
	modelMu.RUnlock()
	if isCurrent {
		warning += L("\n\nATTENTION : c'est le profil actuellement chargé. AppData restera intact.", "\n\nWARNING: this is the currently loaded profile. AppData will remain untouched.")
	}
	if messageBox(L("Supprimer le profil ?", "Delete profile?"), warning+L("\n\nContinuer ?", "\n\nContinue?"), MB_YESNO|MB_ICONWARNING) != IDYES {
		return
	}
	startTask(L("Déplacement du profil vers la corbeille…", "Moving profile to trash…"), func() taskResult {
		postProgress(L("Déplacement dans la corbeille…", "Moving to trash…"), 35)
		if err := deleteProfileToTrash(p.ID); err != nil {
			return taskResult{Kind: "delete", Err: err}
		}
		modelMu.Lock()
		if currentProfileID == p.ID {
			currentProfileID = ""
		}
		if selectedProfileID == p.ID {
			selectedProfileID = ""
		}
		modelMu.Unlock()
		postProgress(L("Actualisation des profils…", "Refreshing profiles…"), 82)
		if err := reloadModel(""); err != nil {
			return taskResult{Kind: "delete", Err: err}
		}
		return taskResult{Kind: "delete", Message: L("Profil déplacé dans la corbeille interne.", "Profile moved to internal trash.")}
	})
}

func doDuplicateProfile() {
	p, ok := selectedProfile()
	if !ok {
		return
	}
	name, ok := promptText(L("Dupliquer le profil", "Duplicate profile"), L("Nom de la copie :", "Copy name:"), p.Name+L(" - Copie", " - Copy"))
	if !ok {
		return
	}
	startTask(L("Duplication du profil…", "Duplicating profile…"), func() taskResult {
		postProgress(L("Copie des saves et de la seed…", "Copying saves and seed…"), 35)
		np, err := duplicateProfile(p.ID, name)
		if err != nil {
			return taskResult{Kind: "duplicate", Err: err}
		}
		postProgress(L("Actualisation…", "Refreshing…"), 85)
		if err := reloadModel(np.ID); err != nil {
			return taskResult{Kind: "duplicate", Err: err}
		}
		return taskResult{Kind: "duplicate", Message: L("Profil dupliqué : ", "Profile duplicated: ") + np.Name, SelectedID: np.ID, ShowInfoBox: true, InfoBoxTitle: L("Duplication terminée", "Duplicate complete")}
	})
}

func doLockProfile() {
	p, ok := selectedProfile()
	if !ok {
		return
	}
	newState := !p.Locked
	startTask(L("Mise à jour du verrouillage…", "Updating lock…"), func() taskResult {
		if err := setProfileLocked(p.ID, newState); err != nil {
			return taskResult{Kind: "lock", Err: err}
		}
		if err := reloadModel(p.ID); err != nil {
			return taskResult{Kind: "lock", Err: err}
		}
		msg := L("Profil déverrouillé : ", "Profile unlocked: ") + p.Name
		if newState {
			msg = L("Profil verrouillé : ", "Profile locked: ") + p.Name
		}
		return taskResult{Kind: "lock", Message: msg, SelectedID: p.ID}
	})
}

func doRecovery() {
	if isGameRunning() {
		messageBox(L("Elden Ring est ouvert", "Elden Ring is running"), L("Ferme Elden Ring avant de restaurer une sauvegarde de secours.", "Close Elden Ring before restoring a recovery save."), MB_OK|MB_ICONWARNING)
		return
	}
	if !fileExists(filepath.Join(recoverySaveDir(), "ER0000.sl2")) {
		messageBox(L("Aucun secours", "No recovery"), L("Aucune sauvegarde de récupération n'est disponible.", "No recovery save is available."), MB_OK|MB_ICONINFORMATION)
		return
	}
	if messageBox(L("Restaurer le secours ?", "Restore recovery?"), L("La save actuellement dans AppData sera d'abord copiée dans la sauvegarde d'urgence, puis le dernier point de récupération sera restauré. Continuer ?", "The current AppData save will first be copied to the emergency backup, then the latest recovery point will be restored. Continue?"), MB_YESNO|MB_ICONWARNING) != IDYES {
		return
	}
	startTask(L("Restauration du secours…", "Restoring recovery…"), func() taskResult {
		postProgress(L("Sauvegarde d'urgence de l'état actuel…", "Emergency backup of current state…"), 25)
		_, _ = emergencyBackup()
		postProgress(L("Restauration du dernier point de récupération…", "Restoring latest recovery point…"), 65)
		if err := restoreRecoverySnapshot(); err != nil {
			return taskResult{Kind: "recovery", Err: err}
		}
		return taskResult{Kind: "recovery", Message: L("Sauvegarde de récupération restaurée dans AppData.", "Recovery save restored to AppData."), ShowInfoBox: true, InfoBoxTitle: L("Récupération terminée", "Recovery complete")}
	})
}

func doExportSelectedProfile() {
	p, ok := selectedProfile()
	if !ok {
		messageBox(L("Exporter", "Export"), L("Sélectionne d'abord un profil.", "Select a profile first."), MB_OK|MB_ICONINFORMATION)
		return
	}
	startTask(L("Export du profil…", "Exporting profile…"), func() taskResult {
		postProgress(L("Création du fichier ZIP…", "Creating ZIP file…"), 40)
		path, err := exportProfile(p.ID)
		if err != nil {
			return taskResult{Kind: "export", Err: err}
		}
		return taskResult{Kind: "export", Message: L("Profil exporté :\n", "Profile exported:\n") + path, ShowInfoBox: true, InfoBoxTitle: L("Export terminé", "Export complete")}
	})
}

func doImportProfileZip() {
	path, ok := chooseFile(L("Choisir un profil ZIP", "Choose profile ZIP"), "Profile ZIP\x00*.zip\x00"+L("Tous les fichiers", "All files")+"\x00*.*\x00\x00")
	if !ok {
		return
	}
	startTask(L("Import du profil…", "Importing profile…"), func() taskResult {
		postProgress(L("Lecture du ZIP…", "Reading ZIP…"), 30)
		p, err := importProfileZip(path)
		if err != nil {
			return taskResult{Kind: "import-profile", Err: err}
		}
		postProgress(L("Actualisation…", "Refreshing…"), 85)
		if err := reloadModel(p.ID); err != nil {
			return taskResult{Kind: "import-profile", Err: err}
		}
		return taskResult{Kind: "import-profile", Message: L("Profil importé : ", "Profile imported: ") + p.Name, SelectedID: p.ID, ShowInfoBox: true, InfoBoxTitle: L("Import terminé", "Import complete")}
	})
}

func doImportSeed() {
	if !cfg.UseRandomizer || !cfg.UseModEngine {
		messageBox(L("Randomizer non configuré", "Randomizer not configured"), L("Configure ModEngine 2 et Elden Ring Randomizer dans PARAMÈTRES.", "Configure ModEngine 2 and Elden Ring Randomizer in SETTINGS."), MB_OK|MB_ICONWARNING)
		return
	}
	if isGameRunning() {
		messageBox(L("Elden Ring est ouvert", "Elden Ring is running"), L("Ferme Elden Ring avant d'importer ou modifier une seed.", "Close Elden Ring before importing or changing a seed."), MB_OK|MB_ICONERROR)
		return
	}
	p, ok := selectedProfile()
	if !ok || p.Mode != "randomizer" {
		messageBox(L("Profil Randomizer requis", "Randomizer profile required"), L("Sélectionne d'abord un profil Randomizer.", "Select a Randomizer profile first."), MB_OK|MB_ICONINFORMATION)
		return
	}
	seed, ok := promptText(L("Importer le seed actuel", "Import current seed"), L("Nom / numéro du seed à associer à « ", "Seed name / number to associate with ‘")+p.Name+L(" » :\n\nCe nom permet aussi de réutiliser facilement le même seed sur un autre profil.", "’:\n\nThis name also lets you easily reuse the same seed on another profile."), p.Seed)
	if !ok || strings.TrimSpace(seed) == "" {
		return
	}
	source, sourceLabel, sourceOK := chooseRandomizerImportSource()
	if !sourceOK || source == "" {
		messageBox(L("Aucun seed détecté", "No seed detected"), L("Aucun regulation.bin Randomizer n'a été trouvé.\n\n1. Ouvre EldenRingRandomizer et génère le seed, OU garde ton seed déjà fonctionnel dans ModEngine 2.\n2. Reviens ici.\n3. Clique « Importer le seed actuel ».\n\nL'application ne modifie plus transfer.bat.", "No Randomizer regulation.bin was found.\n\n1. Open EldenRingRandomizer and generate the seed, OR keep your already working seed in ModEngine 2.\n2. Return here.\n3. Click ‘Import current seed’.\n\nThe application no longer modifies transfer.bat."), MB_OK|MB_ICONWARNING)
		return
	}
	confirm := fmt.Sprintf(L("Source détectée : %s\n\nAssocier cette configuration au profil « %s » ?\n\nL'original ne sera pas supprimé ni chargé automatiquement.", "Detected source: %s\n\nAssociate this configuration with profile ‘%s’?\n\nThe original will not be deleted or loaded automatically."), sourceLabel, p.Name)
	if messageBox(L("Importer le seed", "Import seed"), confirm, MB_YESNO|MB_ICONQUESTION) != IDYES {
		return
	}
	modelMu.RLock()
	wasCurrent := currentProfileID == p.ID
	modelMu.RUnlock()
	startTask(L("Import du seed en cours…", "Importing seed…"), func() taskResult {
		postProgress(L("Copie de la configuration Randomizer…", "Copying Randomizer configuration…"), 25)
		if err := copyRandomizerPackage(source, profileRandoDir(p.ID)); err != nil {
			return taskResult{Kind: "seed", Err: err}
		}
		b, err := os.ReadFile(profileMetaPath(p.ID))
		if err != nil {
			return taskResult{Kind: "seed", Err: err}
		}
		var meta ProfileMeta
		if err := json.Unmarshal(b, &meta); err != nil {
			return taskResult{Kind: "seed", Err: err}
		}
		meta.Seed = strings.TrimSpace(seed)
		if err := saveProfileMeta(meta); err != nil {
			return taskResult{Kind: "seed", Err: err}
		}
		postProgress(L("Ajout à la bibliothèque de seeds…", "Adding to seed library…"), 72)
		if err := storeSeedInLibrary(meta.Seed, p.ID); err != nil {
			return taskResult{Kind: "seed", Err: err}
		}
		// If the profile was already installed, its files are now different from what is in
		// AppData/ModEngine. Mark it as needing an explicit reload; never deploy automatically.
		if wasCurrent {
			modelMu.Lock()
			currentProfileID = ""
			modelMu.Unlock()
			saveState()
		}
		if err := reloadModel(p.ID); err != nil {
			return taskResult{Kind: "seed", Err: err}
		}
		appendProfileEvent(p.ID, "seed", strings.TrimSpace(seed))
		msg := L("Seed importé et conservé dans la bibliothèque : ", "Seed imported and stored in the library: ") + strings.TrimSpace(seed)
		if wasCurrent {
			msg += L("\n\nLe profil n'a PAS été rechargé automatiquement. Clique JOUER quand tu veux appliquer le nouveau seed.", "\n\nThe profile was NOT reloaded automatically. Click PLAY when you want to apply the new seed.")
		}
		return taskResult{Kind: "seed", Message: msg, SelectedID: p.ID, ShowInfoBox: true, InfoBoxTitle: L("Seed importé", "Seed imported")}
	})
}

func doOpenRandomizer() {
	if !cfg.UseRandomizer {
		messageBox(L("Randomizer non configuré", "Randomizer not configured"), L("Ouvre PARAMÈTRES pour configurer Elden Ring Randomizer.", "Open SETTINGS to configure Elden Ring Randomizer."), MB_OK|MB_ICONWARNING)
		return
	}
	exe := randomizerExePath()
	if !fileExists(exe) {
		messageBox(L("Randomizer introuvable", "Randomizer not found"), L("Impossible de trouver :\n", "Cannot find:\n")+exe, MB_OK|MB_ICONERROR)
		return
	}
	cmd := exec.Command(exe)
	cmd.Dir = cfg.RandApp
	if err := cmd.Start(); err != nil {
		messageBox(L("Erreur", "Error"), L("Impossible d'ouvrir EldenRingRandomizer :\n", "Unable to open EldenRingRandomizer:\n")+err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	setInfo(L("EldenRingRandomizer ouvert. Génère ta seed, puis reviens cliquer « Importer le seed actuel ». Aucun transfer.bat n'est modifié.", "EldenRingRandomizer opened. Generate your seed, then return and click ‘Import current seed’. No transfer.bat is modified."))
}

func doBackup() {
	if isGameRunning() {
		messageBox(L("Elden Ring est ouvert", "Elden Ring is running"), L("Ferme Elden Ring avant de sauvegarder le profil.", "Close Elden Ring before saving the profile."), MB_OK|MB_ICONERROR)
		return
	}
	p, ok := currentProfile()
	if !ok {
		messageBox(L("Aucun profil actuel", "No current profile"), L("Charge d'abord un profil.", "Load a profile first."), MB_OK|MB_ICONINFORMATION)
		return
	}
	startTask(L("Sauvegarde du profil actuel…", "Saving current profile…"), func() taskResult {
		postProgress(L("Vérification de la save AppData…", "Checking AppData save…"), 15)
		label, err := backupCurrentProfile(p.ID)
		if err != nil {
			return taskResult{Kind: "backup", Err: err}
		}
		postProgress(L("Validation de la nouvelle sauvegarde…", "Validating new save…"), 88)
		appendProfileEvent(p.ID, "manual-backup", label)
		_ = reloadModel(selectedProfileID)
		return taskResult{Kind: "backup", Message: L("Progression sauvegardée : ", "Progress saved: ") + p.Name + " • " + label}
	})
}

func doNamedBackup() {
	if isGameRunning() {
		messageBox(L("Elden Ring est ouvert", "Elden Ring is running"), L("Ferme Elden Ring avant de créer un point important.", "Close Elden Ring before creating an important point."), MB_OK|MB_ICONERROR)
		return
	}
	p, ok := currentProfile()
	if !ok {
		messageBox(L("Aucun profil actuel", "No current profile"), L("Charge d'abord un profil.", "Load a profile first."), MB_OK|MB_ICONINFORMATION)
		return
	}
	name, ok := promptText(L("Créer un point de sauvegarde important", "Create an important save point"), L("Nom du point (ex. Avant NG+, Avant DLC, Build final) :\n\nCe point est conservé dans l'historique du profil.", "Point name (e.g. Before NG+, Before DLC, Final build):\n\nThis point is kept in the profile history."), "")
	if !ok || strings.TrimSpace(name) == "" {
		return
	}
	startTask(L("Création du point important…", "Creating important save point…"), func() taskResult {
		postProgress(L("Copie sécurisée de la save…", "Securely copying save…"), 35)
		label, err := backupCurrentProfileNamed(p.ID, name)
		if err != nil {
			return taskResult{Kind: "named-backup", Err: err}
		}
		_ = reloadModel(p.ID)
		return taskResult{Kind: "named-backup", Message: L("Point important créé : ", "Important point created: ") + label}
	})
}

func doSwitch(launchAfter bool) {
	if isGameRunning() {
		messageBox(L("Elden Ring est ouvert", "Elden Ring is running"), L("Ferme Elden Ring avant de changer de profil.", "Close Elden Ring before switching profiles."), MB_OK|MB_ICONERROR)
		return
	}
	p, ok := selectedProfile()
	if !ok {
		return
	}
	if err := validateModEngineLauncher(); err != nil {
		messageBox(L("ModEngine 2 requis", "ModEngine 2 required"), err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	if len(selectedSaves) == 0 {
		messageBox(L("Aucune sauvegarde", "No save"), L("Ce profil n'a aucune sauvegarde valide.", "This profile has no valid save."), MB_OK|MB_ICONERROR)
		return
	}
	if p.Mode == "randomizer" && (!cfg.UseModEngine || !cfg.UseRandomizer) {
		messageBox(L("Intégration requise", "Integration required"), L("Ce profil Randomizer nécessite ModEngine 2 + Elden Ring Randomizer. Configure-les dans PARAMÈTRES.", "This Randomizer profile requires ModEngine 2 + Elden Ring Randomizer. Configure them in SETTINGS."), MB_OK|MB_ICONWARNING)
		return
	}
	sel, _, _ := pSendMessageW.Call(saveListHwnd, LB_GETCURSEL, 0, 0)
	idx := int(sel)
	if sel == ^uintptr(0) || idx < 0 || idx >= len(selectedSaves) {
		idx = 0
	}
	sv := selectedSaves[idx]
	curName := L("Aucun", "None")
	if cp, ok := currentProfile(); ok {
		curName = cp.Name
	}
	mode := "Normal"
	if p.Mode == "randomizer" {
		mode = "Randomizer"
		if p.Seed != "" {
			mode += " • " + seedLabel(p.Seed)
		}
	}
	actionLine := L("Le profil sera chargé sans lancer le jeu.", "The profile will be loaded without launching the game.")
	if launchAfter {
		actionLine = L("Le profil sera chargé puis Elden Ring sera lancé automatiquement.", "The profile will be loaded and Elden Ring will launch automatically.")
	}
	summary := fmt.Sprintf(L("Profil actuel : %s\n\nProfil à charger : %s\nMode : %s\nSauvegarde : %s\n\nLe profil actuel sera sauvegardé automatiquement avant le changement.\n%s\n\nContinuer ?", "Current profile: %s\n\nProfile to load: %s\nMode: %s\nSave: %s\n\nThe current profile will be saved automatically before switching.\n%s\n\nContinue?"), curName, p.Name, mode, sv.Label, actionLine)
	if messageBox(L("Confirmer le changement", "Confirm switch"), summary, MB_YESNO|MB_ICONQUESTION) != IDYES {
		return
	}
	modelMu.RLock()
	oldID := currentProfileID
	modelMu.RUnlock()
	target := p
	selectedSave := sv
	startTask(L("Changement de profil en cours…", "Switching profile…"), func() taskResult {
		if target.Mode == "randomizer" {
			postProgress(L("Étape 1/5 — Vérification de la seed…", "Step 1/5 — Checking seed…"), 10)
			if err := validateRandoProfile(target); err != nil {
				return taskResult{Kind: "switch", Err: err}
			}
		} else {
			postProgress(L("Étape 1/5 — Vérification du profil normal…", "Step 1/5 — Checking normal profile…"), 10)
		}

		postProgress(L("Étape 2/5 — Sauvegarde du profil actuel…", "Step 2/5 — Saving current profile…"), 25)
		if oldID != "" {
			if _, err := backupCurrentProfile(oldID); err != nil {
				return taskResult{Kind: "switch", Err: fmt.Errorf(L("le profil actuel n'a pas pu être sauvegardé : %w", "current profile could not be saved: %w"), err)}
			}
		} else if fileExists(filepath.Join(appDataSave(), "ER0000.sl2")) {
			if _, err := emergencyBackup(); err != nil {
				return taskResult{Kind: "switch", Err: fmt.Errorf(L("la sauvegarde de sécurité automatique a échoué : %w", "automatic safety backup failed: %w"), err)}
			}
		}

		postProgress(L("Étape 3/5 — Configuration des intégrations…", "Step 3/5 — Configuring integrations…"), 45)
		modChanged := false
		rb := ""
		if cfg.UseModEngine {
			rb = filepath.Join(rollbackRoot(), time.Now().Format("2006-01-02_15-04-05"))
			_ = os.RemoveAll(rb)
			if err := snapshotModState(rb); err != nil {
				return taskResult{Kind: "switch", Err: fmt.Errorf(L("impossible de créer la sécurité des mods : %w", "unable to create mod safety snapshot: %w"), err)}
			}
			if target.Mode == "randomizer" {
				if err := deployRandomizerProfile(target); err != nil {
					return taskResult{Kind: "switch", Err: fmt.Errorf(L("déploiement de la seed impossible : %w", "unable to deploy seed: %w"), err)}
				}
				modChanged = true
			} else {
				if err := restoreBaseModState(); err != nil {
					return taskResult{Kind: "switch", Err: fmt.Errorf(L("restauration de l'état ModEngine normal impossible : %w", "unable to restore normal ModEngine state: %w"), err)}
				}
				modChanged = true
			}
		}

		postProgress(L("Étape 4/5 — Point de récupération + chargement de la save…", "Step 4/5 — Recovery point + loading save…"), 70)
		if fileExists(filepath.Join(appDataSave(), "ER0000.sl2")) {
			if err := createRecoverySnapshot(); err != nil {
				if modChanged && rb != "" {
					_ = restoreModState(rb)
				}
				return taskResult{Kind: "switch", Err: fmt.Errorf(L("impossible de créer le point de récupération : %w", "unable to create recovery point: %w"), err)}
			}
		}
		if err := mirrorCopy(selectedSave.Path, appDataSave()); err != nil {
			if modChanged && rb != "" {
				_ = restoreModState(rb)
			}
			return taskResult{Kind: "switch", Err: fmt.Errorf(L("chargement de la sauvegarde impossible : %w", "unable to load save: %w"), err)}
		}
		postProgress(L("Étape 5/5 — Vérification finale…", "Step 5/5 — Final verification…"), 94)
		modelMu.Lock()
		currentProfileID = target.ID
		selectedProfileID = target.ID
		modelMu.Unlock()
		saveState()
		if rb != "" {
			_ = os.RemoveAll(rb)
		}
		_ = reloadModel(target.ID)
		appendProfileEvent(target.ID, "switch", selectedSave.Label)
		return taskResult{Kind: "switch", Message: L("Profil chargé : ", "Profile loaded: ") + target.Name + " • " + selectedSave.Label, CurrentID: target.ID, SelectedID: target.ID, LaunchAfter: launchAfter, LoadedSavePath: selectedSave.Path}
	})
}

func startGameWatch(profileID, profileName string) {
	if !cfg.AutoSaveOnExit {
		return
	}
	gameWatchMu.Lock()
	if gameWatchActive {
		gameWatchMu.Unlock()
		return
	}
	gameWatchActive = true
	gameWatchMu.Unlock()
	go func() {
		defer func() { gameWatchMu.Lock(); gameWatchActive = false; gameWatchMu.Unlock() }()
		deadline := time.Now().Add(90 * time.Second)
		for !isGameRunning() && time.Now().Before(deadline) {
			time.Sleep(1 * time.Second)
		}
		if !isGameRunning() {
			return
		}
		started := time.Now()
		logLine("Elden Ring detected • profile=" + profileName)
		for isGameRunning() {
			time.Sleep(2 * time.Second)
		}
		sessionSeconds := int64(time.Since(started).Seconds())
		if sessionSeconds < 0 {
			sessionSeconds = 0
		}
		// Smart autosave: wait until ER0000.sl2 stops changing before copying it.
		waitForSaveStable(filepath.Join(appDataSave(), "ER0000.sl2"), 18*time.Second)
		modelMu.RLock()
		stillCurrent := currentProfileID == profileID
		modelMu.RUnlock()
		if !stillCurrent {
			return
		}
		_ = updateProfileMeta(profileID, func(p *ProfileMeta) {
			p.TotalPlaySeconds += sessionSeconds
			p.LastSessionSeconds = sessionSeconds
			p.SessionCount++
			p.LastPlayedAt = time.Now().Format(time.RFC3339)
		})
		label, err := backupCurrentProfile(profileID)
		appendProfileEvent(profileID, "session", fmt.Sprintf("%s", formatPlayTime(sessionSeconds)))
		if err == nil {
			appendProfileEvent(profileID, "autosave", label)
			_ = reloadModel(profileID)
		}
		r := taskResult{Kind: "autosave", Err: err, SelectedID: profileID}
		if err == nil {
			r.Message = fmt.Sprintf(L("Session terminée : %s • Total : %s • Autosave : %s", "Session ended: %s • Total: %s • Autosave: %s"), formatPlayTime(sessionSeconds), func() string {
				if p, ok := findProfile(profileID); ok {
					return formatPlayTime(p.TotalPlaySeconds)
				}
				return "—"
			}(), label)
		}
		autoMu.Lock()
		pendingAuto = r
		autoMu.Unlock()
		pPostMessageW.Call(mainHwnd, WM_APP_AUTOSAVE, 0, 0)
	}()
}

func doLaunch() {
	if isGameRunning() {
		messageBox("Elden Ring", L("Elden Ring est déjà ouvert.", "Elden Ring is already running."), MB_OK|MB_ICONINFORMATION)
		return
	}
	p, ok := currentProfile()
	if !ok {
		messageBox(L("Aucun profil chargé", "No profile loaded"), L("Charge un profil avant de lancer Elden Ring.", "Load a profile before launching Elden Ring."), MB_OK|MB_ICONWARNING)
		return
	}
	cmd, err := profileLaunchCommand(p)
	if err != nil {
		messageBox(L("Lancement refusé", "Launch refused"), err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	if err := cmd.Start(); err != nil {
		messageBox(L("Erreur", "Error"), L("Impossible de lancer ModEngine :\n", "Unable to launch ModEngine:\n")+err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	setInfo(L("Elden Ring lancé via ModEngine 2 • Profil : ", "Elden Ring launched via ModEngine 2 • Profile: ") + p.Name)
	logLine("launch via ModEngine • " + p.Name)
	appendProfileEvent(p.ID, "launch", "ModEngine 2")
	startGameWatch(p.ID, p.Name)
}

func doRefresh() {
	startTask(L("Actualisation des profils et sauvegardes…", "Refreshing profiles and saves…"), func() taskResult {
		postProgress(L("Lecture des profils…", "Reading profiles…"), 25)
		modelMu.RLock()
		selID := selectedProfileID
		modelMu.RUnlock()
		if err := reloadModel(selID); err != nil {
			return taskResult{Kind: "refresh", Err: err}
		}
		if cfg.UseModEngine {
			postProgress(L("Vérification de l'état du Randomizer…", "Checking Randomizer state…"), 82)
			_ = detectRandoState()
		}
		return taskResult{Kind: "refresh", Message: L("Profils et sauvegardes actualisés.", "Profiles and saves refreshed.")}
	})
}

func doHistory() {
	if pageKind != "" {
		destroyPage()
	}
	p, ok := selectedProfile()
	if !ok {
		p, ok = currentProfile()
	}
	if !ok {
		messageBox(L("Sauvegardes", "Saves"), L("Sélectionne d'abord un profil.", "Select a profile first."), MB_OK|MB_ICONINFORMATION)
		return
	}
	beginPageBuild()
	pageKind = "history"
	setControlsEnabled(false)
	cw, ch := pageClientSize()
	pagePanelHwnd = pageAdd(mainHwnd, "STATIC", "", 0, WS_CHILD|WS_VISIBLE|WS_BORDER, 0, 0, cw, ch, 0, 0)
	panel := pagePanelHwnd
	pageAdd(panel, "STATIC", L("SAUVEGARDES / HISTORIQUE", "SAVES / HISTORY"), 0, WS_CHILD|WS_VISIBLE, 36, 24, cw-72, 42, 0, fontTitle)
	mode := L("Normal", "Normal")
	if p.Mode == "randomizer" {
		mode = "Randomizer"
		if p.Seed != "" {
			mode += " • " + seedLabel(p.Seed)
		}
	}
	summary := fmt.Sprintf(L("%s  •  %s  •  Temps total %s  •  %d sessions", "%s  •  %s  •  Total playtime %s  •  %d sessions"), p.Name, mode, formatPlayTime(p.TotalPlaySeconds), p.SessionCount)
	pageAdd(panel, "STATIC", summary, 0, WS_CHILD|WS_VISIBLE, 38, 70, cw-76, 28, 0, fontSection)

	pageAdd(panel, "BUTTON", L("Sauvegarder le profil installé", "Save installed profile"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 38, 108, 240, 42, idBackup, fontNormal)
	pageAdd(panel, "BUTTON", L("Créer un point important", "Create important point"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 290, 108, 220, 42, idNamedBackup, fontNormal)
	pageAdd(panel, "BUTTON", L("Récupération", "Recovery"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 522, 108, 170, 42, idRecovery, fontNormal)
	pageAdd(panel, "STATIC", L("Ces actions ne chargent jamais un autre profil automatiquement.", "These actions never load another profile automatically."), 0, WS_CHILD|WS_VISIBLE, 710, 116, cw-748, 28, 0, fontSmall)

	events := readProfileEvents(p.ID, 120)
	var b strings.Builder
	if len(events) == 0 {
		b.WriteString(L("Aucun événement enregistré pour le moment.", "No recorded events yet."))
	}
	for _, e := range events {
		t, err := time.Parse(time.RFC3339, e.Time)
		ts := e.Time
		if err == nil {
			ts = t.Local().Format("02-01-06 15:04:05")
		}
		kind := e.Kind
		switch e.Kind {
		case "session":
			kind = L("SESSION", "SESSION")
		case "autosave":
			kind = L("AUTOSAVE", "AUTOSAVE")
		case "switch":
			kind = L("PROFIL CHARGÉ", "PROFILE LOADED")
		case "named-backup":
			kind = L("POINT IMPORTANT", "IMPORTANT POINT")
		case "manual-backup":
			kind = L("SAUVEGARDE MANUELLE", "MANUAL SAVE")
		case "seed":
			kind = "SEED"
		case "launch":
			kind = L("JEU LANCÉ", "GAME LAUNCHED")
		}
		fmt.Fprintf(&b, "%s   %-18s   %s\r\n", ts, kind, e.Detail)
	}
	pageAdd(panel, "EDIT", b.String(), WS_EX_CLIENTEDGE, WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY, 38, 168, cw-76, ch-246, 0, fontNormal)
	pageAdd(panel, "BUTTON", L("RETOUR", "BACK"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, cw-190, ch-62, 152, 40, idPageBack, fontNormal)
	endPageBuild()
}

func helpText() string {
	fr := "ELDEN RING PROFILE MANAGER — AIDE / TUTORIEL\r\n\r\n" +
		"DÉMARRAGE RAPIDE\r\n1. Configure une seule fois Elden Ring, AppData, la save de référence, ModEngine 2 et Randomizer si tu les utilises.\r\n2. Crée ou importe un profil.\r\n3. Sélectionne-le puis clique ▶ JOUER.\r\n4. L'application ne charge JAMAIS automatiquement un profil après une création, un import, un changement de seed ou une simple sélection.\r\n\r\n" +
		"SAVE DE RÉFÉRENCE\r\n• C'est un MODÈLE PROTÉGÉ pour créer de futurs profils/runs.\r\n• Ne choisis PAS une sauvegarde que tu veux continuer à jouer comme référence.\r\n• Le dossier SteamID complet est copié, pas seulement ER0000.sl2.\r\n\r\n" +
		"PROFILS\r\n• PROFIL INSTALLÉ DANS ELDEN RING indique ce qui est réellement en place dans AppData.\r\n• Sélectionner un autre profil ne change rien dans Elden Ring.\r\n• ▶ JOUER effectue la sauvegarde de sécurité, installe explicitement le profil, prépare son environnement puis lance le jeu.\r\n• Charger sans lancer fait la même préparation sans démarrer Elden Ring.\r\n• Renommer, dupliquer, verrouiller ou supprimer sont rangés dans PROFIL / OUTILS.\r\n\r\n" +
		"RANDOMIZER / SEEDS\r\n• ModEngine 2 est requis pour jouer ; Randomizer reste optionnel.\r\n• Génère ton seed normalement dans EldenRingRandomizer, ou garde un seed déjà fonctionnel dans ModEngine 2.\r\n• Clique Importer le seed actuel : le gestionnaire reproduit le transfert Randomizer → ModEngine qui fonctionne et configure le chargement des DLL du helper.\r\n• Aucun transfer.bat n'est créé ni remplacé.\r\n• Les seeds importés sont conservés dans une bibliothèque et peuvent être réutilisés facilement sur de nouveaux profils.\r\n• Chaque profil Randomizer garde le seed qui lui est associé ; le déploiement dans ModEngine 2 se fait uniquement lors d'un ▶ Charger la partie explicite.\r\n\r\n" +
		"MODENGINE 2 / CONFIGURATION EXISTANTE\r\n• Si ton Randomizer, ModEngine 2, ou les deux sont déjà personnalisés et fonctionnent, l'application prend cette configuration existante comme référence au lieu de la remettre à zéro.\r\n• Le config_eldenring.toml propre fourni avec l'application sert uniquement de référence de secours pour une configuration standard.\r\n• Tous les profils, Normal comme Randomizer, passent par ModEngine 2. Aucun lancement direct via Steam.\r\n• L'application ne gère PAS les autres mods : leur installation et leur compatibilité restent à la charge de l'utilisateur.\r\n\r\n" +
		"SAUVEGARDES / SÉCURITÉ\r\n• Le dossier de sauvegarde complet est protégé avant un remplacement.\r\n• Des copies de récupération et des points importants peuvent être créés depuis SAUVEGARDES.\r\n• Les remplacements utilisent des dossiers temporaires uniques et des tentatives supplémentaires si Windows verrouille un fichier.\r\n• Après une session lancée depuis l'application, l'autosave attend que la sauvegarde se stabilise avant copie.\r\n\r\n" +
		"ORGANISATION\r\n• Accueil : sélectionner et jouer.\r\n• PROFIL / OUTILS : gestion rare du profil et dossiers utiles.\r\n• SAUVEGARDES : historique, sauvegarde manuelle, point important et récupération.\r\n• PARAMÈTRES : chemins, intégrations et apparence.\r\n• Les détails techniques restent hors du chemin principal pour garder l'application simple."
	en := "ELDEN RING PROFILE MANAGER — HELP / TUTORIAL\r\n\r\n" +
		"QUICK START\r\n1. Configure Elden Ring, AppData, the reference save, ModEngine 2 and Randomizer once if you use them.\r\n2. Create or import a profile.\r\n3. Select it and click ▶ PLAY.\r\n4. The app NEVER automatically loads a profile after creation, import, a seed change or simple selection.\r\n\r\n" +
		"REFERENCE SAVE\r\n• This is a PROTECTED TEMPLATE for future profiles/runs.\r\n• Do NOT choose a save you want to keep playing as the reference.\r\n• The complete SteamID folder is copied, not only ER0000.sl2.\r\n\r\n" +
		"PROFILES\r\n• PROFILE INSTALLED IN ELDEN RING shows what is actually installed in AppData.\r\n• Selecting another profile changes nothing in Elden Ring.\r\n• ▶ PLAY explicitly creates a safety save, installs the profile, prepares its environment and launches the game.\r\n• Load without launching performs the same preparation without starting Elden Ring.\r\n• Rename, duplicate, lock and delete are kept under PROFILE / TOOLS.\r\n\r\n" +
		"RANDOMIZER / SEEDS\r\n• ModEngine 2 is required to play; Randomizer remains optional.\r\n• Generate your seed normally in EldenRingRandomizer, or keep a seed that already works in ModEngine 2.\r\n• Click Import current seed: the manager reproduces the working Randomizer → ModEngine transfer and configures the helper DLL loading.\r\n• No transfer.bat is created or replaced.\r\n• Imported seeds are kept in a library and can easily be reused on new profiles.\r\n• Each Randomizer profile keeps its assigned seed; deployment to ModEngine 2 happens only after an explicit ▶ Load save action.\r\n\r\n" +
		"MODENGINE 2 / EXISTING SETUP\r\n• If your Randomizer, ModEngine 2, or both are already customized and working, the app uses that existing setup as a reference instead of resetting it.\r\n• The clean config_eldenring.toml bundled with the app is only a fallback reference for a standard setup.\r\n• All profiles, Normal and Randomizer, launch through ModEngine 2. No direct Steam launch.\r\n• The app does NOT manage other mods: their installation and compatibility remain the user's responsibility.\r\n\r\n" +
		"SAVES / SAFETY\r\n• The complete save folder is protected before replacement.\r\n• Recovery copies and important points can be created from SAVES.\r\n• Replacements use unique temporary folders and additional retries when Windows locks a file.\r\n• After a session launched from the app, autosave waits for the save to become stable before copying it.\r\n\r\n" +
		"ORGANIZATION\r\n• Home: select and play.\r\n• PROFILE / TOOLS: occasional profile management and useful folders.\r\n• SAVES: history, manual save, important point and recovery.\r\n• SETTINGS: paths, integrations and appearance.\r\n• Technical details stay out of the main workflow to keep the app easy to understand."
	return L(fr, en)
}

func doHelp() {
	if pageKind != "" {
		destroyPage()
	}
	beginPageBuild()
	pageKind = "help"
	setControlsEnabled(false)
	cw, ch := pageClientSize()
	pagePanelHwnd = pageAdd(mainHwnd, "STATIC", "", 0, WS_CHILD|WS_VISIBLE|WS_BORDER, 0, 0, cw, ch, 0, 0)
	p := pagePanelHwnd
	pageAdd(p, "STATIC", L("AIDE / TUTORIEL", "HELP / TUTORIAL"), 0, WS_CHILD|WS_VISIBLE, 36, 24, cw-72, 42, 0, fontTitle)
	pageAdd(p, "STATIC", L("Guide intégré — Échap ou RETOUR pour revenir au gestionnaire.", "Built-in guide — Escape or BACK to return to the manager."), 0, WS_CHILD|WS_VISIBLE, 38, 68, cw-76, 26, 0, fontNormal)
	pageAdd(p, "EDIT", helpText(), WS_EX_CLIENTEDGE, WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY, 38, 108, cw-76, ch-188, 0, fontNormal)
	pageAdd(p, "BUTTON", L("RETOUR", "BACK"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, cw-190, ch-62, 152, 40, idHelpClose, fontNormal)
	endPageBuild()
}

// ----------------------------- Folder center / appearance actions -----------
var folderClassRegistered bool

func folderWndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		createChild(hwnd, "STATIC", L("CENTRE DES DOSSIERS", "FOLDER CENTER"), 0, WS_CHILD|WS_VISIBLE, 24, 20, 500, 30, 0, fontSection)
		createChild(hwnd, "STATIC", L("Ouvre directement l'Explorateur Windows au bon endroit.", "Open Windows Explorer directly at the right location."), 0, WS_CHILD|WS_VISIBLE, 24, 50, 500, 24, 0, fontSmall)
		createChild(hwnd, "BUTTON", L("Dossier du profil sélectionné", "Selected profile folder"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON, 24, 88, 246, 42, idFolderProfile, fontNormal)
		createChild(hwnd, "BUTTON", L("Saves du profil", "Profile saves"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON, 284, 88, 246, 42, idFolderSaves, fontNormal)
		createChild(hwnd, "BUTTON", L("Seed / fichiers Randomizer", "Seed / Randomizer files"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON, 24, 142, 246, 42, idFolderSeed, fontNormal)
		createChild(hwnd, "BUTTON", L("Bibliothèque de seeds", "Seed library"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON, 284, 142, 246, 42, idFolderSeedImport, fontNormal)
		createChild(hwnd, "BUTTON", "AppData Elden Ring", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON, 24, 210, 246, 42, idFolderAppData, fontNormal)
		createChild(hwnd, "BUTTON", "ModEngine 2", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON, 284, 210, 246, 42, idFolderModEngine, fontNormal)
		createChild(hwnd, "BUTTON", L("Dossier Randomizer", "Randomizer folder"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON, 24, 264, 246, 42, idFolderRandApp, fontNormal)
		createChild(hwnd, "BUTTON", L("Dossier du gestionnaire", "Manager folder"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON, 284, 264, 246, 42, idFolderApp, fontNormal)
		createChild(hwnd, "BUTTON", L("Exporter le profil", "Export profile"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON, 24, 318, 246, 42, idFolderExport, fontNormal)
		createChild(hwnd, "BUTTON", L("Importer un profil ZIP", "Import profile ZIP"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON, 284, 318, 246, 42, idFolderImport, fontNormal)
		createChild(hwnd, "BUTTON", L("Fermer", "Close"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON, 390, 382, 140, 38, idFolderClose, fontNormal)
		return 0
	case WM_COMMAND:
		id := loword(wParam)
		switch id {
		case idFolderProfile, idFolderSaves, idFolderSeed:
			p, ok := selectedProfile()
			if !ok {
				messageBox(L("Dossiers", "Folders"), L("Sélectionne d'abord un profil.", "Select a profile first."), MB_OK|MB_ICONINFORMATION)
				return 0
			}
			switch id {
			case idFolderProfile:
				openExplorer(profileDir(p.ID))
			case idFolderSaves:
				openExplorer(profileSavesDir(p.ID))
			case idFolderSeed:
				if p.Mode != "randomizer" {
					messageBox(L("Profil normal", "Normal profile"), L("Ce profil n'utilise pas de seed Randomizer.", "This profile does not use a Randomizer seed."), MB_OK|MB_ICONINFORMATION)
				} else {
					_ = os.MkdirAll(profileRandoDir(p.ID), 0755)
					openExplorer(profileRandoDir(p.ID))
				}
			}
		case idFolderSeedImport:
			if cfg.UseRandomizer {
				_ = os.MkdirAll(seedImportRoot(), 0755)
				openExplorer(seedImportRoot())
			} else {
				messageBox(L("Randomizer non configuré", "Randomizer not configured"), L("Configure le Randomizer dans PARAMÈTRES.", "Configure the Randomizer in SETTINGS."), MB_OK|MB_ICONINFORMATION)
			}
		case idFolderAppData:
			openExplorer(appDataSave())
		case idFolderModEngine:
			openExplorer(cfg.ModEngine)
		case idFolderRandApp:
			openExplorer(cfg.RandApp)
		case idFolderApp:
			openExplorer(exeDir())
		case idFolderExport:
			pDestroyWindow.Call(hwnd)
			doExportSelectedProfile()
		case idFolderImport:
			pDestroyWindow.Call(hwnd)
			doImportProfileZip()
		case idFolderClose:
			pDestroyWindow.Call(hwnd)
		}
		return 0
	case WM_CLOSE:
		pDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		folderDialogHwnd = 0
		pEnableWindow.Call(mainHwnd, 1)
		pSetForegroundWindow.Call(mainHwnd)
		return 0
	case WM_CTLCOLORSTATIC:
		hdc := wParam
		pSetBkMode.Call(hdc, TRANSPARENT)
		pSetTextColor.Call(hdc, colText)
		return brushBg
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func ensureFolderClass() {
	if folderClassRegistered {
		return
	}
	hInst, _, _ := pGetModuleHandleW.Call(0)
	cursor, _, _ := pLoadCursorW.Call(0, IDC_ARROW)
	cn := utf16Ptr("EldenRingFoldersPublicV1")
	wc := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), LpfnWndProc: syscall.NewCallback(folderWndProc), HInstance: hInst, HCursor: cursor, HbrBackground: brushBg, LpszClassName: cn, HIcon: appIcon, HIconSm: appIcon}
	if r, _, _ := pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); r != 0 {
		folderClassRegistered = true
	}
}

func doFolders() {
	if pageKind != "" {
		destroyPage()
	}
	beginPageBuild()
	pageKind = "folders"
	setControlsEnabled(false)
	cw, ch := pageClientSize()
	pagePanelHwnd = pageAdd(mainHwnd, "STATIC", "", 0, WS_CHILD|WS_VISIBLE|WS_BORDER, 0, 0, cw, ch, 0, 0)
	pnl := pagePanelHwnd
	pageAdd(pnl, "STATIC", L("PROFIL / OUTILS", "PROFILE / TOOLS"), 0, WS_CHILD|WS_VISIBLE, 36, 24, cw-72, 42, 0, fontTitle)
	name := L("Aucun profil sélectionné", "No profile selected")
	locked := false
	if sp, ok := selectedProfile(); ok {
		name = sp.Name
		locked = sp.Locked
	}
	pageAdd(pnl, "STATIC", L("Profil sélectionné : ", "Selected profile: ")+name, 0, WS_CHILD|WS_VISIBLE, 38, 68, cw-76, 28, 0, fontSection)

	pageAdd(pnl, "STATIC", L("GESTION DU PROFIL", "PROFILE MANAGEMENT"), 0, WS_CHILD|WS_VISIBLE, 60, 112, cw-120, 26, 0, fontSection)
	pageAdd(pnl, "BUTTON", L("Renommer", "Rename"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 60, 146, 170, 40, idRenameProfile, fontNormal)
	pageAdd(pnl, "BUTTON", L("Dupliquer", "Duplicate"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 242, 146, 170, 40, idDuplicateProfile, fontNormal)
	lockText := L("Verrouiller", "Lock")
	if locked {
		lockText = L("Déverrouiller", "Unlock")
	}
	pageAdd(pnl, "BUTTON", lockText, 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 424, 146, 170, 40, idLockProfile, fontNormal)
	pageAdd(pnl, "BUTTON", L("Supprimer", "Delete"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, 606, 146, 170, 40, idDeleteProfile, fontNormal)
	pageAdd(pnl, "STATIC", L("Ces actions modifient uniquement le profil dans le gestionnaire. Elles ne le chargent pas dans Elden Ring.", "These actions only change the profile inside the manager. They do not load it into Elden Ring."), 0, WS_CHILD|WS_VISIBLE, 794, 150, cw-834, 36, 0, fontSmall)

	pageAdd(pnl, "STATIC", L("DOSSIERS UTILES", "USEFUL FOLDERS"), 0, WS_CHILD|WS_VISIBLE, 60, 214, cw-120, 26, 0, fontSection)
	left := 60
	right := cw/2 + 10
	bw := cw/2 - 80
	y := 250
	gap := 54
	pageAdd(pnl, "BUTTON", L("Dossier du profil", "Profile folder"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, left, y, bw, 40, idFolderProfile, fontNormal)
	pageAdd(pnl, "BUTTON", L("Sauvegardes du profil", "Profile saves"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, right, y, bw, 40, idFolderSaves, fontNormal)
	y += gap
	pageAdd(pnl, "BUTTON", L("Seed du profil", "Profile seed"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, left, y, bw, 40, idFolderSeed, fontNormal)
	pageAdd(pnl, "BUTTON", L("Bibliothèque de seeds", "Seed library"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, right, y, bw, 40, idFolderSeedImport, fontNormal)
	y += gap
	pageAdd(pnl, "BUTTON", "AppData Elden Ring", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, left, y, bw, 40, idFolderAppData, fontNormal)
	pageAdd(pnl, "BUTTON", "ModEngine 2", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, right, y, bw, 40, idFolderModEngine, fontNormal)
	y += gap
	pageAdd(pnl, "BUTTON", L("Dossier Randomizer", "Randomizer folder"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, left, y, bw, 40, idFolderRandApp, fontNormal)
	pageAdd(pnl, "BUTTON", L("Dossier du gestionnaire", "Manager folder"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, right, y, bw, 40, idFolderApp, fontNormal)
	y += gap
	pageAdd(pnl, "BUTTON", L("Exporter le profil ZIP", "Export profile ZIP"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, left, y, bw, 40, idFolderExport, fontNormal)
	pageAdd(pnl, "BUTTON", L("Importer un profil ZIP", "Import profile ZIP"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, right, y, bw, 40, idFolderImport, fontNormal)
	pageAdd(pnl, "STATIC", L("Les autres mods ne sont pas gérés par cette application : ModEngine2 reste responsable de leur fonctionnement.", "Other mods are not managed by this application: ModEngine2 remains responsible for them."), 0, WS_CHILD|WS_VISIBLE, 60, y+60, cw-120, 38, 0, fontSmall)
	pageAdd(pnl, "BUTTON", L("RETOUR", "BACK"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, cw-190, ch-62, 152, 40, idPageBack, fontNormal)
	endPageBuild()
}

func doFullscreen() {
	if windowMaximized {
		pShowWindow.Call(mainHwnd, SW_RESTORE)
	} else {
		pShowWindow.Call(mainHwnd, SW_MAXIMIZE)
	}
}

func settingsDiagnosticText() string {
	lines := []string{}
	game := strings.TrimSpace(getWindowText(settingsGameEdit))
	if fileExists(game) && strings.EqualFold(filepath.Base(game), "eldenring.exe") {
		lines = append(lines, L("✓ Elden Ring : eldenring.exe détecté", "✓ Elden Ring: eldenring.exe detected"))
	} else {
		lines = append(lines, L("✕ Elden Ring : eldenring.exe introuvable", "✕ Elden Ring: eldenring.exe not found"))
	}
	okSave := fileExists(filepath.Join(strings.TrimSpace(getWindowText(settingsSaveEdit)), "ER0000.sl2"))
	if okSave {
		lines = append(lines, L("✓ Save Elden Ring : ER0000.sl2 détecté", "✓ Elden Ring save: ER0000.sl2 detected"))
	} else {
		lines = append(lines, L("✕ Save Elden Ring : ER0000.sl2 introuvable", "✕ Elden Ring save: ER0000.sl2 not found"))
	}
	ref := strings.TrimSpace(getWindowText(settingsReferenceEdit))
	refOK := fileExists(filepath.Join(ref, "ER0000.sl2")) || fileExists(filepath.Join(templateRoot(), "ER0000.sl2"))
	if refOK {
		lines = append(lines, L("✓ Save de référence : disponible / protégée", "✓ Reference save: available / protected"))
	} else {
		lines = append(lines, L("✕ Save de référence : non configurée", "✕ Reference save: not configured"))
	}
	data := strings.TrimSpace(getWindowText(settingsDataEdit))
	if data != "" {
		if err := os.MkdirAll(data, 0755); err == nil {
			test := filepath.Join(data, ".__write_test__")
			if os.WriteFile(test, []byte("ok"), 0644) == nil {
				_ = os.Remove(test)
				lines = append(lines, L("✓ Stockage : écriture autorisée", "✓ Storage: writable"))
			} else {
				lines = append(lines, L("✕ Stockage : écriture impossible", "✕ Storage: not writable"))
			}
		} else {
			lines = append(lines, L("✕ Stockage : dossier inaccessible", "✕ Storage: folder inaccessible"))
		}
	}
	if settingsTemp.UseModEngine || strings.TrimSpace(getWindowText(settingsModEngineEdit)) != "" {
		if fileExists(filepath.Join(strings.TrimSpace(getWindowText(settingsModEngineEdit)), "launchmod_eldenring.bat")) {
			lines = append(lines, "✓ ModEngine 2 : launchmod_eldenring.bat")
		} else {
			lines = append(lines, L("✕ ModEngine 2 : launchmod_eldenring.bat introuvable", "✕ ModEngine 2: launchmod_eldenring.bat not found"))
		}
	} else {
		lines = append(lines, L("○ ModEngine 2 : optionnel / désactivé", "○ ModEngine 2: optional / disabled"))
	}
	if settingsTemp.UseRandomizer || strings.TrimSpace(getWindowText(settingsRandomizerEdit)) != "" {
		if fileExists(filepath.Join(strings.TrimSpace(getWindowText(settingsRandomizerEdit)), "EldenRingRandomizer.exe")) {
			lines = append(lines, "✓ Elden Ring Randomizer : EldenRingRandomizer.exe")
		} else {
			lines = append(lines, L("✕ Randomizer : EldenRingRandomizer.exe introuvable", "✕ Randomizer: EldenRingRandomizer.exe not found"))
		}
	} else {
		lines = append(lines, L("○ Randomizer : optionnel / désactivé", "○ Randomizer: optional / disabled"))
	}
	return strings.Join(lines, "\n")
}

func handlePageCommand(id int) bool {
	if pageKind == "settings" {
		switch id {
		case idSettingsClose:
			if settingsFirstRun {
				if messageBox(L("Annuler la configuration ?", "Cancel setup?"), L("Aucun réglage ne sera enregistré et le gestionnaire va se fermer.\n\nContinuer ?", "No setting will be saved and the manager will close.\n\nContinue?"), MB_YESNO|MB_ICONWARNING) == IDYES {
					pDestroyWindow.Call(mainHwnd)
				}
			} else {
				destroyPage()
			}
			return true
		case idSettingsApply:
			applySettingsPage()
			return true
		case idSettingsLangFR:
			settingsTemp.Language = "fr"
			updateSettingsButtons()
			setSettingsStatus("Français sélectionné. Le changement complet sera visible après validation.")
			return true
		case idSettingsLangEN:
			settingsTemp.Language = "en"
			updateSettingsButtons()
			setSettingsStatus("English selected. Full language change will apply after validation.")
			return true
		case idSettingsBrowseGame:
			if path, ok := chooseFile(L("Choisir eldenring.exe", "Choose eldenring.exe"), "Elden Ring\x00eldenring.exe\x00"+L("Tous les fichiers", "All files")+"\x00*.*\x00\x00"); ok {
				if !strings.EqualFold(filepath.Base(path), "eldenring.exe") {
					setSettingsStatus(L("✕ Sélectionne eldenring.exe.", "✕ Select eldenring.exe."))
				} else {
					settingsTemp.GameExe = path
					setWindowText(settingsGameEdit, path)
					setSettingsStatus(L("✓ Elden Ring détecté.", "✓ Elden Ring detected."))
				}
			}
			return true
		case idSettingsBrowseSave:
			if dir, steam, ok := chooseSaveFolder(); ok {
				settingsTemp.SavePath = dir
				settingsTemp.SteamID = steam
				setWindowText(settingsSaveEdit, dir)
				setSettingsStatus(L("✓ Save Elden Ring détectée.", "✓ Elden Ring save detected."))
			}
			return true
		case idSettingsBrowseData:
			if dir, ok := chooseFolder(L("Choisir le dossier de stockage", "Choose storage folder")); ok {
				settingsTemp.DataRoot = dir
				setWindowText(settingsDataEdit, dir)
			}
			return true
		case idSettingsBrowseRef:
			if dir, _, ok := chooseSaveFolder(); ok {
				settingsTemp.ReferenceSource = dir
				setWindowText(settingsReferenceEdit, dir)
				setSettingsStatus(L("✓ Save de référence sélectionnée. Elle sera COPIÉE et protégée lors de l'application.", "✓ Reference save selected. It will be COPIED and protected when applying."))
			}
			return true
		case idSettingsToggleME:
			settingsTemp.UseModEngine = !settingsTemp.UseModEngine
			if !settingsTemp.UseModEngine {
				settingsTemp.UseRandomizer = false
				settingsTemp.LaunchNormalViaModEngine = false
			}
			updateSettingsButtons()
			return true
		case idSettingsBrowseME:
			if dir, ok := chooseModEngineFolder(); ok {
				settingsTemp.ModEngine = dir
				settingsTemp.UseModEngine = true
				setWindowText(settingsModEngineEdit, dir)
				updateSettingsButtons()
			}
			return true
		case idSettingsToggleNormalME:
			if settingsTemp.UseModEngine {
				settingsTemp.LaunchNormalViaModEngine = true
				updateSettingsButtons()
			}
			return true
		case idSettingsToggleRando:
			if !settingsTemp.UseModEngine {
				setSettingsStatus(L("⚠ Active d'abord ModEngine 2.", "⚠ Enable ModEngine 2 first."))
				return true
			}
			settingsTemp.UseRandomizer = !settingsTemp.UseRandomizer
			updateSettingsButtons()
			return true
		case idSettingsBrowseRando:
			if dir, ok := chooseRandomizerFolder(); ok {
				settingsTemp.RandApp = dir
				settingsTemp.UseRandomizer = true
				settingsTemp.UseModEngine = true
				setWindowText(settingsRandomizerEdit, dir)
				updateSettingsButtons()
			}
			return true
		case idSettingsToggleAutosave:
			settingsTemp.AutoSaveOnExit = !settingsTemp.AutoSaveOnExit
			updateSettingsButtons()
			return true
		case idSettingsBackground:
			if path, ok := chooseImageFile(); ok {
				settingsBackgroundSource = path
				settingsTemp.BackgroundImage = path
				setSettingsStatus(L("✓ Nouveau fond sélectionné. Il sera copié lors de l'application.", "✓ New background selected. It will be copied when applying."))
			}
			return true
		case idSettingsClearBackground:
			settingsBackgroundSource = ""
			settingsTemp.BackgroundImage = ""
			setSettingsStatus(L("Fond personnalisé désactivé (après APPLIQUER).", "Custom background disabled (after APPLY)."))
			return true
		case idSettingsDiagnostic:
			messageBox(L("Diagnostic des chemins", "Path diagnostic"), settingsDiagnosticText(), MB_OK|MB_ICONINFORMATION)
			return true
		case idSettingsPresetGold:
			applySettingsPreset("gold")
			return true
		case idSettingsPresetBlue:
			applySettingsPreset("blue")
			return true
		case idSettingsPresetViolet:
			applySettingsPreset("violet")
			return true
		case idSettingsPresetRed:
			applySettingsPreset("red")
			return true
		case idSettingsPresetDark:
			applySettingsPreset("dark")
			return true
		}
	}
	if pageKind == "help" {
		if id == idHelpClose || id == idPageBack {
			destroyPage()
			return true
		}
	}
	if pageKind == "history" {
		switch id {
		case idPageBack:
			destroyPage()
			return true
		case idBackup:
			destroyPage()
			doBackup()
			return true
		case idNamedBackup:
			destroyPage()
			doNamedBackup()
			return true
		case idRecovery:
			destroyPage()
			doRecovery()
			return true
		}
	}
	if pageKind == "folders" {
		switch id {
		case idRenameProfile:
			destroyPage()
			doRenameProfile()
			return true
		case idDuplicateProfile:
			destroyPage()
			doDuplicateProfile()
			return true
		case idLockProfile:
			destroyPage()
			doLockProfile()
			return true
		case idDeleteProfile:
			destroyPage()
			doDeleteProfile()
			return true
		case idPageBack, idFolderClose:
			destroyPage()
			return true
		case idFolderProfile, idFolderSaves, idFolderSeed:
			p, ok := selectedProfile()
			if !ok {
				messageBox(L("Dossiers", "Folders"), L("Sélectionne d'abord un profil.", "Select a profile first."), MB_OK|MB_ICONINFORMATION)
				return true
			}
			if id == idFolderProfile {
				openExplorer(profileDir(p.ID))
			}
			if id == idFolderSaves {
				_ = os.MkdirAll(profileSavesDir(p.ID), 0755)
				openExplorer(profileSavesDir(p.ID))
			}
			if id == idFolderSeed {
				if p.Mode != "randomizer" {
					messageBox(L("Profil normal", "Normal profile"), L("Ce profil n'utilise pas de seed Randomizer.", "This profile does not use a Randomizer seed."), MB_OK|MB_ICONINFORMATION)
				} else {
					_ = os.MkdirAll(profileRandoDir(p.ID), 0755)
					openExplorer(profileRandoDir(p.ID))
				}
			}
			return true
		case idFolderSeedImport:
			_ = os.MkdirAll(seedsRoot(), 0755)
			openExplorer(seedsRoot())
			return true
		case idFolderAppData:
			openExplorer(appDataSave())
			return true
		case idFolderModEngine:
			openExplorer(cfg.ModEngine)
			return true
		case idFolderRandApp:
			openExplorer(cfg.RandApp)
			return true
		case idFolderApp:
			openExplorer(exeDir())
			return true
		case idFolderExport:
			destroyPage()
			doExportSelectedProfile()
			return true
		case idFolderImport:
			destroyPage()
			doImportProfileZip()
			return true
		}
	}
	return false
}

// ----------------------------- Prompt dialog --------------------------------
type promptDialogState struct {
	Title, Label, Default string
	Hwnd, Edit            uintptr
	Done, OK              bool
	Result                string
}

var promptClassRegistered bool

func promptWndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		promptMu.Lock()
		promptState.Hwnd = hwnd
		label := promptState.Label
		def := promptState.Default
		promptMu.Unlock()
		createChild(hwnd, "EDIT", label, 0, WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY, 24, 20, 580, 112, 0, fontNormal)
		edit := createChild(hwnd, "EDIT", def, WS_EX_CLIENTEDGE, WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_AUTOHSCROLL, 24, 144, 580, 34, idPromptEdit, fontNormal)
		createChild(hwnd, "BUTTON", "OK", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_DEFPUSHBUTTON, 380, 202, 104, 36, idPromptOK, fontNormal)
		createChild(hwnd, "BUTTON", L("Annuler", "Cancel"), 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON, 496, 202, 104, 36, idPromptCancel, fontNormal)
		promptMu.Lock()
		promptState.Edit = edit
		promptMu.Unlock()
		pSetFocus.Call(edit)
		return 0
	case WM_COMMAND:
		id := loword(wParam)
		if id == idPromptOK || id == IDOK {
			promptMu.Lock()
			edit := promptState.Edit
			promptMu.Unlock()
			n, _, _ := pGetWindowTextLengthW.Call(edit)
			buf := make([]uint16, int(n)+1)
			if n > 0 {
				pGetWindowTextW.Call(edit, uintptr(unsafe.Pointer(&buf[0])), n+1)
			}
			res := strings.TrimSpace(syscall.UTF16ToString(buf))
			promptMu.Lock()
			promptState.Result = res
			promptState.OK = true
			promptState.Done = true
			promptMu.Unlock()
			pDestroyWindow.Call(hwnd)
			return 0
		} else if id == idPromptCancel || id == IDCANCEL {
			promptMu.Lock()
			promptState.OK = false
			promptState.Done = true
			promptMu.Unlock()
			pDestroyWindow.Call(hwnd)
			return 0
		}
	case WM_CLOSE:
		promptMu.Lock()
		promptState.OK = false
		promptState.Done = true
		promptMu.Unlock()
		pDestroyWindow.Call(hwnd)
		return 0
	case WM_CTLCOLORSTATIC:
		hdc := wParam
		pSetBkMode.Call(hdc, TRANSPARENT)
		pSetTextColor.Call(hdc, colText)
		return brushBg
	case WM_CTLCOLOREDIT:
		hdc := wParam
		pSetTextColor.Call(hdc, colText)
		pSetBkColor.Call(hdc, colPanel)
		return brushEdit
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func ensurePromptClass() {
	if promptClassRegistered {
		return
	}
	hInst, _, _ := pGetModuleHandleW.Call(0)
	cursor, _, _ := pLoadCursorW.Call(0, IDC_ARROW)
	cn := utf16Ptr("EldenRingPromptPublicV1")
	wc := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), LpfnWndProc: syscall.NewCallback(promptWndProc), HInstance: hInst, HCursor: cursor, HbrBackground: brushBg, LpszClassName: cn, HIcon: appIcon, HIconSm: appIcon}
	if r, _, _ := pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); r != 0 {
		promptClassRegistered = true
	}
}

// ----------------------------- Main window proc -----------------------------
func wndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		mainHwnd = hwnd
		createUI()
		pSetTimer.Call(hwnd, 1, 2000, 0)
		if appIcon != 0 {
			pSendMessageW.Call(hwnd, WM_SETICON, ICON_BIG, appIcon)
			pSendMessageW.Call(hwnd, WM_SETICON, ICON_SMALL, appIcon)
		}
		return 0
	case WM_COMMAND:
		id := loword(wParam)
		code := hiword(wParam)
		if modalActive {
			switch id {
			case idModalYes:
				modalResult = IDYES
				modalActive = false
			case idModalNo:
				modalResult = IDNO
				modalActive = false
			case idModalCancel, idModalEditCancel:
				modalResult = IDCANCEL
				modalActive = false
			case idModalOK:
				modalResult = IDOK
				modalActive = false
			case idModalEditOK:
				modalEditResult = getWindowText(modalEditHwnd)
				modalResult = IDOK
				modalActive = false
			}
			return 0
		}
		if pageKind != "" {
			if handlePageCommand(id) {
				return 0
			}
		}
		if busy || !initialized {
			return 0
		}
		if id == idSaveList && code == LBN_SELCHANGE {
			primaryAction = primaryActionState{}
			updatePrimaryAction()
			return 0
		}
		if id == idProfileList && code == LBN_SELCHANGE {
			primaryAction = primaryActionState{}
			sel, _, _ := pSendMessageW.Call(profileListHwnd, LB_GETCURSEL, 0, 0)
			idx := int(sel)
			if idx >= 0 && idx < len(profileListIDs) {
				modelMu.Lock()
				selectedProfileID = profileListIDs[idx]
				modelMu.Unlock()
				go saveState()
				refreshSelectedDetails()
				setControlsEnabled(true)
			}
			return 0
		}
		switch id {
		case idCreateProfile:
			doCreateProfile()
		case idImportExisting:
			doImportExistingSave()
		case idRenameProfile:
			doRenameProfile()
		case idDeleteProfile:
			doDeleteProfile()
		case idDuplicateProfile:
			doDuplicateProfile()
		case idLockProfile:
			doLockProfile()
		case idImportSeed:
			doImportSeed()
		case idOpenRandomizer:
			doOpenRandomizer()
		case idBackup:
			doBackup()
		case idNamedBackup:
			doNamedBackup()
		case idRecovery:
			doRecovery()
		case idSwitch:
			doSwitch(false)
		case idPlay:
			doPrimaryAction()
		case idLaunch:
			doLaunch()
		case idRefresh:
			doRefresh()
		case idFolders:
			doFolders()
		case idHistory:
			doHistory()
		case idBackground:
			setCustomBackground()
		case idHelp:
			doHelp()
		case idSettings:
			doSettings()
		}
		return 0
	case WM_APP_TASKDONE:
		taskMu.Lock()
		r := pendingTask
		taskMu.Unlock()
		if r.Kind == "init" {
			initialized = true
			busy = false
		} else {
			setBusy(false)
		}
		if r.Err != nil {
			postProgress(L("Échec — aucune étape supplémentaire ne sera exécutée.", "Failed — no further step will be executed."), 0)
			setInfo(L("Erreur : ", "Error: ") + r.Err.Error())
			logLine("ERREUR: " + r.Err.Error())
			messageBox(L("Erreur", "Error"), r.Err.Error(), MB_OK|MB_ICONERROR)
			refreshAllUI()
			return 0
		}
		postProgress(L("Terminé.", "Done."), 100)
		if r.SelectedID != "" {
			modelMu.Lock()
			selectedProfileID = r.SelectedID
			modelMu.Unlock()
		}
		if r.CurrentID != "" {
			modelMu.Lock()
			currentProfileID = r.CurrentID
			modelMu.Unlock()
		}
		saveState()
		refreshAllUI()
		if r.Kind == "switch" && r.LoadedSavePath != "" {
			armPrimaryAction(r.CurrentID, r.LoadedSavePath)
		}
		if r.Message != "" {
			setInfo(r.Message)
		} else {
			setInfo(L("Prêt.", "Ready."))
		}
		if r.ShowInfoBox && r.Message != "" {
			title := r.InfoBoxTitle
			if title == "" {
				title = L("Terminé", "Done")
			}
			messageBox(title, r.Message, MB_OK|MB_ICONINFORMATION)
		}
		invalidate(mainHwnd)
		if r.LaunchAfter {
			doLaunch()
		}
		return 0
	case WM_APP_PROGRESS:
		progressMu.Lock()
		p := pendingProgress
		progressMu.Unlock()
		pSendMessageW.Call(progressHwnd, PBM_SETPOS, uintptr(p.Percent), 0)
		setWindowText(progressTextHwnd, p.Text)
		return 0
	case WM_APP_AUTOSAVE:
		primaryAction = primaryActionState{}
		autoMu.Lock()
		r := pendingAuto
		autoMu.Unlock()
		if r.Err != nil {
			setInfo("Autosave après fermeture : erreur — " + r.Err.Error())
			logLine("AUTOSAVE ERREUR: " + r.Err.Error())
		} else {
			postProgress("Autosave terminée après fermeture d'Elden Ring.", 100)
			setInfo(r.Message)
			logLine(r.Message)
			refreshAllUI()
		}
		return 0
	case WM_SIZE:
		w := loword(lParam)
		h := hiword(lParam)
		if w > 0 && h > 0 {
			layoutControls(w, h)
		}
		windowMaximized = (wParam == 2)
		if pageKind != "" && pagePanelHwnd != 0 {
			pMoveWindow.Call(pagePanelHwnd, 0, 0, uintptr(w), uintptr(h), 1)
		}
		return 0
	case WM_ERASEBKGND:
		drawBackground(hwnd, wParam)
		return 1
	case WM_TIMER:
		if wParam == 1 && initialized {
			if cfg.UseRandomizer {
				if _, label := currentRandomizerImportSource(); label != "" {
					setWindowText(seedImportStatusHwnd, L("Seed détecté : ", "Seed detected: ")+label)
				} else {
					setWindowText(seedImportStatusHwnd, L("Aucun seed prêt à importer", "No seed ready to import"))
				}
			} else {
				setWindowText(seedImportStatusHwnd, L("Randomizer : non configuré", "Randomizer: not configured"))
			}
		}
		return 0
	case WM_KEYDOWN:
		if wParam == VK_ESCAPE && pageKind != "" && !modalActive {
			if settingsFirstRun && pageKind == "settings" {
				if messageBox(L("Annuler la configuration ?", "Cancel setup?"), L("Le gestionnaire va se fermer sans enregistrer la configuration.", "The manager will close without saving setup."), MB_YESNO|MB_ICONWARNING) == IDYES {
					pDestroyWindow.Call(mainHwnd)
				}
			} else {
				destroyPage()
			}
			return 0
		}
	case WM_DRAWITEM:
		dis := (*DRAWITEMSTRUCT)(unsafe.Pointer(lParam))
		if dis.CtlType == 5 { // ODT_STATIC
			drawImageLabel(hwnd, dis)
		} else if int(dis.CtlID) == idProfileList || int(dis.CtlID) == idSaveList {
			drawOwnerList(dis)
		} else {
			drawOwnerButton(dis)
		}
		return 1
	case WM_CTLCOLORSTATIC:
		hdc := wParam
		pSetBkMode.Call(hdc, 2)
		pSetBkColor.Call(hdc, colBg)
		color := colText
		if lParam == randoStatusHwnd {
			switch {
			case strings.HasPrefix(randoVisualState, "ACTIF") || strings.HasPrefix(randoVisualState, "ACTIVE"):
				color = colGreen
			case strings.HasPrefix(randoVisualState, "DÉSACTIVÉ") || strings.HasPrefix(randoVisualState, "DISABLED") || strings.HasPrefix(randoVisualState, "NON CONFIGURÉ") || strings.HasPrefix(randoVisualState, "NOT CONFIGURED"):
				color = colGold
			default:
				color = colRed
			}
		}
		pSetTextColor.Call(hdc, color)
		if lParam == modalPanelHwnd || lParam == pagePanelHwnd {
			return brushPanel
		}
		if pageKind == "" && paintLabelBackground(hwnd, lParam, hdc) {
			pSetBkMode.Call(hdc, TRANSPARENT)
			return hollowBrush
		}

		return brushBg
	case WM_CTLCOLORLISTBOX:
		hdc := wParam
		pSetTextColor.Call(hdc, colText)
		pSetBkColor.Call(hdc, colPanel)
		return brushPanel
	case WM_DESTROY:
		pKillTimer.Call(hwnd, 1)
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func prepareIcon() uintptr {
	b, err := embeddedFS.ReadFile("app.ico")
	if err != nil {
		return 0
	}
	p := filepath.Join(os.TempDir(), "EldenRing_Profile_Manager_Public_1.4.7.ico")
	_ = os.WriteFile(p, b, 0644)
	h, _, _ := pLoadImageW.Call(0, uintptr(unsafe.Pointer(utf16Ptr(p))), IMAGE_ICON, 0, 0, LR_LOADFROMFILE|LR_DEFAULTSIZE)
	return h
}

func main() {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	pSetProcessDPIAware.Call()

	// Load the portable public configuration before creating the UI so the
	// selected language is already available to every control.
	if err := loadOrCreateConfig(); err != nil {
		cfg = defaultConfig()
		messageBox("Elden Ring Profile Manager", "config.json: "+err.Error(), MB_OK|MB_ICONERROR)
	}
	// Public Preview 1.4 creates the main window first. Initial setup is an integrated page,
	// so the first launch no longer chains Windows-style popups.
	if cfg.FirstRunComplete {
		if err := ensureAppDirs(); err != nil {
			// A native box is kept only for a fatal error before the main window exists.
			r, _, _ := pMessageBoxW.Call(0, uintptr(unsafe.Pointer(utf16Ptr(err.Error()))), uintptr(unsafe.Pointer(utf16Ptr("Elden Ring Profile Manager"))), MB_OK|MB_ICONERROR)
			_ = r
			return
		}
	}

	appIcon = prepareIcon()
	brushBg, _, _ = pCreateSolidBrush.Call(colBg)
	hollowBrush, _, _ = pGetStockObject.Call(HOLLOW_BRUSH)
	applyThemeFromConfig()
	fontSmall, _, _ = pCreateFontW.Call(^uintptr(13), 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(utf16Ptr("Segoe UI"))))
	fontNormal, _, _ = pCreateFontW.Call(^uintptr(15), 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(utf16Ptr("Segoe UI"))))
	fontSection, _, _ = pCreateFontW.Call(^uintptr(17), 0, 0, 0, 600, 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(utf16Ptr("Segoe UI Semibold"))))
	fontTitle, _, _ = pCreateFontW.Call(^uintptr(28), 0, 0, 0, 600, 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(utf16Ptr("Segoe UI Semibold"))))

	hInst, _, _ := pGetModuleHandleW.Call(0)
	className := utf16Ptr("EldenRingProfileManagerPublicV12")
	cursor, _, _ := pLoadCursorW.Call(0, IDC_ARROW)
	wc := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), LpfnWndProc: syscall.NewCallback(wndProc), HInstance: hInst, HIcon: appIcon, HCursor: cursor, HbrBackground: brushBg, LpszClassName: className, HIconSm: appIcon}
	if r, _, _ := pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); r == 0 {
		return
	}
	width, height := 1260, 920
	sx, _, _ := pGetSystemMetrics.Call(0)
	sy, _, _ := pGetSystemMetrics.Call(1)
	x := (int(sx) - width) / 2
	y := (int(sy) - height) / 2
	title := L("Elden Ring Profile Manager — Aperçu public 1.4.7", "Elden Ring Profile Manager — Public Preview 1.4.7")
	hwnd, _, _ := pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(utf16Ptr(title))), WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_MAXIMIZEBOX|WS_THICKFRAME|WS_VISIBLE, uintptr(x), uintptr(y), uintptr(width), uintptr(height), 0, 0, hInst, 0)
	if hwnd == 0 {
		return
	}
	dark := int32(1)
	pDwmSetWindowAttribute.Call(hwnd, 20, uintptr(unsafe.Pointer(&dark)), unsafe.Sizeof(dark))
	if cfg.StartMaximized {
		pShowWindow.Call(hwnd, SW_MAXIMIZE)
		windowMaximized = true
	} else {
		pShowWindow.Call(hwnd, SW_SHOW)
		windowMaximized = false
	}
	pUpdateWindow.Call(hwnd)
	logLine("=== Elden Ring Profile Manager Public Preview 1.4.7 ===")
	if !cfg.FirstRunComplete || strings.TrimSpace(cfg.SavePath) == "" {
		busy = true
		initialized = false
		showSettingsPage(true)
	} else {
		startInitialization()
	}
	var m MSG
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
	for _, h := range []uintptr{fontSmall, fontNormal, fontSection, fontTitle, brushBg, brushPanel, brushEdit} {
		if h != 0 {
			pDeleteObject.Call(h)
		}
	}
}
