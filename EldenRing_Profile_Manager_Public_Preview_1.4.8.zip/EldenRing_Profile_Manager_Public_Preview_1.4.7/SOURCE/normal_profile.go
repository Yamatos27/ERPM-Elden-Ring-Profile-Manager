//go:build windows

package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/pelletier/go-toml/v2"
)

func isRandomizerHelperPath(path string) bool {
	name := strings.ToLower(filepath.Base(strings.ReplaceAll(path, "\\", "/")))
	return name == "randomizerhelper.dll" || name == "randomizercrashfix.dll"
}

func normalBaselineTrusted() bool {
	b, err := os.ReadFile(filepath.Join(baseModsRoot(), "baseline.json"))
	if err != nil {
		return false
	}
	var meta struct {
		State string `json:"randomizerStateAtCapture"`
	}
	if json.Unmarshal(b, &meta) != nil {
		return false
	}
	if meta.State != "DÉSACTIVÉ" && meta.State != "DISABLED" {
		return false
	}
	if dirExists(filepath.Join(baseModsRoot(), "mod", "diste")) {
		return false
	}
	for _, n := range requiredRandomizerDLLs {
		if fileExists(filepath.Join(baseModsRoot(), "root", n)) {
			return false
		}
	}
	return true
}

// A captured reference may itself be randomized. Never reinstall that payload
// for Normal. Preserve the user's current TOML and independent DLL entries.
func restoreBaseModState() error {
	if err := validateModEngineLauncher(); err != nil {
		return err
	}
	doc, b, err := readRandomizerConfig(modEngineConfigPath())
	if err != nil {
		return err
	}
	dlls, err := configDLLs(doc)
	if err != nil {
		return err
	}
	kept := make([]string, 0, len(dlls))
	for _, dll := range dlls {
		if !isRandomizerHelperPath(dll) {
			kept = append(kept, dll)
		}
	}
	text := string(b)
	if len(kept) != len(dlls) {
		encoded, err := toml.Marshal(map[string]any{"external_dlls": kept})
		if err != nil {
			return err
		}
		array := strings.TrimSpace(strings.SplitN(strings.TrimSpace(string(encoded)), "=", 2)[1])
		start, end, err := externalDLLSpan(text)
		if err != nil {
			return err
		}
		if start < 0 {
			return fmt.Errorf("external_dlls introuvable")
		}
		text = text[:start] + array + text[end:]
	}
	if err := copyFile(modEngineConfigPath(), uniqueSiblingPath(modEngineConfigPath(), "before-normal")); err != nil {
		return err
	}
	if normalBaselineTrusted() {
		if err := restoreTrustedBaseModState(); err != nil {
			return err
		}
	} else {
		// Do not delete the reference: it may be useful for recovery or seed import.
		if err := cleanRandomizerFromModEngine(); err != nil {
			return err
		}
	}
	if err := os.MkdirAll(modDir(), 0755); err != nil {
		return err
	}
	if err := os.WriteFile(modEngineConfigPath(), []byte(text), 0644); err != nil {
		return err
	}
	return validateNormalEnvironment()
}

func validateNormalEnvironment() error {
	doc, _, err := readRandomizerConfig(modEngineConfigPath())
	if err != nil {
		return err
	}
	dlls, err := configDLLs(doc)
	if err != nil {
		return err
	}
	for _, dll := range dlls {
		if isRandomizerHelperPath(dll) {
			return fmt.Errorf("profil Normal : %s est encore actif ; recharge le profil Normal avant de jouer", dll)
		}
	}
	if dirExists(filepath.Join(modDir(), "diste")) {
		return fmt.Errorf("profil Normal : fichiers Randomizer encore présents dans mod/diste ; recharge le profil")
	}
	// A regulation file is permitted only when it matches the verified normal reference.
	regulation := filepath.Join(modDir(), "regulation.bin")
	if fileExists(regulation) {
		if !normalBaselineTrusted() {
			return fmt.Errorf("profil Normal : regulation.bin sans référence normale vérifiée ; recharge le profil")
		}
		want, err := fileDigest(filepath.Join(baseModsRoot(), "mod", "regulation.bin"))
		if err != nil {
			return err
		}
		actual, err := fileDigest(regulation)
		if err != nil {
			return err
		}
		if actual != want {
			return fmt.Errorf("profil Normal : regulation.bin diffère de la référence normale ; recharge le profil")
		}
	}
	return nil
}
