//go:build windows

package main

import "testing"

func TestPrimaryActionRequiresExactLoadedSelection(t *testing.T) {
	loaded := primaryActionState{ProfileID: "a", SavePath: "older-save"}
	for _, test := range []struct {
		selected, current, path string
		ready                   bool
	}{
		{"a", "a", "older-save", true},
		{"b", "a", "older-save", false},
		{"a", "b", "older-save", false},
		{"a", "a", "newest-save", false},
		{"a", "a", "", false},
	} {
		if got := loaded.ready(test.selected, test.current, test.path); got != test.ready {
			t.Fatalf("%+v: got %v", test, got)
		}
	}
	if (primaryActionState{}).ready("a", "a", "older-save") {
		t.Fatal("startup/unloaded state can launch")
	}
}
