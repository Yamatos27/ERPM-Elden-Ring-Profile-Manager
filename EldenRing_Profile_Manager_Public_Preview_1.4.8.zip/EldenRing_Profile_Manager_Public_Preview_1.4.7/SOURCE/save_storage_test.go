package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestSaveCompressionRoundTripAndListing(t *testing.T) {
	old := cfg
	defer func() { cfg = old }()
	cfg.DataRoot = t.TempDir()
	cfg.SteamID = "123"
	p := ProfileMeta{ID: "test"}
	older := filepath.Join(profileSavesDir(p.ID), "2026-09-04_01-00-00", cfg.SteamID)
	latest := filepath.Join(profileSavesDir(p.ID), "2026-09-05_01-00-00", cfg.SteamID)
	put(t, filepath.Join(older, "ER0000.sl2"), "old-save-content")
	put(t, filepath.Join(older, "ER0000.sl2.bak"), "backup-content")
	put(t, filepath.Join(older, "nested", "other.bin"), "nested-content")
	put(t, filepath.Join(latest, "ER0000.sl2"), "latest-content")
	maintainSaveStorage([]ProfileMeta{p})
	if fileExists(filepath.Join(older, "ER0000.sl2")) || !fileExists(filepath.Join(older, saveArchiveName)) {
		t.Fatal("old snapshot not compressed")
	}
	if !fileExists(filepath.Join(latest, "ER0000.sl2")) {
		t.Fatal("latest compressed")
	}
	saves := listProfileSaves(p.ID)
	if len(saves) != 2 || saves[1].Path != older {
		t.Fatal("archive not listed at stable path")
	}
	dst := filepath.Join(t.TempDir(), "game")
	put(t, filepath.Join(dst, "ER0000.sl2"), "current")
	if err := mirrorCopy(older, dst); err != nil {
		t.Fatal(err)
	}
	for name, want := range map[string]string{"ER0000.sl2": "old-save-content", "ER0000.sl2.bak": "backup-content", "nested/other.bin": "nested-content"} {
		b, e := os.ReadFile(filepath.Join(dst, name))
		if e != nil || string(b) != want {
			t.Fatalf("restoration mismatch %s: %v", name, e)
		}
	}
	if fileExists(filepath.Join(dst, saveArchiveName)) {
		t.Fatal("archive deployed to game")
	}
	maintainSaveStorage([]ProfileMeta{p})
	if len(listProfileSaves(p.ID)) != 2 {
		t.Fatal("repeat maintenance damaged listing")
	}
}

func TestCorruptSaveArchivePreservesCurrentSave(t *testing.T) {
	root := t.TempDir()
	src := filepath.Join(root, "archive")
	dst := filepath.Join(root, "game")
	put(t, filepath.Join(src, saveArchiveName), "invalid zip")
	put(t, filepath.Join(dst, "ER0000.sl2"), "untouched")
	if err := mirrorCopy(src, dst); err == nil {
		t.Fatal("corrupt archive accepted")
	}
	b, _ := os.ReadFile(filepath.Join(dst, "ER0000.sl2"))
	if string(b) != "untouched" {
		t.Fatal("current save damaged")
	}
	if !fileExists(filepath.Join(src, saveArchiveName)) {
		t.Fatal("source lost")
	}
}
