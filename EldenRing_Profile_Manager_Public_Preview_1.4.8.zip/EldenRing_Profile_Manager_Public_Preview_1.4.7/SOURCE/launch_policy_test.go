//go:build windows

package main

import (
	"os"
	"reflect"
	"testing"
)

func TestNormalAlwaysUsesModEngine(t *testing.T) {
	_, p := fixture(t)
	p.Mode = "normal"
	cfg.LaunchNormalViaModEngine = false // old config must not restore direct Steam launch
	cmd, err := profileLaunchCommand(p)
	if err != nil {
		t.Fatal(err)
	}
	if cmd.Dir != cfg.ModEngine || !reflect.DeepEqual(cmd.Args, []string{"cmd.exe", "/d", "/c", ".\\launchmod_eldenring.bat"}) {
		t.Fatalf("wrong launch: %v, %s", cmd.Args, cmd.Dir)
	}
	cfg.UseModEngine = false
	if cmd, err := profileLaunchCommand(p); err == nil || cmd != nil {
		t.Fatal("disabled ME returned a fallback")
	}
	cfg.UseModEngine = true
	if err := os.Remove(launchBatPath()); err != nil {
		t.Fatal(err)
	}
	if cmd, err := profileLaunchCommand(p); err == nil || cmd != nil {
		t.Fatal("missing launcher returned a fallback")
	}
}

func TestRandomizerLaunchPolicyKeepsValidation(t *testing.T) {
	src, p := fixture(t)
	if cmd, err := profileLaunchCommand(p); err == nil || cmd != nil {
		t.Fatal("unimported Randomizer accepted")
	}
	if err := copyRandomizerPackage(src, profileRandoDir(p.ID)); err != nil {
		t.Fatal(err)
	}
	if err := deployRandomizerProfile(p); err != nil {
		t.Fatal(err)
	}
	if _, err := profileLaunchCommand(p); err != nil {
		t.Fatal(err)
	}
	cfg.UseRandomizer = false
	if cmd, err := profileLaunchCommand(p); err == nil || cmd != nil {
		t.Fatal("disabled Randomizer accepted")
	}
}
