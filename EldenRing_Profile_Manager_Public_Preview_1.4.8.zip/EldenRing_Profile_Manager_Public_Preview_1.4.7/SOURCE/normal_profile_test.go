//go:build windows

package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestRandomizedBaselineNeverRestoredForNormal(t *testing.T) {
	src, p := fixture(t)
	if err := copyRandomizerPackage(src, profileRandoDir(p.ID)); err != nil {
		t.Fatal(err)
	}
	put(t, filepath.Join(cfg.ModEngine, "ertransmogrify.dll"), "independent")
	b, _ := os.ReadFile(modEngineConfigPath())
	put(t, modEngineConfigPath(), strings.Replace(string(b), "'other.dll'", "'other.dll', 'ertransmogrify.dll'", 1))
	if err := deployRandomizerProfile(p); err != nil {
		t.Fatal(err)
	}
	// Reproduce the user's baseline.json: captured with Randomizer ACTIVE.
	if err := captureBaseModState(); err != nil {
		t.Fatal(err)
	}
	if normalBaselineTrusted() {
		t.Fatal("randomized baseline trusted")
	}
	normal := ProfileMeta{ID: "normal", Mode: "normal"}
	if _, err := profileLaunchCommand(normal); err == nil {
		t.Fatal("normal launch accepted active rando")
	}
	for i := 0; i < 2; i++ {
		if err := restoreBaseModState(); err != nil {
			t.Fatal(err)
		}
		if _, err := profileLaunchCommand(normal); err != nil {
			t.Fatal(err)
		}
		for _, name := range append([]string{"regulation.bin"}, managedRandoDirs...) {
			if pathExists(filepath.Join(modDir(), name)) {
				t.Fatal("seed restored into Normal", name)
			}
		}
		doc, _, err := readRandomizerConfig(modEngineConfigPath())
		if err != nil {
			t.Fatal(err)
		}
		dlls, _ := configDLLs(doc)
		if len(dlls) != 2 || dlls[1] != "ertransmogrify.dll" {
			t.Fatal("independent entries lost", dlls)
		}
		if err := deployRandomizerProfile(p); err != nil {
			t.Fatal(err)
		}
	}
	if !fileExists(filepath.Join(baseModsRoot(), "mod", "regulation.bin")) {
		t.Fatal("original reference destroyed")
	}
}

func TestVerifiedNormalBaselineRetained(t *testing.T) {
	_, p := fixture(t)
	p.Mode = "normal"
	put(t, filepath.Join(baseModsRoot(), "baseline.json"), `{"randomizerStateAtCapture":"DISABLED"}`)
	put(t, filepath.Join(baseModsRoot(), "mod", "regulation.bin"), "normal reference")
	put(t, filepath.Join(baseModsRoot(), "mod", "event", "normal.bin"), "normal event")
	put(t, filepath.Join(modDir(), "regulation.bin"), "randomizer")
	if err := restoreBaseModState(); err != nil {
		t.Fatal(err)
	}
	if _, err := profileLaunchCommand(p); err != nil {
		t.Fatal(err)
	}
	b, _ := os.ReadFile(filepath.Join(modDir(), "regulation.bin"))
	if string(b) != "normal reference" {
		t.Fatal("normal reference not restored")
	}
	put(t, filepath.Join(modDir(), "regulation.bin"), "unexpected")
	if _, err := profileLaunchCommand(p); err == nil {
		t.Fatal("mismatched Normal regulation accepted")
	}
}
