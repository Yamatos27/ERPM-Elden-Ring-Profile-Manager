//go:build windows

package main

type primaryActionState struct{ ProfileID, SavePath string }

var primaryAction primaryActionState

func (state primaryActionState) ready(selected, current, path string) bool {
	return state.ProfileID != "" && state.SavePath != "" && state.ProfileID == selected && selected == current && state.SavePath == path
}

func selectedSavePath() string {
	if len(selectedSaves) == 0 {
		return ""
	}
	idx, _, _ := pSendMessageW.Call(saveListHwnd, LB_GETCURSEL, 0, 0)
	if idx >= uintptr(len(selectedSaves)) {
		idx = 0
	}
	return selectedSaves[idx].Path
}

func primaryReady() bool {
	modelMu.RLock()
	selected, current := selectedProfileID, currentProfileID
	modelMu.RUnlock()
	return primaryAction.ready(selected, current, selectedSavePath())
}

func updatePrimaryAction() {
	h := actionButtons[idPlay]
	if h == 0 {
		return
	}
	label := L("1 · CHARGER LA PARTIE", "1 · LOAD SAVE")
	if busy {
		label = L("CHARGEMENT EN COURS…", "WORKING…")
	} else if primaryReady() {
		label = L("2 · ▶ JOUER", "2 · ▶ PLAY")
	}
	setWindowText(h, label)
}

func armPrimaryAction(profile, path string) {
	primaryAction = primaryActionState{}
	// Reloading the model defaults to the newest save; retain the exact loaded
	// selection, including when the user deliberately chose an older snapshot.
	for i, save := range selectedSaves {
		if save.Path == path {
			pSendMessageW.Call(saveListHwnd, LB_SETCURSEL, uintptr(i), 0)
			primaryAction = primaryActionState{ProfileID: profile, SavePath: path}
			break
		}
	}
	updatePrimaryAction()
}

func doPrimaryAction() {
	if busy || modalActive || !initialized {
		return
	}
	if primaryReady() {
		doLaunch()
		return
	}
	doSwitch(false)
}
