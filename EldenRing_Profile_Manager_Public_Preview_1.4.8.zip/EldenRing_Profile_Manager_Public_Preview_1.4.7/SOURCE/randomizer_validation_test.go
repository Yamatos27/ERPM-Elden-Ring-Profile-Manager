//go:build windows

package main

import (
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
)

func put(t *testing.T, path, content string) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, []byte(content), 0644); err != nil {
		t.Fatal(err)
	}
}

func fixture(t *testing.T) (string, ProfileMeta) {
	t.Helper()
	old := cfg
	t.Cleanup(func() { cfg = old })
	root := t.TempDir()
	cfg.DataRoot = filepath.Join(root, "manager")
	cfg.ModEngine = filepath.Join(root, "ModEngine with spaces")
	cfg.UseModEngine = true
	cfg.UseRandomizer = true
	p := ProfileMeta{ID: "test", Name: "test", Mode: "randomizer"}
	src := filepath.Join(root, "Randomizer", "randapp")
	put(t, filepath.Join(src, "regulation.bin"), "new-regulation")
	for _, n := range managedRandoDirs {
		put(t, filepath.Join(src, n, "nested", "payload.bin"), "new-"+n)
		if err := os.MkdirAll(filepath.Join(src, n, "empty"), 0755); err != nil {
			t.Fatal(err)
		}
	}
	for _, n := range append(append([]string{}, requiredRandomizerDLLs...), requiredRandomizerINIs...) {
		put(t, filepath.Join(src, "dll", n), "payload-"+n)
	}
	put(t, filepath.Join(src, "dll", "extra.txt"), "extra-text")
	put(t, filepath.Join(src, "dll", "empty_log.txt"), "")
	put(t, filepath.Join(src, "dll", "extra.ini"), "extra-ini")
	put(t, filepath.Join(src, "dll", "extra.dll"), "extra-dll")
	put(t, filepath.Join(src, "dll", "ignored.exe"), "ignored")
	put(t, launchBatPath(), "@echo off\n.\\modengine2_launcher.exe -t er -c .\\config_eldenring.toml\n")
	put(t, filepath.Join(cfg.ModEngine, "modengine2_launcher.exe"), "fake launcher, never executed")
	put(t, modEngineConfigPath(), "[modengine]\nexternal_dlls = ['other.dll'] # keep\ndebug = false\n[extension.mod_loader]\nenabled = true\nmods = [{enabled = true, name = 'default', path = 'mod'}]\n")
	put(t, filepath.Join(cfg.ModEngine, "other.dll"), "unrelated")
	return src, p
}

func TestDeploymentMatchesTransferBat(t *testing.T) {
	src, p := fixture(t)
	// Import via parent Randomizer/randapp as requested.
	if err := copyRandomizerPackage(filepath.Dir(src), profileRandoDir(p.ID)); err != nil {
		t.Fatal(err)
	}
	for _, n := range managedRandoDirs {
		put(t, filepath.Join(modDir(), n, "obsolete.bin"), "old")
	}
	put(t, filepath.Join(cfg.ModEngine, "RandomizerOld.ini"), "old")
	put(t, filepath.Join(modDir(), "parts", "unrelated.bin"), "keep")
	// A stale baseline must never overwrite current configuration or leak old seed files.
	put(t, filepath.Join(baseModsRoot(), "mod", "event", "baseline.bin"), "old baseline")
	if err := deployRandomizerProfile(p); err != nil {
		t.Fatal(err)
	}
	expected := map[string]string{"mod/regulation.bin": "new-regulation", "mod/parts/unrelated.bin": "keep", "other.dll": "unrelated"}
	for _, n := range managedRandoDirs {
		expected["mod/"+n+"/nested/payload.bin"] = "new-" + n
		if !dirExists(filepath.Join(modDir(), n, "empty")) {
			t.Fatal("empty directory lost", n)
		}
		if pathExists(filepath.Join(modDir(), n, "obsolete.bin")) {
			t.Fatal("old seed retained", n)
		}
	}
	for _, n := range append(append([]string{}, requiredRandomizerDLLs...), requiredRandomizerINIs...) {
		expected[n] = "payload-" + n
	}
	expected["extra.txt"] = "extra-text"
	expected["extra.ini"] = "extra-ini"
	expected["extra.dll"] = "extra-dll"
	for rel, want := range expected {
		got, err := os.ReadFile(filepath.Join(cfg.ModEngine, filepath.FromSlash(rel)))
		if err != nil || string(got) != want {
			t.Fatalf("transfer mismatch %s: %q %v", rel, got, err)
		}
	}
	for _, rel := range []string{"ignored.exe", "RandomizerOld.ini", "mod/event/baseline.bin"} {
		if pathExists(filepath.Join(cfg.ModEngine, filepath.FromSlash(rel))) {
			t.Fatal("unexpected deployment", rel)
		}
	}
	doc, _, err := readRandomizerConfig(modEngineConfigPath())
	if err != nil {
		t.Fatal(err)
	}
	dlls, err := configDLLs(doc)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(dlls, append([]string{"other.dll"}, requiredRandomizerDLLs...)) {
		t.Fatal(dlls)
	}
	cmd, err := randomizerLaunchCommand(p)
	if err != nil {
		t.Fatal(err)
	}
	if cmd.Dir != cfg.ModEngine || !reflect.DeepEqual(cmd.Args, []string{"cmd.exe", "/d", "/c", ".\\launchmod_eldenring.bat"}) {
		t.Fatalf("incorrect launch %v %s", cmd.Args, cmd.Dir)
	}
	// No process is started by this test. Post-deployment payload still exists.
	put(t, filepath.Join(modDir(), "regulation.bin"), "wrong seed")
	if _, err := randomizerLaunchCommand(p); err == nil || !strings.Contains(err.Error(), "regulation.bin") {
		t.Fatal("mismatched seed accepted", err)
	}
}

func TestIncompletePackagesRejected(t *testing.T) {
	src, p := fixture(t)
	only := filepath.Join(t.TempDir(), "legacy")
	put(t, filepath.Join(only, "regulation.bin"), "legacy")
	if err := validateRandomizerPackage(only); err == nil || !strings.Contains(err.Error(), "RandomizerHelper.dll") || !strings.Contains(err.Error(), "chr") {
		t.Fatal(err)
	}
	if err := copyRandomizerPackage(src, profileRandoDir(p.ID)); err != nil {
		t.Fatal(err)
	}
	for _, rel := range []string{"chr", "root/RandomizerHelper_config.ini", "root/RandomizerCrashFix.dll"} {
		t.Run(rel, func(t *testing.T) {
			dir := filepath.Join(t.TempDir(), "package")
			if err := copyTree(profileRandoDir(p.ID), dir); err != nil {
				t.Fatal(err)
			}
			if err := os.RemoveAll(filepath.Join(dir, filepath.FromSlash(rel))); err != nil {
				t.Fatal(err)
			}
			if err := validateRandomizerPackage(dir); err == nil {
				t.Fatal("missing required payload accepted")
			}
		})
	}
	before, err := os.ReadFile(filepath.Join(profileRandoDir(p.ID), "regulation.bin"))
	if err != nil {
		t.Fatal(err)
	}
	if err := copyRandomizerPackage(only, profileRandoDir(p.ID)); err == nil {
		t.Fatal("incomplete import accepted")
	}
	after, _ := os.ReadFile(filepath.Join(profileRandoDir(p.ID), "regulation.bin"))
	if string(before) != string(after) {
		t.Fatal("failed import replaced existing seed")
	}
}

func TestSourceWithoutChrAndReadableErrors(t *testing.T) {
	src, p := fixture(t)
	if err := os.RemoveAll(filepath.Join(src, "chr")); err != nil {
		t.Fatal(err)
	}
	if err := copyRandomizerPackage(src, profileRandoDir(p.ID)); err != nil {
		t.Fatal(err)
	}
	put(t, filepath.Join(modDir(), "chr", "old.bin"), "old seed")
	if err := deployRandomizerProfile(p); err != nil {
		t.Fatal(err)
	}
	if pathExists(filepath.Join(modDir(), "chr")) {
		t.Fatal("old chr retained")
	}
	if _, err := randomizerLaunchCommand(p); err != nil {
		t.Fatal(err)
	}
	put(t, filepath.Join(modDir(), "chr", "foreign.bin"), "unexpected")
	if _, err := randomizerLaunchCommand(p); err == nil {
		t.Fatal("unexpected chr accepted")
	}
	if err := os.RemoveAll(filepath.Join(profileRandoDir(p.ID), "event")); err != nil {
		t.Fatal(err)
	}
	err := validateRandoProfile(p)
	if err == nil || !strings.Contains(err.Error(), "event") || strings.Contains(err.Error(), profileRandoDir(p.ID)) {
		t.Fatalf("unreadable/missing validation: %v", err)
	}
}

func TestModEngineImportUsesModRegulation(t *testing.T) {
	src, p := fixture(t)
	if err := copyTree(src, modDir()); err != nil {
		t.Fatal(err)
	}
	for _, n := range append(append([]string{}, requiredRandomizerDLLs...), requiredRandomizerINIs...) {
		put(t, filepath.Join(cfg.ModEngine, n), "payload-"+n)
	}
	put(t, filepath.Join(cfg.ModEngine, "regulation.bin"), "WRONG root regulation")
	if err := copyRandomizerPackage(cfg.ModEngine, profileRandoDir(p.ID)); err != nil {
		t.Fatal(err)
	}
	b, _ := os.ReadFile(filepath.Join(profileRandoDir(p.ID), "regulation.bin"))
	if string(b) != "new-regulation" {
		t.Fatal("root regulation selected", string(b))
	}
}

func TestConfigCommentsAndIdempotence(t *testing.T) {
	src, p := fixture(t)
	if err := copyRandomizerPackage(src, profileRandoDir(p.ID)); err != nil {
		t.Fatal(err)
	}
	put(t, modEngineConfigPath(), "[modengine]\nexternal_dlls = [\n'other]file.dll' # comment with ] and \"RandomizerHelper.dll\"\n]\ndebug = false\n[extension.mod_loader]\nenabled = true\nmods = [{enabled=true,path='mod',name='default'}]\n")
	if err := ensureRandomizerDLLsInConfig(profileRandoDir(p.ID)); err != nil {
		t.Fatal(err)
	}
	a, _ := os.ReadFile(modEngineConfigPath())
	if err := ensureRandomizerDLLsInConfig(profileRandoDir(p.ID)); err != nil {
		t.Fatal(err)
	}
	b, _ := os.ReadFile(modEngineConfigPath())
	if string(a) != string(b) {
		t.Fatal("not idempotent")
	}
	for _, bad := range []string{"[modengine]\nexternal_dlls = [", "[modengine]\nexternal_dlls=[]\nexternal_dlls=[]"} {
		put(t, modEngineConfigPath(), bad)
		if err := ensureRandomizerDLLsInConfig(profileRandoDir(p.ID)); err == nil {
			t.Fatal("invalid TOML accepted")
		}
	}
}

func TestPrelaunchFailures(t *testing.T) {
	src, p := fixture(t)
	if err := copyRandomizerPackage(src, profileRandoDir(p.ID)); err != nil {
		t.Fatal(err)
	}
	if err := deployRandomizerProfile(p); err != nil {
		t.Fatal(err)
	}
	good, _ := os.ReadFile(modEngineConfigPath())
	for _, bad := range []string{strings.Replace(string(good), "enabled = true", "enabled = false", 1), strings.Replace(string(good), "path = 'mod'", "path = 'wrong'", 1), strings.Replace(string(good), "RandomizerHelper.dll", "Absent.dll", 1)} {
		put(t, modEngineConfigPath(), bad)
		if _, err := randomizerLaunchCommand(p); err == nil {
			t.Fatal("invalid environment allowed")
		}
	}
	put(t, modEngineConfigPath(), string(good))
	if err := os.Remove(launchBatPath()); err != nil {
		t.Fatal(err)
	}
	if _, err := randomizerLaunchCommand(p); err == nil {
		t.Fatal("missing launcher allowed")
	}
}

func TestTransmogIsIndependent(t *testing.T) {
	src, p := fixture(t)
	put(t, filepath.Join(src, "dll", "ertransmogrify.dll"), "unrelated source version")
	if err := copyRandomizerPackage(src, profileRandoDir(p.ID)); err != nil {
		t.Fatal(err)
	}
	if fileExists(filepath.Join(profileRandoDir(p.ID), "root", "ertransmogrify.dll")) {
		t.Fatal("unrelated mod imported")
	}
	// Legacy cache and baseline must not overwrite the installed independent mod.
	put(t, filepath.Join(profileRandoDir(p.ID), "root", "ertransmogrify.dll"), "legacy cache")
	put(t, filepath.Join(baseModsRoot(), "root", "ertransmogrify.dll"), "legacy baseline")
	put(t, filepath.Join(cfg.ModEngine, "ertransmogrify.dll"), "user dll")
	put(t, filepath.Join(cfg.ModEngine, "ertransmogrify.ini"), "user settings")
	b, _ := os.ReadFile(modEngineConfigPath())
	put(t, modEngineConfigPath(), strings.Replace(string(b), "'other.dll'", "'other.dll', 'ertransmogrify.dll'", 1))
	if err := deployRandomizerProfile(p); err != nil {
		t.Fatal(err)
	}
	doc, _, err := readRandomizerConfig(modEngineConfigPath())
	if err != nil {
		t.Fatal(err)
	}
	dlls, _ := configDLLs(doc)
	if !reflect.DeepEqual(dlls, append([]string{"other.dll", "ertransmogrify.dll"}, requiredRandomizerDLLs...)) {
		t.Fatal("existing entry lost", dlls)
	}
	if err := restoreBaseModState(); err != nil {
		t.Fatal(err)
	}
	for name, want := range map[string]string{"ertransmogrify.dll": "user dll", "ertransmogrify.ini": "user settings"} {
		got, _ := os.ReadFile(filepath.Join(cfg.ModEngine, name))
		if string(got) != want {
			t.Fatal("independent mod modified", name)
		}
	}
}
