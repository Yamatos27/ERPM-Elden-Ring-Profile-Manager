package main

import (
	"strings"
	"unsafe"
)

// Own the whole label paint so the native STATIC control cannot fill over the
// image after WM_CTLCOLORSTATIC returns. Paint background and text together.
func drawImageLabel(parent uintptr, dis *DRAWITEMSTRUCT) {
	saved, _, _ := gdi32.NewProc("SaveDC").Call(dis.HDC)
	defer gdi32.NewProc("RestoreDC").Call(dis.HDC, saved)
	if !paintLabelBackground(parent, dis.HwndItem, dis.HDC) {
		pFillRect.Call(dis.HDC, uintptr(unsafe.Pointer(&dis.RcItem)), brushBg)
	}
	pSetBkMode.Call(dis.HDC, TRANSPARENT)
	color := colText
	if dis.HwndItem == randoStatusHwnd {
		switch {
		case strings.HasPrefix(randoVisualState, "ACTIF"), strings.HasPrefix(randoVisualState, "ACTIVE"):
			color = colGreen
		case strings.HasPrefix(randoVisualState, "DÉSACTIVÉ"), strings.HasPrefix(randoVisualState, "DISABLED"), strings.HasPrefix(randoVisualState, "NON CONFIGURÉ"), strings.HasPrefix(randoVisualState, "NOT CONFIGURED"):
			color = colGold
		default:
			color = colRed
		}
	}
	pSetTextColor.Call(dis.HDC, color)
	font, _, _ := pSendMessageW.Call(dis.HwndItem, 0x31, 0, 0) // WM_GETFONT
	if font != 0 {
		gdi32.NewProc("SelectObject").Call(dis.HDC, font)
	}
	text := getWindowText(dis.HwndItem)
	rect := dis.RcItem
	pDrawTextW.Call(dis.HDC, uintptr(unsafe.Pointer(utf16Ptr(text))), uintptr(^uint32(0)), uintptr(unsafe.Pointer(&rect)), 0x10|0x800) // DT_WORDBREAK | DT_NOPREFIX
}

// Repaint the exact image underneath this label before Windows draws its text.
// Transparency alone leaves the previous text behind after value changes.
func paintLabelBackground(parent, child, dc uintptr) bool {
	bgMu.RLock()
	available := len(bgPixels) > 0
	bgMu.RUnlock()
	if !available || parent == 0 || child == 0 {
		return false
	}
	actual, _, _ := user32.NewProc("GetParent").Call(child)
	if actual != parent {
		return false
	}
	var origin POINT
	user32.NewProc("MapWindowPoints").Call(child, parent, uintptr(unsafe.Pointer(&origin)), 1)
	saved, _, _ := gdi32.NewProc("SaveDC").Call(dc)
	if saved == 0 {
		return false
	}
	gdi32.NewProc("SetViewportOrgEx").Call(dc, uintptr(-origin.X), uintptr(-origin.Y), 0)
	ok := drawBackground(parent, dc)
	gdi32.NewProc("RestoreDC").Call(dc, saved)
	return ok
}
